package com.fanniemae.razor.automation.utils.html;

import java.util.List;

public class Table {
	
	private Row headerRow;
	private List<Row> rows;
	private int height;
	private String width = "100%";
	private String table = "";  
	
	public Table setRows(List<Row> rows){
		this.rows = rows;
		return this;
	}
	
	public Table setTableHeight(int height){
		this.height = height;
		return this;
	}
	
	public Table setTableWidth(String width){
		this.width = width;
		return this;
	}
	
	public Table setHeader(Row headerRow){
	    this.headerRow = headerRow;
	    return this;
	}
	
	@Override
	public String toString(){
		StringBuilder table = new StringBuilder();
		//TODO:  move with to Style class
		table.append("<table " + "\"style=width=" + width + "%\"> <thead>"); 
		table.append(headerRow + " </thead> <tbody>");
		for(Row row:rows){
			table.append(row.toString());
		}
		table.append(" </tbody> </table>");
		return table.toString();
	}
	
}
