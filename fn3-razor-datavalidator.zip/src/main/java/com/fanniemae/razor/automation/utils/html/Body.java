package com.fanniemae.razor.automation.utils.html;

public class Body {
	
	private String subHeading;
	private Table table;
	private String textBlock;
	public Body setSubHeading(String subHeading, String headingType){
		this.subHeading = "<"+headingType+">" + subHeading + "</"+headingType+">";
		return this;
	}

	public String getSubHeading() {
		return subHeading;
	}
	
	public Body setTextBlock(String text){
		this.textBlock = "<p>" + text + "</p>";
		return this;
	}
	
	public Table getTable() {
		return table;
	}
	public Body setTable(Table table) {
		this.table = table;
		return this;
	}

	@Override
	public String toString(){
		StringBuilder bodyString = new StringBuilder(subHeading + textBlock);
		
		if(table != null){
			bodyString.append(table);
		}
		return bodyString.toString();
	}
}
