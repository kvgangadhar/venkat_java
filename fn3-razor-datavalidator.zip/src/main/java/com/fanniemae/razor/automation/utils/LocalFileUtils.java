package com.fanniemae.razor.automation.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Component;

import com.fanniemae.razor.request.ClaimDecisionRequest;
import com.fanniemae.razor.request.ClaimDetail;
import com.fanniemae.testeng.automation.filesystem.FileUtils;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;

/**
 * File handling utility class for File upload related functionality
 * 
 * @author q2uscv
 *
 */
@Component
public class LocalFileUtils {

    /**
     * Creates a temporary file in the temporary location and returns the file path
     * 
     * @param inputFileDirectory
     * @param inputFileName
     * @param outputFileName
     * @return
     * @throws IOException
     */
    public static String createTempFileCopyForUpload(String inputFileDirectory, String inputFileName,
            String outputFileName, String outputFileExtn) throws IOException {
        String outputFile = outputFileName + outputFileExtn;
        Path tempFile = Files.createTempFile(outputFile, null);
        // strip off the extension like "123456789.tmp" at the end of the file name.
        Path newTempFile = Files.move(tempFile, tempFile.resolveSibling(outputFile));
        String dataFileToUpload = inputFileDirectory + "/" + inputFileName;
        InputStream inputStream = LocalFileUtils.class.getResourceAsStream(dataFileToUpload);
        Files.copy(inputStream, newTempFile, StandardCopyOption.REPLACE_EXISTING);
        CucumberLogUtils.logInfo("Successfully created a copy of " + inputFileName + " to " + newTempFile.toString());
        return newTempFile.toString();
    }

    /**
     * It takes file size and create a temporary file of that size and returns path for temporary file.
     * 
     * @param sizeinMB
     * @return
     * @throws IOException
     */
    public static String createTempFile(String fileNameWithExtn, long sizeinMB) throws IOException {
        RandomAccessFile f = null;
        Path newTempFile = null;
        Path tempFile = Files.createTempFile(fileNameWithExtn, null);
        newTempFile = Files.move(tempFile, tempFile.resolveSibling(fileNameWithExtn));
        f = new RandomAccessFile(newTempFile.toString(), "rw");
        f.setLength(1024 * 1024 * sizeinMB);
        f.close();
        return newTempFile.toString();
    }

    /**
     * delete temporary files in the temp directory
     * 
     * @param fileDirectory
     * @param fileNameWithExtn
     * @return
     */
    public static boolean deleteTempFile(String fileDirectory, String fileNameWithExtn) {
        // boolean status = false;
        return FileUtils.deleteFile(fileDirectory + fileNameWithExtn);
    }
    
    public static boolean deleteTempFile(String fileDirectory) {
        // boolean status = false;
        return FileUtils.deleteFile(fileDirectory);
    }
    
    public static List<String> readMultiInsertQueryFile(String fileNameWithPath) throws FileNotFoundException, IOException {
    	String content = IOUtils.toString(LocalFileUtils.class.getResourceAsStream(fileNameWithPath), StandardCharsets.UTF_8);
		//String content = IOUtils.toString(new FileInputStream(fileNameWithPath), StandardCharsets.UTF_8);
    	//String content = FileUtils.readFileToString(fileNameWithPath);
		String[] stringArray = content.split(";");
		List<String> queryList = Arrays.asList(stringArray);
		return queryList;
    }
    
    public static List<String> readMultiInsertQueryFileWithDate(String fileNameWithPath, String dateStr) throws FileNotFoundException, IOException {
    	String content = IOUtils.toString(LocalFileUtils.class.getResourceAsStream(fileNameWithPath), StandardCharsets.UTF_8);
		//String content = IOUtils.toString(new FileInputStream(fileNameWithPath), StandardCharsets.UTF_8);
    	//String content = FileUtils.readFileToString(fileNameWithPath);
		String[] stringArray = content.split(";");
		List<String> queryList = Arrays.asList(stringArray);
		return queryList;
    }
    public static List<ClaimDecisionRequest> splitBatchClaim(ClaimDecisionRequest batchRequest) {
        List<ClaimDecisionRequest> claimRequests = new ArrayList<>();
        ClaimDetail[] requestDetails = batchRequest.getValidateClaim();
        IntStream.range(0, requestDetails.length).forEach(index -> {
            ClaimDecisionRequest singleRequest = new ClaimDecisionRequest();
            singleRequest.setCreatedOnDt(batchRequest.getCreatedOnDt());
            singleRequest.setRequestId(batchRequest.getRequestId());
            singleRequest.setMessageCountNum(batchRequest.getMessageCountNum());
            //Assign validateClaim details for the single request
            ClaimDetail[] singleRequestValidateClaimDetail = new ClaimDetail[1];
            singleRequestValidateClaimDetail[0] = requestDetails[index];
            singleRequest.setValidateClaim(singleRequestValidateClaimDetail);
            claimRequests.add(index, singleRequest);
        });
        return claimRequests;
    }
    	
    /*   Unused code. 
	public static String createBulkJson(String singleJsonPath, int jsonCount) throws Exception{
		String singleJson = new String(JsonUtils.readJSONFile(singleJsonPath));
		ClaimDecisionRequest claimRequest = JsonUtils.convertJSONString2JSON(singleJson, ClaimDecisionRequest.class);
		String requestId = claimRequest.getRequestId();
		ClaimDecisionRequest multiClaimDecisionRequest = new ClaimDecisionRequest();
		multiClaimDecisionRequest.setBatchRequest(true);
		multiClaimDecisionRequest.setMessageCountNum(Long.valueOf(jsonCount));
		List<ClaimDetail> claimDetails = new ArrayList<>();
		IntStream.range(0, jsonCount).forEach(count -> {
			try {
				ClaimDetail claim = cloneClaimDetail(claimRequest);
				claim.setClaimTransactionId(requestId + "_" + count );  
				claimDetails.add(claim);
			} catch (Exception e) {
				e.printStackTrace();
			}			
		}
		);
		multiClaimDecisionRequest.setValidateClaim(claimDetails.toArray(new ClaimDetail[0]));
		return JsonUtils.convertJSON2String(multiClaimDecisionRequest);
	}
	*/

	private static ClaimDetail cloneClaimDetail(ClaimDecisionRequest claimRequest)
			throws IOException, ClassNotFoundException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(baos);
		oos.writeObject(claimRequest.getValidateClaim()[0]);
		ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
		ObjectInputStream ois = new ObjectInputStream(bais);
		return (ClaimDetail) ois.readObject();
	}
}
