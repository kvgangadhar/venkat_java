package com.fanniemae.razor.automation;

import com.fanniemae.sharedservices.evas.VaultFactory;
import com.fanniemae.sharedservices.evas.exception.ServiceException;
import com.fanniemae.sharedservices.evas.vault.Vault;
import com.fanniemae.sharedservices.evas.vault.object.PasswordObject;

public class PamPasswordTest {
//Command to be used in unix after copying this file under /export/appl/fn3devl/Sarma
// "/export/apps/tsp_tools/"jdk1.8.0_131"/bin/java -cp /export/appl/fn3devl/Sarma:/export/apps/epv/evas/japi/*:/export/apps/epv/ext/sdk/* PamPasswordTest"
// /export/apps/tsp_tools/"jdk1.8.0_131"/bin/java -cp
	public static void main(String[] args) {
		PamPasswordTest pamTest = new PamPasswordTest();
		try {
			pamTest.getPAMCredentialsUsingEPV("FN3_ORACLE_DORLQ01_ACCT");
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public final PasswordObject getPAMCredentialsUsingEPV(String objID) throws ServiceException {
		PasswordObject	passwordObj;
		Vault vault = VaultFactory.getVault("FN3", "D");
		passwordObj  = (PasswordObject)vault.getVaultObject(objID);
		final String userId = passwordObj.getAccountID();
		final String password = passwordObj.getPassword();
		System.out.println("********PAM Account ID - " + userId);
		System.out.println("********PAM Account Password - " + password);
		return passwordObj;
	}

}

