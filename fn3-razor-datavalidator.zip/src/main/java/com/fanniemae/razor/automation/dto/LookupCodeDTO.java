package com.fanniemae.razor.automation.dto;

public class LookupCodeDTO {
	
	private String codeName;
	private String codeType;
	private String sourceCodeDescr;
	private String targetCodeDescr;

	public String getCodeName() {
		return codeName;
	}
	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}
	public String getCodeType() {
		return codeType;
	}
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}
	public String getSourceCodeDescr() {
		return sourceCodeDescr;
	}
	public void setSourceCodeDescr(String sourceCodeDescr) {
		this.sourceCodeDescr = sourceCodeDescr;
	}
	public String getTargetCodeDescr() {
		return targetCodeDescr;
	}
	public void setTargetCodeDescr(String targetCodeDescr) {
		this.targetCodeDescr = targetCodeDescr;
	}
	
}
