/*
 * Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 */

package com.fanniemae.razor.automation.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.fanniemae.razor.automation.dto.QueryConditionsDTO;
import com.fanniemae.razor.automation.dto.QueryParametersDTO;

/**
 * Xml Utility class for xml traversal
 * 
 */
@Component
public class XmlUtils {

	//private static final String FILE_NAME = "/export/appl/fn3devl/DataValidator/data/QueryMapper.xml";
	
	@Autowired
	private Environment environment; 
	private static Environment env;
	
	@PostConstruct
	public void init() {
		env = environment;
	}
	
	private static Map<String, String> testCaseQueryMap;
	
	public static QueryConditionsDTO getSourceConditions(String source, String srcSchema, String xmlFileName) throws Exception {
		return getSourceConditions(source,"DataTable",srcSchema,xmlFileName);
	}
	
	public static QueryConditionsDTO getSourceConditions(String source, String sourceType,String srcSchema, String xmlFileName) throws Exception {
		
		QueryConditionsDTO queryConditionsDTO = null;
		List<QueryConditionsDTO> queryConditionsDTOList = new ArrayList<QueryConditionsDTO>();
		Map<String,QueryParametersDTO> sourceQueryConditions = new HashMap<String,QueryParametersDTO>();
		Document doc = readXmlFile(xmlFileName);
		NodeList sourceNodeList = doc.getElementsByTagName("source");
		for (int sourceIndex = 0; sourceIndex < sourceNodeList.getLength(); sourceIndex++) {
			queryConditionsDTO = new QueryConditionsDTO();
			boolean isConditionFound = false;
			Node sourceNode = sourceNodeList.item(sourceIndex);
			String src = sourceNode.getAttributes().item(0).getNodeValue();
			if (sourceNode.getNodeType() == Node.ELEMENT_NODE && sourceNode.getAttributes() != null) {
				Element eElement = (Element) sourceNode;
				NodeList tableNodeList = eElement.getElementsByTagName("table");
				for (int tableIndex = 0; tableIndex < tableNodeList.getLength(); tableIndex++) {
					String srcTableName = null;
					String trgTableName = null;
					String srcKey = null;
					String trgKey = null;
					String tableFromClause = null;
					String tableSelectClause = null;
					String alternateSource = null;
					QueryParametersDTO queryParametersDTO = new QueryParametersDTO();
					Node tableNode = tableNodeList.item(tableIndex);
					if (tableNode.getNodeType() == Node.ELEMENT_NODE && tableNode.getAttributes() != null) {
						trgTableName = tableNode.getAttributes().getNamedItem("targetname").getNodeValue();
						if(sourceType.equalsIgnoreCase("DataTable") && !trgTableName.equalsIgnoreCase(source)){
							continue;
						}
						else{
							isConditionFound = true;
						}
						queryParametersDTO.setTargetTableName(trgTableName);
						srcTableName = tableNode.getAttributes().getNamedItem("sourcename").getNodeValue();
						queryParametersDTO.setSourceTableName(srcTableName);
						Node srcKeyNode = tableNode.getAttributes().getNamedItem("srcKey");
						if(srcKeyNode != null){
							srcKey = srcKeyNode.getNodeValue();
							queryParametersDTO.setSourceKey(srcKey);
						}
						
						Node trgKeyNode = tableNode.getAttributes().getNamedItem("trgKey");
						if(trgKeyNode != null){
							trgKey = trgKeyNode.getNodeValue();
							queryParametersDTO.setTargetKey(trgKey);
						}
						
						Node tableFromClauseAttr = tableNode.getAttributes().getNamedItem("fromClause");
						if(tableFromClauseAttr != null){
							tableFromClause = tableFromClauseAttr.getNodeValue().replaceAll("SRC_SCHEMA", srcSchema);
							queryParametersDTO.setFromClause(tableFromClause);
						}
						
						Node tableSelectClauseAttr = tableNode.getAttributes().getNamedItem("selectClause");
						if(tableSelectClauseAttr != null){
							tableSelectClause = tableSelectClauseAttr.getNodeValue().replaceAll("SRC_SCHEMA", srcSchema);
							queryParametersDTO.setSelectClause(tableSelectClause);
						}
						
						Node alternateSourceAttr = tableNode.getAttributes().getNamedItem("alternateSource");
						if(alternateSourceAttr != null){
							alternateSource = alternateSourceAttr.getNodeValue();
							queryParametersDTO.setAlternateSource(alternateSource);
						}
						
					}
					String key = "";
				//	if(sourceType.equalsIgnoreCase("DataTable") && source.equalsIgnoreCase(trgTableName)){
				//		sourceQueryConditions = new HashMap<String, QueryParametersDTO>();
				//		key = srcTableName.toUpperCase()+":"+trgTableName.toUpperCase();
				//		sourceQueryConditions.put(key,queryParametersDTO);
						//isConditionFound = true;
						//break;
				//	}
					key = srcTableName.toUpperCase()+":"+trgTableName.toUpperCase();
					sourceQueryConditions.put(key,queryParametersDTO);
				}
				if(isConditionFound){
					queryConditionsDTO.setSource(src);
					queryConditionsDTO.setSourceContditions(sourceQueryConditions);
					queryConditionsDTOList.add(queryConditionsDTO);
				}
			}
		}
		
		return queryConditionsDTOList.get(0);
	}
	
	public static Map<String,Map<String,String>> getTargetConditions(String xmlFileName) throws Exception {
		
		
		Map<String,Map<String,String>> trgtableConditions = new HashMap<String, Map<String,String>>();
		Document doc = readXmlFile(xmlFileName);
		Node targetNode = doc.getElementsByTagName("target").item(0);
		if(targetNode.getNodeType() == Node.ELEMENT_NODE){
            Element tableElement = (Element) targetNode;
            NodeList tableNodes = tableElement.getElementsByTagName("table");
            int columnSize = 0;
			for (int i=0;i<tableNodes.getLength();i++){
				String tableName = tableNodes.item(i).getAttributes().getNamedItem("tableId").getNodeValue();
				String isCritical = "N";
				Node isCriticalNode = tableNodes.item(i).getAttributes().getNamedItem("isCritical");
				if(isCriticalNode != null){
					isCritical = "Y";
				}
				if(tableNodes.item(i).getNodeType() == Node.ELEMENT_NODE){
					Element columnElement = (Element) tableNodes.item(i);
					NodeList columnNodes = columnElement.getElementsByTagName("column");
					Map<String,String> columnConditions =  new HashMap<String,String>();
					for (int j=0;j<columnNodes.getLength();j++){
						String columnName = columnNodes.item(j).getAttributes().getNamedItem("columnName").getNodeValue();
						String srcColumnRequired = columnNodes.item(j).getAttributes().getNamedItem("isRequiredOnSource").getNodeValue();
						//System.out.println("Is Column "+columnName+" Required: "+srcColumnRequired);
						columnConditions.put(columnName.toUpperCase().trim(), srcColumnRequired+":"+isCritical); 
					}
					columnSize = columnSize + columnConditions.size();
					trgtableConditions.put(tableName, columnConditions);
				}
			}
			//System.out.println("In the Loop ***** Table Size" + trgtableConditions.size());
			//System.out.println("In the Loop ***** Column Size" + columnSize);
			
			
		}
		/*//nodeList.getLength();
		//Node targetNode = doc.getElementsByTagName("target").item(0);
		//NamedNodeMap tableNodeList = targetNode.getAttributes();
		//String targetName = targetNode.getLocalName();
		//NamedNodeMap tableNodeList = targetNode.getAttributes();
		for (int i=0; i<tableNodeList.getLength(); i++){
			
			Node tableNode = tableNodeList.item(i);
			String src = tableNode.getAttributes().item(0).getNodeValue();
			String tableName = tableNode.getNodeName();
			System.out.println("Table Name: " + tableName);
		}*/
		return trgtableConditions;
	}
	
	public static Map<String,List<String>> getTargetTables(String xmlFileName) throws ParserConfigurationException, SAXException, IOException{
		Document doc = readXmlFile(xmlFileName);
		Node targetNode = doc.getElementsByTagName("target").item(0);
		Map<String,List<String>> trgTableColumnList = new HashMap<String,List<String>>();
		List<String> trgColumnList = null;
		if(targetNode.getNodeType() == Node.ELEMENT_NODE){
            Element tableElement = (Element) targetNode;
            NodeList tableNodes = tableElement.getElementsByTagName("table");
			for (int i=0;i<tableNodes.getLength();i++){
				String tableName = tableNodes.item(i).getAttributes().getNamedItem("tableId").getNodeValue();
				
				if(tableNodes.item(i).getNodeType() == Node.ELEMENT_NODE){
					Element columnElement = (Element) tableNodes.item(i);
					NodeList columnNodes = columnElement.getElementsByTagName("column");
					trgColumnList = new ArrayList<String>();
					for (int j=0;j<columnNodes.getLength();j++){
						
						String columnName = columnNodes.item(j).getAttributes().getNamedItem("columnName").getNodeValue();
						trgColumnList.add(columnName);
					}
					trgTableColumnList.put(tableName, trgColumnList);
				}
			}
			System.out.println("############ " + trgTableColumnList.toString());
		}
		return trgTableColumnList;
	}
	
	//Get all information for any individual table
	public static Map<String,String> getTableProps(String table, String xmlFileName) throws ParserConfigurationException, SAXException, IOException{
		Map<String,String> tableProps = new HashMap<String,String>();
		Document doc = readXmlFile(xmlFileName);
		Node targetNode = doc.getElementsByTagName("target").item(0);
		if(targetNode.getNodeType() == Node.ELEMENT_NODE){
            Element tableElement = (Element) targetNode;
            NodeList tableNodes = tableElement.getElementsByTagName("table");
            for (int i=0;i<tableNodes.getLength();i++){
				String tableName = tableNodes.item(i).getAttributes().getNamedItem("tableId").getNodeValue();
					//table tableId="LN" oneToOneMapping="N" childTables="PROP_EXP_CLSFN_SMRY,PROP_EXP_CLM,PROP_PRSVN_EXP_PRE_APRVL,LN_SPCL_FEAT,LN_DLQY,FNM_ACTG_PRCD,FNM_ACTG_RCVB,LN_APPL" primaryKey="FNM_LN_ID" isCritical="Y">
					Node oneToOneMappingNode, childTablesNode, primaryKeyNode, isCriticalNode,altKeyColumnNode;
					oneToOneMappingNode = tableNodes.item(i).getAttributes().getNamedItem("oneToOneMapping");
					if(oneToOneMappingNode != null)
						tableProps.put("oneToOneMapping", oneToOneMappingNode.getNodeValue());
					childTablesNode = tableNodes.item(i).getAttributes().getNamedItem("childTables");
					if(childTablesNode != null)
						tableProps.put("childTables", childTablesNode.getNodeValue());
					primaryKeyNode = tableNodes.item(i).getAttributes().getNamedItem("primaryKey");
					if(primaryKeyNode != null)
						tableProps.put("primaryKey", primaryKeyNode.getNodeValue());
					altKeyColumnNode = tableNodes.item(i).getAttributes().getNamedItem("alternateKey");
					if(altKeyColumnNode != null)
						tableProps.put("alternateKey", altKeyColumnNode.getNodeValue());
					isCriticalNode = tableNodes.item(i).getAttributes().getNamedItem("isCritical");
					if(isCriticalNode != null)
						tableProps.put("isCritical", isCriticalNode.getNodeValue());
					if(tableName.equalsIgnoreCase(table)){
						break;
				}
            }
		}
		return tableProps;
	}
	
	public static Map<String,Map<String,String>> getParentTableAndKeyMap(String xmlFileName) throws ParserConfigurationException, SAXException, IOException{
		Map<String,Map<String,String>> tableAndKeyMap = new HashMap<String,Map<String,String>>();
		Document doc = readXmlFile(xmlFileName);
		Node targetNode = doc.getElementsByTagName("target").item(0);
		if(targetNode.getNodeType() == Node.ELEMENT_NODE){
            Element tableElement = (Element) targetNode;
            NodeList tableNodes = tableElement.getElementsByTagName("table");
            for (int i=0;i<tableNodes.getLength();i++){
            	Map<String,String> tableProps = new HashMap<String,String>();
            	Node primaryKeyNode,alternateKeyNode,isCriticalNode;
				String tableName = tableNodes.item(i).getAttributes().getNamedItem("tableId").getNodeValue();
				primaryKeyNode = tableNodes.item(i).getAttributes().getNamedItem("primaryKey");
				alternateKeyNode = tableNodes.item(i).getAttributes().getNamedItem("alternateKey");
				isCriticalNode = tableNodes.item(i).getAttributes().getNamedItem("isCritical");
				String criticalFlag = "N";
				if (primaryKeyNode != null)
				{
					tableProps.put("primaryKey", primaryKeyNode.getNodeValue());
					if (alternateKeyNode != null){
						tableProps.put("alternateKey", alternateKeyNode.getNodeValue());
					}
					if(isCriticalNode != null){
						criticalFlag = isCriticalNode.getNodeValue();
					}	
					tableProps.put("isCritical", criticalFlag);
					tableAndKeyMap.put(tableName,tableProps);
				}
            }
		}
		return tableAndKeyMap;
	}
	
	public static List<Map<String,String>> getAdhocQuries(String xmlFileName) throws ParserConfigurationException, SAXException, IOException{
		List<Map<String,String>> queryList = new ArrayList<Map<String,String>>();
		Document doc = readXmlFile(xmlFileName);
		Node targetNode = doc.getElementsByTagName("adhoc").item(0);
		if(targetNode.getNodeType() == Node.ELEMENT_NODE){
			Element queryElement = (Element) targetNode;
			NodeList queryNodes = queryElement.getElementsByTagName("query");
			String selectQuery = null;
			String schemaPrefix = null;
			String resultType = null;
			String queryName = null;
			String queryTables = null;
			String expectedResult = null;
			for (int i=0;i<queryNodes.getLength();i++){
				Map<String,String> queryMap = new HashMap<String,String>();
				Node selectQueryNode = queryNodes.item(i).getAttributes().getNamedItem("selectQuery");
				selectQuery = (selectQueryNode != null) ? selectQueryNode.getNodeValue() : StringUtils.EMPTY;
				Node schemaPrefixNode = queryNodes.item(i).getAttributes().getNamedItem("schemaPrefix");
				schemaPrefix = (schemaPrefixNode != null) ? schemaPrefixNode.getNodeValue() : StringUtils.EMPTY;
				Node resultTypeNode = queryNodes.item(i).getAttributes().getNamedItem("resultType");
				resultType = (resultTypeNode != null) ? resultTypeNode.getNodeValue() : StringUtils.EMPTY;
				Node queryNameNode = queryNodes.item(i).getAttributes().getNamedItem("queryName");
				queryName = (queryNameNode != null) ? queryNameNode.getNodeValue() : StringUtils.EMPTY ;
				Node queryTablesNode = queryNodes.item(i).getAttributes().getNamedItem("queryTables");
				queryTables = (queryTablesNode != null) ? queryTablesNode.getNodeValue() : StringUtils.EMPTY;
				Node expectedResultNode = queryNodes.item(i).getAttributes().getNamedItem("expectedResult");
				expectedResult = (expectedResultNode != null) ? expectedResultNode.getNodeValue() : StringUtils.EMPTY;
				queryMap.put("schemaPrefix", schemaPrefix);
				queryMap.put("selectQuery", selectQuery);
				queryMap.put("resultType", resultType);
				queryMap.put("queryName", queryName);
				queryMap.put("queryTables", queryTables);
				queryMap.put("expectedResult", expectedResult);

				queryList.add(queryMap);
			}
		}
		return queryList;
	}
	
	private static Document readXmlFile(String fileName)
			throws ParserConfigurationException, SAXException, IOException {
		Document doc = null;
		try{
			File fXmlFile = new File(fileName);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return doc;
	}
	
	public static void main(String[] args) throws Exception {
		//System.out.println(getSourceConditions("ARROW","fpw").getSourceContditions().get("LNCMNT:LN_CMNTS").getFromClause());
/*		Map<String,Map<String,String>> targetConditions = getTargetConditions();
		int size = targetConditions.size();
		//System.out.println("#####################SIZE: " + size);
		//for(Map<String,String> columnConditions : targetConditions.values()) {
			Iterator<String> tableterator = targetConditions.keySet().iterator();
			String tableName;
			int size1 =0; 
			
			while(tableterator.hasNext()){
				
				tableName = (String) tableterator.next();
				Map<String,String> columnConditions = targetConditions.get(tableName);
				
				
				Iterator<String> columnIterator = columnConditions.keySet().iterator();
				while(columnIterator.hasNext()){
					int size2 = columnConditions.size();
					size1 = size1+size2;
					//System.out.println("$$$$$$$$$$$$$ SIZE: " + size1);
					String columnName = (String) columnIterator.next();
					String isRequired = columnConditions.get(columnName);
					
					System.out.println("*******" +tableName+":"+ columnName + ":" +isRequired);
			}
		}*/
		//Map<String,String> relations = oneToOneMapping();
		//System.out.println(relations.toString());
		//Map<String,String> relations = getRelations("LN");
		//System.out.println(relations.toString());
		//Map<String,Map<String,String>> parentKeyMap = getParentTableAndKeyMap();
		//System.out.println(parentKeyMap.toString());
		//List<Map<String,String>> queries = getAdhocQuries();
		//System.out.println(queries.toString());
		
		
//		StringBuilder errorString = new StringBuilder();
//		int errorCount = 0;
//		if(errorString.length()>0){
//			errorCount = errorString.toString().split("\n").length;
//		}
//		System.out.println("Length: " + errorCount);
		/*QueryConditionsDTO queryConditionsDTO = getSourceConditions("LN_APPL","DataTable","FN3ACPT");
		
			System.out.println("Source :" + queryConditionsDTO.getSource());
			System.out.println("Conditions:" + queryConditionsDTO.getSourceContditions());
		*/
		/* Map<String,List<String>> list = getTargetTables();
		//System.out.println(list.toString());
		//System.out.println("\n" + list.size());
		for(String trgTable:list.keySet()){
			System.out.println(trgTable);
			for(String columnName:list.get(trgTable)){
				System.out.println("    "+columnName);
			}
		}*/
	}
	
}