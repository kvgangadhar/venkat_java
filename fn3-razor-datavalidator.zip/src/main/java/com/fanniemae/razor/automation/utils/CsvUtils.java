/*
 * Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.razor.automation.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;


public class CsvUtils {

	public static boolean isTypeCode(String sourceColumn, String csvFileName){
		boolean isTypeCode = false;
		List<String> columnNames = new ArrayList<String>();
		Iterable<CSVRecord> records = readCSV(csvFileName);
		for (CSVRecord record : records) {
		    String sourceTableName = record.get("Source Table Name");
		    String sourceAttribute = record.get("Source Attribute Name");
		    columnNames.add(sourceTableName+"."+sourceAttribute);
		}
		if(columnNames.contains(sourceColumn)){
			isTypeCode = true;
		}
		return isTypeCode;
	}
	public static Map<String, String> getSourceEDGLookUp(String csvFileName){
		Iterable<CSVRecord> records = readCSV(csvFileName);
		Map<String,String> edgValueLookUp = new HashMap<String,String>();
		for (CSVRecord record : records) {
		    String sourceTableName = record.get("Source Table Name");
		    String sourceAttribute = record.get("Source Attribute Name");
		    String sourceValue = record.get("Source Value");
		    String eDGValue = record.get("EDG Value");
		    String eDGKey = sourceTableName+":"+sourceAttribute+":"+sourceValue;
		    edgValueLookUp.put(eDGKey, eDGValue);
		   // System.out.println(source + ":" + sourceTableName + ":" + sourceValue + ":" + eDGValue);
		}
		return edgValueLookUp;
	}
	
	public static Map<String, List<String>> getTargetEDGLookUp(String tableName, String csvFileName){
		Iterable<CSVRecord> records = readCSV(csvFileName);
		Map<String,List<String>> edgValueLookUp = new HashMap<String,List<String>>();
		List<String> eDGValues = new ArrayList<String>();
		for (CSVRecord record : records) {
		    String targetTableName = record.get("Target Table Name");
		    if(tableName != null && !targetTableName.equalsIgnoreCase(tableName)){
		    	continue;
		    }
		    String targetAttribute = record.get("Target Attribute Name");
		    String eDGValue = record.get("EDG Value");
		    String eDGKey = targetTableName+":"+targetAttribute;
		    if(edgValueLookUp.containsKey(eDGKey)){
		    	eDGValues = edgValueLookUp.get(eDGKey);
		    	eDGValues.add(eDGValue);
		    }
		    else{
		    	eDGValues = new ArrayList<String>();
		    	eDGValues.add(eDGValue);
		    	edgValueLookUp.put(eDGKey, eDGValues);
		    }
		    
		   // System.out.println(source + ":" + sourceTableName + ":" + sourceValue + ":" + eDGValue);
		}
		return edgValueLookUp;
	}
	
	public static Iterable<CSVRecord> readCSV(String csvFileName){
		Reader in = null;
		try {
			in = new FileReader(csvFileName);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Iterable<CSVRecord> records = null;
		try {
			records = CSVFormat.RFC4180.withFirstRecordAsHeader().parse(in);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return records;
	}
	public static void main(String[] args){
		//CsvUtils csvUtils = new CsvUtils();
		/*Map<String,String> edgValueLookUp = csvUtils.getSourceEDGLookUp();
		//for(String edgValueKey:edgValueLookUp.keySet()){
			//System.out.println("Edg Key: " + edgValueKey + " :: " + "Edg Value: " + edgValueLookUp.get(edgValueKey));
		//}
		String eDGValueKey = "RECEIPT:CATEGORY:311";
		String eDGValue = edgValueLookUp.get(eDGValueKey);
		System.out.println("Edg Key: " + eDGValueKey + " :: " + "Edg Value: " + eDGValue);*/
		
		//Map<String,List<String>> trgEdgValues = CsvUtils.getTargetEDGLookUp("FNM_ACTG_RCVB");
		//System.out.println("Target EDGValues: " + trgEdgValues.toString());
	}
}

