package com.fanniemae.razor.automation.dto;

/**
 * For the validation of JSON values 
 * @author q2uscv
 *
 */
public class JSONOutputElement {

	private String jSONpath;
	private String jSONvalue;
	private Class clazz;

	public String getjSONvalue() {
		return jSONvalue;
	}

	public void setjSONvalue(String jSONvalue) {
		this.jSONvalue = jSONvalue;
	}

	public String getjSONpath() {
		return jSONpath;
	}

	public void setjSONpath(String jSONpath) {
		this.jSONpath = jSONpath;
	}

	public Class getClazz() {
		return clazz;
	}

	public void setClazz(Class clazz) {
		this.clazz = clazz;
	}
	
	

}
