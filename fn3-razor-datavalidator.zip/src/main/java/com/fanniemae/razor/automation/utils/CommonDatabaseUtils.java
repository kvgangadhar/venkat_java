package com.fanniemae.razor.automation.utils;

import static com.fanniemae.razor.automation.common.CommonConstants.USE_GREATER_AND_EQUAL_DATE;
import static com.fanniemae.razor.automation.common.CommonConstants.USE_SUBQUERY_CONDITION;
import static com.fanniemae.razor.automation.common.CommonConstants.USE_THE_DATE_INPUT_MATCHING;
import static com.fanniemae.razor.automation.common.CommonConstants.USE_THE_INPUT_MATCHING;
import static com.fanniemae.razor.automation.common.CommonConstants.USE_THE_IN_CONDITION;
import static com.fanniemae.razor.automation.common.CommonConstants.USE_THE_LIKE_CONDITION;
import static com.fanniemae.razor.automation.common.CommonConstants.NOT_NULL_CONDITION;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.fanniemae.razor.automation.common.CommonCache;
import com.fanniemae.razor.automation.common.CommonCacheConstants;
import com.fanniemae.razor.automation.dto.DBColumnDTO;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;

/**
 * Contains utilities related to database connections.
 *
 * @author q2uscv
 */
@Component
public class CommonDatabaseUtils {
	
	
	/**
	 * Builds the where clause.
	 *
	 * @param columnValues the column values
	 * @param existingFormValues the existing form values
	 * @return the string
	 */
	public static String buildWhereClause(List<DBColumnDTO> columnValues,
			Map<String, String> existingFormValues) {
		StringBuilder whereClause = new StringBuilder(" where ");
		boolean firstIteration = true;
		for (DBColumnDTO column : columnValues) {
			if (!firstIteration)
				whereClause.append(" AND ");
			whereClause.append(column.getTableName());
			whereClause.append(".");
			whereClause.append(column.getColumnName());
			if (null != column.getJoin()
					&& column.getJoin().equalsIgnoreCase("Y")) {
				if (null != column.getForeignTable()  
						&& !column.getForeignTable().isEmpty()
						&& null != column.getForeignJoinColumn() 
						&& !column.getForeignJoinColumn().isEmpty()) {
					whereClause.append(" = ");
					whereClause.append(column.getForeignTable());
					whereClause.append(".");
					whereClause.append(column.getForeignJoinColumn());
				} else {
					CucumberLogUtils
							.logFail(
									"Join condition for foreignTable and foreignColumnName are missing.",
									false);
					break;
				}
			} else {
				if (null != column.getColumnValue() && column.getColumnValue().isEmpty()) {
					whereClause.append(" is null");
				} if (column.getColumnValue().equalsIgnoreCase(NOT_NULL_CONDITION)) {
					whereClause.append(" is not null");
				} else if (column.getColumnValue().contains(USE_THE_LIKE_CONDITION)) {
					whereClause.append(" like ");
					whereClause.append(convertColumnValue(column.getColumnValue(), existingFormValues));
				} else if (column.getColumnValue().contains(USE_THE_IN_CONDITION)) {
					whereClause.append(" in ");
					whereClause.append(convertColumnValue(column.getColumnValue(), existingFormValues));
				} else if (column.getColumnValue().contains(USE_SUBQUERY_CONDITION)) {
					whereClause.append(" ");
					whereClause.append(convertColumnValue(column.getColumnValue(), existingFormValues));
				} else if (column.getColumnValue().contains(USE_GREATER_AND_EQUAL_DATE)) {
					whereClause.append(" >= ");
					whereClause.append(convertColumnValue(column.getColumnValue(), existingFormValues));
				} else {
					if (column.getNotEqual() != null && column.getNotEqual().equalsIgnoreCase("Y")) {
						whereClause.append(" != ");
					} else {
						whereClause.append(" = ");
					}
					whereClause.append(convertColumnValue(column.getColumnValue(), existingFormValues));
				}
			}
			whereClause.append(" ");
			firstIteration = false;
		}
		return whereClause.toString(); 
	}

	/**
	 * Builds the query.
	 *
	 * @param tableName the table name
	 * @param whereClause the where clause
	 * @return the string
	 */
	public static String buildQuery(String tableName, String whereClause) {
		StringBuilder query = new StringBuilder(
				"Select count(1) as count from ");

		query.append(tableName);
		query.append(" ");
		query.append(whereClause);
		return query.toString();
	}
	
	/**
	 * Builds the select query.
	 *
	 * @param columnName the column name
	 * @param tableName the table name
	 * @param orderByColumnName the order by column name
	 * @param sortOrder the sort order
	 * @param whereClause the where clause
	 * @return the string
	 */
	public static String buildSelectQuery(String columnName, String tableName,
			String orderByColumnName, String sortOrder, String whereClause) {
		StringBuilder query = new StringBuilder("Select " + columnName
				+ " from ");

		query.append(tableName);
		query.append(" ");
		query.append(whereClause);
		if (orderByColumnName != null && sortOrder != null) {
				query.append(" ORDER BY " + orderByColumnName + " " + sortOrder);			
		}
		return query.toString();
	}

	/**
	 * Convert column value.
	 *
	 * @param columnName the column name
	 * @param columnValue the column value
	 * @param existingFormValues the existing form values
	 * @return the string
	 */
	private static String convertColumnValue(String columnValue, Map<String, String> existingFormValues) {
		if (columnValue.contains(USE_THE_INPUT_MATCHING)) {
			return appendQuotesForStringInputs(existingFormValues
					.get(CommonUtils.getKey(columnValue)));
		} else if (columnValue.contains(USE_THE_DATE_INPUT_MATCHING)) {
			return getDateFormatForWhereClause(existingFormValues
					.get(CommonUtils.getKey(columnValue)));
		} else if (columnValue.contains(USE_THE_IN_CONDITION)) {
			return buildInCondition(CommonUtils.getKey(columnValue));
		}  else if (columnValue.contains(USE_SUBQUERY_CONDITION)) {
			return buildSubQueryCondition(columnValue);
		} else if (columnValue.contains(USE_THE_LIKE_CONDITION)) {
			if(null != existingFormValues
					.get(CommonUtils.getKey(columnValue))) {
				return buildLikeCondition(existingFormValues
						.get(CommonUtils.getKey(columnValue)));
			} else {
				return buildLikeCondition(CommonUtils.getKey(columnValue));
			}
			
		} else if (columnValue.contains(USE_GREATER_AND_EQUAL_DATE)) {
			return buildGreaterOrEqualDate(existingFormValues
					.get(CommonUtils.getKey(columnValue)));
		} else {
			return appendQuotesForStringInputs(columnValue);
		}
	}

	/**
	 * This method build the sql query if date as input string 
	 * @param inputString
	 * @return
	 */
	private static String buildGreaterOrEqualDate(String dateString) {
		StringBuilder formatedDate = new StringBuilder();
		if (dateString != null) {
			formatedDate.append("to_date('").append(dateString).append("','MM/dd/yyyy')");
		} else {
			return null;
		}
		return formatedDate.toString();
	}

	/**
	 * Builds the like condition.
	 *
	 * @param key the key
	 * @return the string
	 */
	private static String buildLikeCondition(String inputString) {		
		StringBuilder formatLike = new StringBuilder("'%");
		if (inputString != null) {
			formatLike.append(inputString).append("%'");
		} else {
			return null;
		}
		return formatLike.toString();		
	}

	/**
	 * Adds the form values for db validation.
	 *
	 * @param map the map
	 */
	@SuppressWarnings("unchecked")
	public static void addFormValuesForDBValidation(CommonCache commonCache, Map<String, String> map) {
		Map<String, String> formValuesMap = commonCache.getFromCache(HashMap.class,
				CommonCacheConstants.DB_VALIDATION_FORM_VALUES);
		Set<String> keys = map.keySet();
		for (String key : keys) {
			formValuesMap.put(key, map.get(key));
		}
	}

	/**
	 * Gets the date format for where clause.
	 *
	 * @param inputString the input string
	 * @return the date format for where clause
	 */
	private static String getDateFormatForWhereClause(String inputString) {
		StringBuilder formatForDate = new StringBuilder("to_date('");
		if (inputString != null) {
			formatForDate.append(inputString).append("','MM/dd/yyyy')");
		} else {
			return null;
		}
		return formatForDate.toString();
	}

	/**
	 * Append quotes for string inputs.
	 *
	 * @param columnValue the column value
	 * @return the string
	 */
	private static String appendQuotesForStringInputs(String columnValue) {
		StringBuilder stringBuilder = new StringBuilder("'");
		stringBuilder.append(columnValue);
		stringBuilder.append("'");
		return stringBuilder.toString();
	}

	
	/**
	 * Prepares IN condition for the where clause.
	 *
	 * @param columnValues the column values
	 * @return the string
	 */
	private static String buildInCondition(String columnValues) {
		StringBuilder inQueryBuilder = new StringBuilder();
		inQueryBuilder.append("(");

		String[] values = columnValues.split(",");
		for (String value : values) {
			inQueryBuilder.append(appendQuotesForStringInputs(value.trim()));
			inQueryBuilder.append(",");
		}
		int strLength = inQueryBuilder.length();
		if (strLength > 0 && inQueryBuilder.charAt(strLength - 1) == ',') {
			inQueryBuilder.deleteCharAt(strLength - 1);
		}

		inQueryBuilder = inQueryBuilder.append(")");
		return inQueryBuilder.toString();
	}
	
	/**
	 * Builds the sub query condition.
	 *
	 * @param columnValues the column values
	 * @return the string
	 */
	private static String buildSubQueryCondition(String columnValues) {
		String subQuery = columnValues.replaceFirst("USE_SUBQUERY_CONDITION=", "");		
		return subQuery;
	}	

	/**
	 * Prepares IN condition for the where clause.
	 *
	 * @param columnValues the column values
	 * @return the string
	 */
	@SuppressWarnings("unused")
	private static String buildInsertColumn(boolean columnValue ,List<DBColumnDTO> columnValues) {
		StringBuilder inQueryBuilder = new StringBuilder();
		inQueryBuilder.append(" (");
	
		for (DBColumnDTO value : columnValues) {
			if (columnValue){
				if (value.getColumnValue().equals("sysdate"))
					inQueryBuilder.append(value.getColumnValue());
				else
					inQueryBuilder.append(appendQuotesForStringInputs(value.getColumnValue()));
			}
			else
				inQueryBuilder.append(value.getColumnName());
			inQueryBuilder.append(",");
		}
		int strLength = inQueryBuilder.length();
		if (strLength > 0 && inQueryBuilder.charAt(strLength - 1) == ',') {
			inQueryBuilder.deleteCharAt(strLength - 1);
		}

		inQueryBuilder = inQueryBuilder.append(")");
		return inQueryBuilder.toString();
	}
    
	//Needed for future
//	public static List<Map<String, Object>> convertDBObjectsToList(List<Map<String, DbField>> listOfDBResult, String timestampFormat) {
//        List<Map<String, Object>> dataList = new ArrayList<Map<String, Object>>();
//        if (listOfDBResult != null) {
//            for (Map<String, DbField> dbData : listOfDBResult) {
//                Map<String, Object> dataMap = new HashMap<String, Object>();
//                Iterator<Entry<String, DbField>> dataRowIterator = dbData.entrySet().iterator();
//                while (dataRowIterator.hasNext()) {
//                    Map.Entry<String, DbField> dataMapDbField = dataRowIterator.next();
//                    String columnName = dataMapDbField.getKey();
//                    DbField columnValueDBField = dataMapDbField.getValue();
//                    String columnValue = "";
//                    if(columnValueDBField != null && columnValueDBField.getValue() != null){
//	                    if(null!=timestampFormat && Types.TIMESTAMP==columnValueDBField.getType()){
//	                    	final DateFormat df = new SimpleDateFormat(timestampFormat);
//	                    	columnValue = df.format(((Date)columnValueDBField.getValue()));
//	                    }else{
//	                    // convert values into String
//	                    	columnValue = columnValueDBField.getValue().toString();
//	                    }
//                    }
//                    dataMap.put(columnName, columnValue);
//                }
//                dataList.add(dataMap);
//            }
//        }
//        return dataList;
//
//    }

}
