/*
 * Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.razor.automation.steps.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import com.fanniemae.razor.automation.dto.MappingDTO;
import com.fanniemae.razor.automation.dto.QueryConditionsDTO;
import com.fanniemae.razor.automation.dto.QueryParametersDTO;
import com.fanniemae.razor.automation.dto.SourceDTO;
import com.fanniemae.razor.automation.dto.SourceNameTypeCode;
import com.fanniemae.razor.automation.utils.CsvUtils;
import com.fanniemae.razor.automation.utils.ExcelUtils;
import com.fanniemae.razor.automation.utils.LoggerUtils;
import com.fanniemae.razor.automation.utils.XmlUtils;

/**
 * Database Steps Implementation logic
 *
 */
@Component
public class DatabaseImpl {
	@Autowired
	private GenericApplicationContext applicationContext;

	private static JdbcTemplate srcDB;
	private static JdbcTemplate trgDB;
	private static String errorType;
	private static String prevErrorType = "INITIALVAL";
	private static String insertQuery = "Insert";
	private static String updateQuery = "Update";
	private static String selectQuery = "Fetch";
	private static String selectUpdateQuery = "SelectUpdate";
	private static int testcaseErrObjId;
	private static String errorMessage;
	static Map<String, Integer> errorTypePriorityMap;
	private String source;
	private String srcSchemaString;
	private String srcSchema;
	private static String trgSchema;

	/**
	 * we populate this map with errortype as key and their Priorities as a values.
	 */
	@PostConstruct
	public void init() {
		trgSchema = env.getRequiredProperty("aws.stage.dbconn.schema");
		errorTypePriorityMap = new HashMap<String, Integer>();
		errorTypePriorityMap.put("INITIALVAL", 0);
		errorTypePriorityMap.put("INFO", 1);
		errorTypePriorityMap.put("WARNING", 2);
		errorTypePriorityMap.put("ERROR", 3);
		errorTypePriorityMap.put("CRITICAL", 4);

	}

	@Autowired
	private Environment env;
	@Autowired
	private LoggerUtils loggerUtils;
	private static StringBuffer logBuffer = null;
	private static StringBuffer errorBuffer = null;
	private static StringBuffer criticalErrorBuffer = null;
	private static final String starFiller = StringUtils.leftPad("", 100, "*");
	//private static final String underBarFiller = StringUtils.leftPad("", 100, "_");
	private static final String emptyLine = "";
	private static final String errorSummaryHeaderBegin = "BEGIN: ERROR REPORT SUMMARY";
	private static final int errorSummaryBeginPad = getHeaderPadding(errorSummaryHeaderBegin);
	private static final String errorSummaryHeaderEnd = "END:  ERROR REPORT SUMMARY";
	private static final int errorSummaryEndPad = getHeaderPadding(errorSummaryHeaderEnd);
	private static final String errorSummaryBeginString = StringUtils.leftPad(errorSummaryHeaderBegin, errorSummaryBeginPad, "");
	private static final String errorSummaryEndString = StringUtils.leftPad(errorSummaryHeaderEnd, errorSummaryEndPad, "");
	private static final String criticalError = "CRITICAL ERROR(S) FOUND";
	private String xmlFileName = null;
	private String csvFileName = null;
	private static Logger logger = Logger.getLogger(DatabaseImpl.class.getName());
	private String mappingFile = null;

	public void startValidations(String tableName) {
		mappingFile = env.getRequiredProperty("aws.stage.dataload.mappingFile");
		xmlFileName = env.getRequiredProperty("aws.stage.dataload.queryMapperXml");
		csvFileName = env.getRequiredProperty("aws.stage.dataload.eDGValueCsv");
		String configFile = System.getProperty("configurationFile");
		String razorEnv = System.getProperty("razor_env_path");
		String validationHeader = "BEGIN: RAZOR DATALOAD AUTOMATION TESTS IN " + razorEnv.toUpperCase() + " ON " + new Date().toString();
		int validationHeaderPad = getHeaderPadding(validationHeader);
		String validationHeaderString = StringUtils.leftPad(validationHeader, validationHeaderPad, "");
		String subHeader1 = "Table Name: " + tableName + " | Mapping File: " + mappingFile.substring(mappingFile.lastIndexOf("/") + 1) + " | Config File: "
				+ configFile.substring(configFile.lastIndexOf("/") + 1);
		int subHeaderPad1 = getHeaderPadding(subHeader1);
		String subHeaderString1 = StringUtils.leftPad(subHeader1, subHeaderPad1, "");

		String subHeader2 = "Mapping File: " + mappingFile.substring(mappingFile.lastIndexOf("/") + 1);
		int subHeaderPad2 = getHeaderPadding(subHeader2);
		String subHeaderString2 = StringUtils.leftPad(subHeader2, subHeaderPad2, "");

		String subHeader3 = "Config File: " + configFile.substring(configFile.lastIndexOf("/") + 1);
		int subHeaderPad3 = getHeaderPadding(subHeader3);
		String subHeaderString3 = StringUtils.leftPad(subHeader3, subHeaderPad3, "");
		logger.info(starFiller);
		logger.info(validationHeaderString);
		logger.info(subHeaderString1);
		logger.info(subHeaderString2);
		logger.info(subHeaderString3);
		logger.info(starFiller);
		logger.info("");
		logger.info("");
	}

	public void endValidations(String tableName) {
		String razorEnv = System.getProperties().getProperty("razor_env_path");
		String validationHeader = "END: RAZOR DATALOAD AUTOMATION TESTS IN " + razorEnv.toUpperCase() + " ON " + new Date().toString();
		int validationHeaderPad = getHeaderPadding(validationHeader);
		String validationHeaderString = StringUtils.leftPad(validationHeader, validationHeaderPad, "");
		String subHeader = "Table Name: " + tableName;
		int subHeaderPad = getHeaderPadding(subHeader);
		String subHeaderString = StringUtils.leftPad(subHeader, subHeaderPad, "");
		logger.info("");
		logger.info("");
		logger.info(starFiller);
		logger.info(validationHeaderString);
		logger.info(subHeaderString);
		logger.info(starFiller);
	}
	// methods called from Autosys for Source to Target validations

	public int validateSTRecordCounts(String tableName, String parentTable, String criticalFlag, String isRefCheckReq, String isTestCaseReq, int testcaseId) {
		int errorCode = 0;
		if ("N".equalsIgnoreCase(isTestCaseReq)) {
			logger.info(" ");
			logger.info("	****** SOURCE TO TARGET RECORD COUNTS CHECK IS NOT REQUIRED FOR THIS TABLE  ********   ");
			logger.info(" ");
		} else {
			errorCode = targetSourceValidations(tableName, "TABLE_REC_COUNT", criticalFlag);
		}
		return errorCode;
	}

	public int validateSTColumnNullCounts(String tableName, String parentTable, String criticalFlag, String isRefCheckReq, String isTestCaseReq, int testcaseId) {
		int errorCode = 0;
		if ("N".equalsIgnoreCase(isTestCaseReq)) {
			logger.info(" ");
			logger.info("	****** SOURCE TO TARGET COLUMN NULL COUNTS CHECK IS NOT REQUIRED FOR THIS TABLE  ********   ");
			logger.info(" ");
		} else {
			errorCode = targetSourceValidations(tableName, "COLUMN_NULL_COUNT", criticalFlag);
		}

		return errorCode;
	}

	public int validateSTColumnData(String tableName, String parentTable, String criticalFlag, String isRefCheckReq, String isTestCaseReq, int testcaseId) {
		int errorCode = 0;
		if ("N".equalsIgnoreCase(isTestCaseReq)) {
			logger.info(" ");
			logger.info("	****** SOURCE TO TARGET COLUMN SPOT CHECK IS NOT REQUIRED FOR THIS TABLE  ********   ");
			logger.info(" ");
		} else {
			errorCode = targetSourceValidations(tableName, "COLUMN_NULL_COUNT", criticalFlag);
		}
		return errorCode;
	}

	/**
	 * This method validates source and target data for any given source
	 * 
	 * @param source
	 * @param srcSchemaPrefix
	 * @param validationType
	 */
	public int targetSourceValidations(String source, String validationType, String criticalFlag) {

		this.source = source;
		trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");
		List<String> srcExcludes = new ArrayList<String>(Arrays.asList("", "N/A", "NA"));
		List<String> trgExcludes = new ArrayList<String>(
				Arrays.asList("LN", "PROP", "PROP_VALU", "PROP_DRVD_VALU", "PROP_EXP_CLM", "PROP_EXP_CLM_LINE_ITM", "PROP_EXP_CLM_PRE_APRVL", "PRTY_VNDR_INFO", "PROP_EXP_CLSFN_SMRY"));
		SourceDTO sourceDTO = null;
		String srcEnv = env.getRequiredProperty("src.dbconn.env").toUpperCase();
		String trgEnv = env.getRequiredProperty("aws.stage.dbconn.username").substring(3).toUpperCase();

		try {
			sourceDTO = ExcelUtils.processExcel(mappingFile, null, source);

		} catch (Exception e) {
			logger.error("FAILURE: Error reading mapping data for the source " + source + " from Mapping File " + mappingFile, e);
		}

		QueryConditionsDTO queryConditions = null;
		List<StringBuilder> errorList = new ArrayList<StringBuilder>();
		// TODO: Need to add implementation <input from business is pending>
		boolean isCritical = false;
		StringBuilder errorString = new StringBuilder();
		StringBuilder criticalErrorString = new StringBuilder();
		int errorCount = 0;
		int errorCode = 0;
		String validationHeader = "";
		String validationSubHeader = "";
		int validationHeaderPad = 0;
		int validationSubHeaderPad = 0;
		String validationHeaderString = "";
		String validationSubHeaderString = "";
		Map<String, List<MappingDTO>> sourceMap = sourceDTO.getSourceMap();
		String srcTypeCode = null;
		boolean isTypeCodeValid = false;
		boolean printHeader = true;
		for (String stgSource : sourceMap.keySet()) {
			String srcTable = null;
			String trgTable = null;
			String srcKey = null;
			String trgKey = null;
			List<String> srcColumns;
			List<String> trgColumns;
			String fromClause = null;
			String selectClause = null;
			if (stgSource.indexOf(" ") > 0 || stgSource.indexOf("/") > 0) {
				srcTypeCode = stgSource.replace(" ", "_").replace("/", "_");
			} else {
				srcTypeCode = stgSource;
			}
			for (SourceNameTypeCode typeCode : SourceNameTypeCode.values()) {
				if (typeCode.name().equals(srcTypeCode)) {
					String srcSchemaPrefix = SourceNameTypeCode.valueOf(srcTypeCode.toUpperCase()).getLabel();
					String srcSchemaString = srcSchemaPrefix + ".dbconn.schema";
					srcSchema = env.getRequiredProperty(srcSchemaString);
					DataSource dataSource = (DataSource) applicationContext.getBean("srcDataSource", srcSchemaPrefix);
					srcDB = new JdbcTemplate(dataSource);
					srcDB.setResultsMapCaseInsensitive(true);
					isTypeCodeValid = true;
					break;
				}
			}
			if (!isTypeCodeValid) {
				logger.info(stgSource + " is not a valid source. Skipping....");
				continue;
			}
			try {
				queryConditions = XmlUtils.getSourceConditions(source, srcSchema, xmlFileName);
			} catch (Exception e) {
				logger.error("FAILURE: Unable to Read Source Condititons for the source " + source, e);
			}
			List<MappingDTO> mappingDTOList = sourceMap.get(stgSource);

			for (MappingDTO mappingDTO : mappingDTOList) {
				StringBuilder altSrcTable = new StringBuilder();
				srcTable = mappingDTO.getSrcTableName().trim();
				if (srcTable.indexOf("\n") != -1) {
					String[] srcTables = srcTable.split("\n");
					for (int i = 0; i < srcTables.length; i++) {
						if (i < srcTables.length - 1) {
							altSrcTable.append(srcTables[i].trim() + ",");
						} else
							altSrcTable.append(srcTables[i].trim());
					}
					srcTable = altSrcTable.toString();
				}

				trgTable = mappingDTO.getTrgTableName().trim();
				srcColumns = mappingDTO.getSrcColumns();
				trgColumns = mappingDTO.getTrgColumns();
				String key = srcTable.toUpperCase() + ":" + trgTable.toUpperCase();
				QueryParametersDTO queryParameters = null;
				if (queryConditions.getSource() != null && queryConditions.getSourceContditions().get(key) != null) {
					queryParameters = queryConditions.getSourceContditions().get(key);
					selectClause = queryParameters.getSelectClause();
					fromClause = queryParameters.getFromClause();
					srcKey = queryParameters.getSourceKey();
					trgKey = queryParameters.getTargetKey();
				} else {
					continue;
				}
				fromClause = fromClause == null ? null : fromClause.replaceAll("\\s+", " ");

				if (!srcExcludes.contains(srcTable) && !trgExcludes.contains(trgTable)) {
					if (validationType.equals("TABLE_REC_COUNT")) {
						if (printHeader) {
							validationHeader = "SOURCE TO TARGET VALIDATIONS :: RECORD COUNTS FOR " + source;
							validationHeaderPad = getHeaderPadding(validationHeader);
							validationHeaderString = StringUtils.leftPad(validationHeader, validationHeaderPad, "");
							logger.info(starFiller);
							logger.info(validationHeaderString);
							logger.info(starFiller);
						}
						printHeader = false;
						errorList = validateTableRecordCounts(isCritical, srcTable, trgTable, srcColumns, trgColumns, fromClause);
					}
					if (validationType.equals("COLUMN_NULL_COUNT")) {
						if (printHeader) {
							validationHeader = "SOURCE TO TARGET VALIDATIONS :: COLUMN NULL COUNTS FOR " + source;
							validationHeaderPad = getHeaderPadding(validationHeader);
							validationHeaderString = StringUtils.leftPad(validationHeader, validationHeaderPad, "");
							logger.info(starFiller);
							logger.info(validationHeaderString);
							logger.info(starFiller);
						}
						printHeader = false;
						errorList = validateColumnNullCounts(isCritical, srcTable, trgTable, srcColumns, trgColumns, fromClause);
					}
					if (validationType.equals("DATA_SPOT_CHECK")) {
						if (printHeader) {
							validationHeader = "SOURCE TO TARGET VALIDATIONS :: SPOT CHECK ON SAMPLE DATA ";
							validationHeaderPad = getHeaderPadding(validationHeader);
							validationHeaderString = StringUtils.leftPad(validationHeader, validationHeaderPad, "");
							validationSubHeader = "Staging Environment: " + trgEnv + ", Soruce Environment: " + srcEnv;
							validationSubHeaderPad = getHeaderPadding(validationSubHeader);
							validationSubHeaderString = StringUtils.leftPad(validationSubHeader, validationSubHeaderPad, "");
							logger.info(starFiller);
							logger.info(validationHeaderString);
							logger.info(validationSubHeaderString);
							logger.info(starFiller);
						}
						printHeader = false;
						if ((srcKey != null && !srcKey.isEmpty()) && (trgKey != null && !trgKey.isEmpty())) {
							errorList = spotCheckOnStagingColumData(isCritical, srcTable, trgTable, srcKey, trgKey, srcColumns, trgColumns, fromClause);
							logger.info("	***  SPOT CHECK IS NOT ACTIVATED ON THIS SOURCE ***");
						}
					}
					if (errorList.size() > 0) {
						errorString.append(errorList.get(0).toString());
						if (!errorString.toString().isEmpty()) {
							if (isCritical && !errorList.get(1).toString().isEmpty()) {
								criticalErrorString.append(errorList.get(1).toString());
							}
						}
					}
				}
			}
		}
		if (errorString.length() > 0) {
			errorCount = errorString.toString().split("\n").length;
			String errorCountHeader = "Error Count: " + errorCount;
			int errorCountHeaderPad = getHeaderPadding(errorCountHeader);
			String errorCountHeaderString = StringUtils.leftPad(errorCountHeader, errorCountHeaderPad, "");
			logger.error("\n" + starFiller + "\n" + errorSummaryBeginString + "\n" + errorCountHeaderString + "\n" + starFiller + "\n" + errorString.toString() + "\n" + starFiller + "\n"
					+ errorSummaryEndString + "\n" + starFiller + "\n");

			if (!criticalErrorString.toString().isEmpty()) {
				int criticalErrorCount = criticalErrorString.toString().split("\n").length;
				String criticalErrorCountHeader = "Error Count: " + errorCount;
				int criticalErrorCountHeaderPad = getHeaderPadding(criticalErrorCountHeader);
				String criticalErrorCountHeaderString = StringUtils.leftPad(criticalErrorCountHeader, criticalErrorCountHeaderPad, "");
				String criticalErrorHeader = criticalErrorCount + " " + criticalError;
				int criticalErrorHeaderPad = getHeaderPadding(criticalErrorHeader);
				String criticalErrorHeaderString = StringUtils.leftPad(criticalErrorHeader, criticalErrorHeaderPad, "");
				logger.fatal("\n" + starFiller + "\n" + criticalErrorHeaderString + "\n" + criticalErrorCountHeaderString + "\n" + starFiller + "\n" + criticalErrorString.toString() + "\n"
						+ starFiller + "\n" + errorSummaryEndString + "\n" + starFiller + "\n");

			}
		}
		if (errorCount > 0 && criticalFlag.equalsIgnoreCase("Y")) {
			errorCode = 1;
		}

		return errorCode;
	}

	/**
	 * This method validates Record Counts of Source and Target Tables for any given source
	 * 
	 * @param isCritical
	 * @param fromClause
	 * @param trgColumns
	 * @param srcColumns
	 * @param trgTable
	 * @param srcTable
	 * @return List of errors and critical errors
	 */
	public List<StringBuilder> validateTableRecordCounts(boolean isCritical, String srcTable, String trgTable, List<String> srcColumns, List<String> trgColumns, String fromClause) {

		String sourceQuery = buildQuery(srcTable, srcSchema, null, fromClause, 1, null, null);
		String targetQuery = buildQuery(trgTable, trgSchema, null, null, 1, null, null);
		String validationSubHeader = "SOURCE TABLE: " + srcSchema + "." + srcTable + " & TARGET TABLE: " + trgSchema + "." + trgTable;
		logger.info(validationSubHeader);
		String dashFiller = StringUtils.leftPad("", validationSubHeader.length(), "-");
		logger.info(dashFiller);
		int sourceCount = 0;
		int targetCount = 0;
		StringBuilder errors = new StringBuilder();
		StringBuilder criticalErrors = new StringBuilder();
		List<StringBuilder> errorList = new ArrayList<StringBuilder>();
		String error = null;
		logger.info("Source Query: " + sourceQuery);
		logger.info("Target Query: " + targetQuery);
		try {
			sourceCount = srcDB.queryForObject(sourceQuery, int.class);
			targetCount = trgDB.queryForObject(targetQuery, int.class);
			logger.info(" ");
			logger.info("	Source Record Count: " + sourceCount);
			logger.info("	Target Record Count: " + targetCount);
			logger.info(" ");
			if (sourceCount == targetCount) {
				logger.info("SUCCESS:  Record Counts for Source Table: " + srcTable + " & Target Table: " + trgTable + " are MATCHING");
			} else {
				error = "Record Counts for Source Table: " + srcTable + " & Target Table: " + trgTable + " are NOT MATCHING";
				errors.append(error + "\n");
				logger.error("FAILURE: " + error);
				if (isCritical) {
					criticalErrors.append(error + "\n");
				}
			}
		} catch (Exception e) {
			logger.error("ERROR: An Error occured in the process.  Please check the log file", e);
		}
		errorList.add(errors);
		errorList.add(criticalErrors);
		return errorList;
	}

	/**
	 * This method validates Null Column counts in Source and Target tables
	 * 
	 * @param isCritical
	 * @param fromClause
	 * @param trgColumns
	 * @param srcColumns
	 * @param trgTable
	 * @param srcTable
	 * @return List of errors and critical errors
	 */

	public List<StringBuilder> validateColumnNullCounts(boolean isCritical, String srcTable, String trgTable, List<String> srcColumns, List<String> trgColumns, String fromClause) {
		StringBuilder errors = new StringBuilder();
		StringBuilder criticalErrors = new StringBuilder();
		List<StringBuilder> errorList = new ArrayList<StringBuilder>();
		for (int i = 0; i < srcColumns.size(); i++) {
			String srcColumn = srcColumns.get(i).trim();
			// TODO: Need to handle this later
			String trgColumn = trgColumns.get(i).trim();
			if (source.equals("ARROW") && (trgTable.equals("LN_CMNTS") || trgTable.equals("LN_CMNTS_FILTR"))) {
				srcColumn = "translate((COALESCE(LOANCMTNAMECOMMENT1, ' ') ||' '|| COALESCE(LOANCMTNAMECOMMENT2, ' ') ||' '|| COALESCE(LOANCMTNAMECOMMENT3, ' ')), chr(10)||chr(13), ' ')";
			}
			if (!(trgTable.equals("LN_CMNTS") || trgTable.equals("LN_CMNTS_FILTR"))) {
				logger.info(emptyLine);
				String validationSubHeader = "SOURCE TABLE: " + srcSchema + "." + srcTable + " & TARGET TABLE: " + trgSchema + "." + trgTable;
				logger.info(validationSubHeader);
				String dashFiller = StringUtils.leftPad("", validationSubHeader.length(), "-");
				logger.info(dashFiller);
				String sourceQuery = buildQuery(srcTable, srcSchema, srcColumn, fromClause, 2, null, null);
				logger.info("Source Query: " + sourceQuery);
				String targetQuery = buildQuery(trgTable, trgSchema, trgColumn, null, 2, null, null);
				logger.info("Target Query: " + targetQuery);
				int sourceCount = 0;
				int targetCount = 0;
				try {
					sourceCount = srcDB.queryForObject(sourceQuery, int.class);
					targetCount = trgDB.queryForObject(targetQuery, int.class);
					logger.info("Source NULL Count: " + sourceCount);
					logger.info("Target NULL Count: " + targetCount);
					if (sourceCount == targetCount) {
						logger.info("SUCCESS: NULL counts for " + srcTable + "." + srcColumn + " & " + trgTable + "." + trgColumn + " are matching");
					} else {
						String error = "NULL counts for " + srcTable + "." + srcColumn + " & " + trgTable + "." + trgColumn + " are NOT matching";
						logger.error("FAILURE: " + error);
						errors.append(error + "\n");
						if (isCritical) {
							criticalErrors.append(error + "\n");
						}
					}
				} catch (Exception e) {
					logger.error("ERROR: An Error occured in the process.  Please check the log file", e);
				}
			}
		}
		errorList.add(errors);
		errorList.add(criticalErrors);
		return errorList;
	}

	/**
	 * This method Validates data in the source and target columns for the same record using the primary key. Only a sample of random records are validated
	 * 
	 * @param isCritical
	 * @param fromClause
	 * @param trgColumns
	 * @param srcColumns
	 * @param trgKey
	 * @param srcKey
	 * @param trgTable
	 * @param srcTable
	 * @return List of error and critical errors
	 */
	public List<StringBuilder> spotCheckOnStagingColumData(boolean isCritical, String srcTable, String trgTable, String srcKey, String trgKey, List<String> srcColumns, List<String> trgColumns,
			String fromClause) {
		StringBuilder errors = new StringBuilder();
		StringBuilder criticalErrors = new StringBuilder();
		List<StringBuilder> errorList = new ArrayList<StringBuilder>();
		logger.info(emptyLine);

		for (int i = 0; i < srcColumns.size(); i++) {
			String srcColumn = srcColumns.get(i).trim();
			if (srcColumn.equalsIgnoreCase("DERIVATION")) {
				continue;
			}
			if (srcColumn.indexOf(".") != -1) {
				String[] srcColumnSplit = srcColumn.split("\\.");
				if (srcColumnSplit.length > 1)
					srcColumn = srcColumnSplit[1];
			}

			String metadataColumn = null;
			boolean isEnum = false;
			// TODO: Need to handle this later
			String trgColumn = trgColumns.get(i).trim();
			String validationSubHeader = "SOURCE COLUMN: " + srcSchema + "." + srcTable + "." + srcColumn + " & TARGET COLUMN: " + trgSchema + "." + trgTable + "." + srcColumn;
			logger.info(emptyLine);
			logger.info(validationSubHeader);
			String dashFiller = StringUtils.leftPad("", validationSubHeader.length(), "-");
			logger.info(dashFiller);
			if (!(trgTable.equals("LN_CMNTS") || trgTable.equals("LN_CMNTS_FILTR"))) {
				if (source.equals("ARROW") && (trgTable.equals("LN_CMNTS"))) {
					srcColumn = "translate((COALESCE(LOANCMTNAMECOMMENT1, ' ') ||' '|| COALESCE(LOANCMTNAMECOMMENT2, ' ') ||' '|| COALESCE(LOANCMTNAMECOMMENT3, ' ')), chr(10)||chr(13), ' ')";
				}
				if (source.equals("ARROW") && trgTable.equals("LN_CMNTS_FILTR")) {
					srcColumn = "CMNT_TEXT";
					metadataColumn = "translate((COALESCE(LOANCMTNAMECOMMENT1, ' ') ||' '|| COALESCE(LOANCMTNAMECOMMENT2, ' ') ||' '|| COALESCE(LOANCMTNAMECOMMENT3, ' ')), chr(10)||chr(13), ' ')";

				} else {
					metadataColumn = srcColumn;
				}
				String tableName = "";
				String columnType = "";
				boolean isTypeCode = false;
				String srcColumnText = null;
				String trgColumnText = null;
				int trgRowCount = 0;
				StringBuilder trgRowCountQuery = new StringBuilder();
				StringBuilder keyValQuery = new StringBuilder();

				trgRowCountQuery.append("SELECT COUNT (*) FROM " + trgSchema + "." + trgTable + " WHERE " + trgColumn + " IS NOT NULL");

				try {
					trgRowCount = trgDB.queryForObject(trgRowCountQuery.toString(), int.class);
				} catch (Exception e) {
					// e.printStackTrace();
					// logger.error("ERROR: An Error occured in the process. Please check the log file", e);
					logger.error("ERROR: An Error occured in the process.  Please check the log file", e);
				}

				for (int j = 0; j < 1; j++) {
					if (!tableName.equalsIgnoreCase(srcTable)) {
						String query = "SELECT " + metadataColumn + " FROM " + srcSchema + "." + srcTable;
						// logger.info("################### Metadata Query: " + query);
						SQLColumn srcSQLColumn = loadMetadata(srcDB, query, srcTable);
						tableName = srcSQLColumn.getTableName();
						isTypeCode = CsvUtils.isTypeCode(srcTable + "." + srcColumn, csvFileName);
						columnType = isTypeCode ? "VARCHAR2" : srcSQLColumn.getColumnType();
					}

					double factor = Math.random();
					int rowNumber = (int) Math.round(factor * trgRowCount);
					keyValQuery.append("SELECT " + trgKey + " FROM " + trgSchema + "." + trgTable);
					keyValQuery.append(" limit 1 offset " + rowNumber);
					String keyVal = "";
					try {
						keyVal = trgDB.queryForObject(keyValQuery.toString(), String.class);
					} catch (Exception e) {
						logger.info("ERROR: An Error occured in getting the data for the key.  Please check the log file", e);

					}
					String targetQuery = buildQuery(trgTable, trgSchema, trgColumn, null, 7, trgKey, keyVal);
					logger.info("********* Target Query: " + targetQuery);
					List<String> trgQueryResult = new ArrayList<String>();
					try {
						trgQueryResult = (List<String>) trgDB.queryForList(targetQuery.toString(), String.class);
					} catch (Exception e) {
						logger.error("************** ERROR Excuting the Target Query" + e.toString());
					}

					// Check to see if the Result List has only null values
					if (trgQueryResult != null && !StreamSupport.stream(trgQueryResult.spliterator(), true).allMatch(o -> o == null)) {
						Collections.sort(trgQueryResult);
					}
					logger.info("******** TARGET RESULT " + trgQueryResult.toString());
					String sourceQuery = buildQuery(srcTable, srcSchema, srcColumn, fromClause, 7, srcKey, keyVal);
					logger.info("********* Source Query: " + sourceQuery);
					List<String> srcQueryResult = new ArrayList<String>();
					try {
						srcQueryResult = (List<String>) srcDB.queryForList(sourceQuery.toString(), String.class);
					} catch (Exception e) {
						logger.error("************** ERROR Excuting the Source Query" + e.toString());
					}
					List<String> srcQueryEnumResult = new ArrayList<String>();
					Map<String, String> eDGLookUp = CsvUtils.getSourceEDGLookUp(csvFileName);
					for (String columnText : srcQueryResult) {
						String lookUpKey = srcTable + ":" + srcColumn + ":" + columnText;
						String eDGValue = eDGLookUp.get(lookUpKey);
						if (eDGValue != null) {
							srcQueryEnumResult.add(eDGValue);
							isEnum = true;
						}
					}

					if (!srcQueryEnumResult.isEmpty()) {
						srcQueryResult = srcQueryEnumResult;
					}
					// Check to see if the Result List has only null values
					if (srcQueryResult != null && !StreamSupport.stream(srcQueryResult.spliterator(), true).allMatch(o -> o == null)) {
						Collections.sort(srcQueryResult);
					}
					logger.info("********  SOURCE RESULT: " + srcQueryResult.toString());

					String srcColumnTextResult = null;
					String trgColumnTextResult = null;
					if (trgQueryResult.size() == srcQueryResult.size()) {
						for (int i1 = 0; i1 < trgQueryResult.size(); i1++) {
							srcColumnTextResult = srcQueryResult.get(i1);
							trgColumnTextResult = trgQueryResult.get(i1);
							if (columnType.equals("DATE") && srcColumnTextResult != null) {
								DateFormat srcInputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
								DateFormat trgInputFormat = new SimpleDateFormat("yyyy-MM-dd");
								DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
								Date trgDate = null;
								Date srcDate = null;
								try {
									srcDate = srcInputFormat.parse(srcColumnTextResult);
									trgDate = trgInputFormat.parse(trgColumnTextResult);
								} catch (ParseException e1) {
									logger.error("ERROR: Can not parse the Source Column: " + srcColumn + " to date.  Please check the log file", e1);
								}
								srcColumnText = srcColumnTextResult == null ? "NULL" : "" + outputFormat.format(srcDate);
								trgColumnText = trgColumnTextResult == null ? "NULL" : "" + outputFormat.format(trgDate);
							} else if (columnType.equals("NUMBER") && srcColumnTextResult != null && !isEnum) {
								DecimalFormat df = new DecimalFormat("#.00");
								srcColumnText = srcColumnTextResult.indexOf(".") != -1 || trgColumnTextResult.indexOf(".") != -1 ? df.format(new Double(srcColumnTextResult)) : srcColumnTextResult;
								if (trgColumnTextResult.matches("[0-9]+")) {
									trgColumnText = srcColumnTextResult.indexOf(".") != -1 || trgColumnTextResult.indexOf(".") != -1 ? new Double(trgColumnTextResult).toString() : trgColumnTextResult;
								} else {
									trgColumnText = trgColumnTextResult;
								}

							} else {
								srcColumnText = srcColumnTextResult == null ? "NULL" : "" + srcColumnTextResult;
								trgColumnText = trgColumnTextResult == null ? "NULL" : "" + trgColumnTextResult;
							}

							if (trgTable.equals("LN_CMNTS_FILTR") && srcColumn.equals("CMNT_TEXT")) {
								String srcColumnText1 = getMatching(srcColumnText);
								srcColumnText = srcColumnText1;
							}
							String srcColumnTextLog = "Source Column " + srcColumn + " Text: " + srcColumnText;
							String trgColumnTextLog = "Target Column " + trgColumn + " Text: " + trgColumnText;
							logger.info(srcColumnTextLog);
							logger.info(trgColumnTextLog);

							if (srcColumnText.equals(trgColumnText)) {
								logger.info("SUCCESS: Data in " + srcTable + "." + srcColumn + " & " + trgTable + "." + trgColumn + " is matching");
							} else {
								String error = "Data in " + srcTable + "." + srcColumn + " & " + trgTable + "." + trgColumn + " is NOT matching. " + srcColumnTextLog + " AND " + trgColumnTextLog;
								logger.error("FAILURE: " + error);
								errors.append(error + "\n");
								if (isCritical) {
									criticalErrors.append(error + "\n");
								}
							}
						}
					} else {
						String error = "Nmuber of Records returned by Soure Query for " + srcTable + "." + srcColumn + "( " + srcQueryResult.size() + " )" + " & and Target Query for " + trgTable + "."
								+ trgColumn + "( " + trgQueryResult.size() + " )" + " where " + trgKey + " = " + keyVal + " are NOT EQUAL";
						logger.error("FAILURE: " + error);
						errors.append(error + "\n");
						if (isCritical) {
							criticalErrors.append(error + "\n");
						}
					}
				}
			}
		}
		errorList.add(errors);
		errorList.add(criticalErrors);
		return errorList;
	}

	/**
	 * This method validates all staging data base columns to check if the data is null for all records
	 */
	public void validateTargetNullCounts() {
		Map<String, List<String>> trgTableColumMap = new HashMap<String, List<String>>();
		String parentTable = "";
		String isRefCheckReq = "";
		String isTestCaseReq = "";
		try {
			trgTableColumMap = XmlUtils.getTargetTables(xmlFileName);
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (String trgTable : trgTableColumMap.keySet()) {
			//System.out.println(trgTable);
			for (String columnName : trgTableColumMap.get(trgTable)) {
				//System.out.println("    " + columnName);
			}
			// should change some testcaseid instead of 0
			validateTargetNullCounts(trgTable, parentTable, "N", isRefCheckReq, isTestCaseReq, 0);
		}
	}

	/**
	 * This method checks to see if any of the target table columns have null values for all the records
	 * 
	 * @param tableName
	 * @param failOnCritical
	 */
	public int validateTargetNullCounts(String tableName, String parentTable, String criticalFlag, String isRefCheckReq, String isTestCaseReq, int testcaseId) {
		// String trgTable = tableName;
		int errorCode = 0;
		if ("N".equalsIgnoreCase(isTestCaseReq)) {
			logger.info("");
			logger.info("***** Validate Target Null Counts Check is NOT REQUIRED for this table *****");
			logger.info("");
		} else {
			logBuffer = new StringBuffer();
			errorBuffer = new StringBuffer();
			criticalErrorBuffer = new StringBuffer();
			SourceDTO sourceDTO = null;
			boolean isValidSource = false;
			int errorCount = 0;

			Map<String, Map<String, String>> targetConditions = null;
			String validationHeader = "VALIDATE STAGING TABLE COLUMNS FOR NULLS";
			int validationHeaderPad = getHeaderPadding(validationHeader);
			String validationHeaderString = StringUtils.leftPad(validationHeader, validationHeaderPad, "");
			String subHeader = "Table Name: " + tableName;
			int subHeaderPad = getHeaderPadding(subHeader);
			String subHeaderString = StringUtils.leftPad(subHeader, subHeaderPad, "");
			// logger.info(starFiller);
			String underLine = StringUtils.leftPad("", validationHeader.length(), "=");
			String underLineString = StringUtils.leftPad(underLine, validationHeaderPad, "");
			logger.info(underLineString);
			logger.info(validationHeaderString);
			logger.info(subHeaderString);
			logger.info(underLineString);
			try {
				sourceDTO = ExcelUtils.processExcel(mappingFile, null, tableName);
			} catch (Exception e) {
				logBuffer.append("ERROR: An Error occured while reading Excel file.  Please check the error logs;");
				logBuffer.append(e + ";");
			}
			try {
				targetConditions = XmlUtils.getTargetConditions(xmlFileName);
			} catch (Exception e) {
				logBuffer.append("ERROR: An Error occured while reading XML file.  Please check the error logs;");
				logBuffer.append(e + ";");
			}

			if (sourceDTO == null) {
				logger.error("Table " + tableName + " is not found in the mapping spreadsheet");
				return 0;
			}
			String trgSchema = env.getRequiredProperty("aws.stage.dbconn.schema");
			trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");

			final int MYTHREADS = 30;
			ExecutorService executor = Executors.newFixedThreadPool(MYTHREADS);
			Map<String, List<MappingDTO>> sourceMap = sourceDTO.getSourceMap();
			String srcTypeCodeName = null;
			List<Enum> validSourceList = SourceNameTypeCode.valuesList();
			for (String stgSource : sourceMap.keySet()) {
				if (stgSource.indexOf(" ") > 0) {
					srcTypeCodeName = stgSource.replace(" ", "_");
				} else {
					srcTypeCodeName = stgSource;
				}

				if (validSourceList.contains(srcTypeCodeName)) {
					String srcSchemaPrefix = SourceNameTypeCode.valueOf(srcTypeCodeName.toUpperCase()).getLabel();
					String srcSchemaString = srcSchemaPrefix + ".dbconn.schema";
					srcSchema = env.getRequiredProperty(srcSchemaString);
					DataSource dataSource = (DataSource) applicationContext.getBean("srcDataSource", srcSchemaPrefix);
					srcDB = new JdbcTemplate(dataSource);
					srcDB.setResultsMapCaseInsensitive(true);
					isValidSource = true;
				}
				List<MappingDTO> mappingDTOList = sourceMap.get(stgSource);
				for (MappingDTO mappingDTO : mappingDTOList) {
					String srcColNotNullCntQuery = null;
					String trgTable = mappingDTO.getTrgTableName().trim();
					String srcTable = mappingDTO.getSrcTableName().trim();
					Map<String, String> columnConditions = targetConditions.get(tableName);
					List<String> trgColumns = mappingDTO.getTrgColumns();
					List<String> srcColumns = mappingDTO.getSrcColumns();
					String tableRowQuery = buildQuery(trgTable, trgSchema, null, null, 1, null, null);
					int totalRecords = trgDB.queryForObject(tableRowQuery, int.class);
					for (int i = 0; i < trgColumns.size(); i++) {
						// ToDo: Convert this to a Map
						List<String> queryList = new ArrayList<String>();
						String trgColumn = trgColumns.get(i).trim();
						String srcColumn = srcColumns.get(i).trim();
						String trgColNotNullCntQuery = buildQuery(trgTable, trgSchema, trgColumn, null, 4, null, null);
						srcColNotNullCntQuery = isValidSource ? buildQuery(srcTable, srcSchema, srcColumn, null, 4, null, null) : null;
						String isSrcColumnRequired = "N";
						// String colAllEmptyCntQuery = buildQuery(trgTable, trgSchema, trgColumn, null,null,null, 6, 0);
						queryList.add(trgTable);
						queryList.add(trgColumn);
						queryList.add(trgColNotNullCntQuery);
						queryList.add(tableName);
						queryList.add(srcTable);
						queryList.add(srcColumn);
						queryList.add(srcColNotNullCntQuery);
						String trgColumnConditionString = columnConditions == null ? null : columnConditions.get(trgColumn);
						if (trgColumnConditionString != null) {
							// ToDo: Need to clean up trgColumnConditionString as there is only isSrcColumnRequired is required - remove ':' from the the string
							String[] trgColumnConditions = trgColumnConditionString.split(":");
							isSrcColumnRequired = trgColumnConditions[0];
						}
						if (isSrcColumnRequired != null && isSrcColumnRequired.equalsIgnoreCase("Y")) {
							String trgColNullCntQuery = buildQuery(trgTable, trgSchema, trgColumn, null, 3, null, null);
							queryList.add(trgColNullCntQuery);
						}
						Runnable worker = new AllNullColumnsRunnable(queryList, totalRecords, criticalFlag, tableName, testcaseId);
						executor.execute(worker);
					}
				}
			}
			executor.shutdown();
			// Wait until all threads are finished
			while (!executor.isTerminated()) {

			}
			String[] logStrings = logBuffer.toString().split(";");
			for (int i = 0; i < logStrings.length; i++) {
				logger.info(logStrings[i]);
			}
			if (!errorBuffer.toString().isEmpty()) {
				errorCount = errorBuffer.toString().split(";").length;

				String errorCountHeader = "Error Count: " + errorCount;
				int errorCountHeaderPad = getHeaderPadding(errorCountHeader);
				String errorCountHeaderString = StringUtils.leftPad(errorCountHeader, errorCountHeaderPad, "");

				errorType = "ERROR";
				errorMessage = "Null columns found";
				errorTableOperations(tableName, testcaseId, errorType, errorMessage);
				logger.error("\n" + starFiller + "\n" + errorSummaryBeginString + "\n" + errorCountHeaderString + "\n" + starFiller + "\n" + errorBuffer.toString() + "\n" + starFiller + "\n"
						+ errorSummaryEndString + "\n" + starFiller + "\n");
				if (!criticalErrorBuffer.toString().isEmpty() && criticalFlag.equalsIgnoreCase("Y")) {
					int criticalErrorCount = criticalErrorBuffer.toString().split(";").length;
					logger.fatal("\n******** " + criticalErrorCount + " CRITICAL ERROR(S) FOUND ***********\n" + criticalErrorBuffer.toString());
				}
			}
			if (errorCount > 0 && criticalFlag.equalsIgnoreCase("Y")) {
				errorCode = 1;
			}
		}
		return errorCode;
	}

	public static class AllNullColumnsRunnable implements Runnable {

		private List<String> queryList;
		private int totalRecords;
		private String isCritical;
		private String tableName;
		private int testcaseId;

		AllNullColumnsRunnable(List<String> queryList, int totalRecords, String criticalFlag, String tableName, int testcaseId) {
			this.queryList = queryList;
			this.totalRecords = totalRecords;
			this.isCritical = criticalFlag;
			this.tableName = tableName;
			this.testcaseId = testcaseId;
		}

		@Override
		public void run() {
			int trgColNotNullCnt = 0;
			int srcColNotNullCnt = 0;
			int colNullCnt = 0;
			String filler = StringUtils.leftPad(" ", 67);
			String filler1 = StringUtils.leftPad(" ", 76);

			try {
				trgColNotNullCnt = trgDB.queryForObject(queryList.get(2), int.class);
				String srcColNullCntQuery = queryList.get(6);
				String srcMessageString = "";
				if (trgColNotNullCnt == 0) {
					if (srcColNullCntQuery != null) {
						srcColNotNullCnt = srcDB.queryForObject(srcColNullCntQuery, int.class);
						if (srcColNotNullCnt == 0) {
							srcMessageString = filler1 + "SOURCE " + queryList.get(3) + " ALSO has ALL records for corresponding column " + queryList.get(4) + "." + queryList.get(5)
									+ " have Null values \n" + filler + "(Query:: " + queryList.get(6) + ");";
						} else {
							srcMessageString = filler1 + "SOURCE " + queryList.get(3) + " for corresponding column " + queryList.get(4) + "." + queryList.get(5) + " has " + srcColNotNullCnt
									+ " Non Null records \n" + filler + "(Query:: " + queryList.get(6) + ");";
							errorMessage = "In target column " + queryList.get(1) + " we have all NULL values while source column " + queryList.get(5) + " has some values";
							errorType = "ERROR";
							if (isCritical.equalsIgnoreCase("Y")) {
								errorType = "CRITICAL";
							}
							errorTableOperations(tableName, testcaseId, errorType, errorMessage);
						}
					}
					String failureString = "All records of table " + queryList.get(0) + " has NULL values for column " + queryList.get(1)
							+ " and query is not available to validate it with source column\n" + filler + "(Query:: " + queryList.get(2) + ")\n";
					errorType = "ERROR";
					errorMessage = "All records of table " + queryList.get(0) + " has NULL values for column " + queryList.get(1) + " and query is not available to validate it with source column";
					String error = "FAILURE: " + failureString + srcMessageString;
					logBuffer.append(error);
					errorBuffer.append(error);
					if (isCritical.equalsIgnoreCase("Y")) {
						criticalErrorBuffer.append(error);
						errorType = "CRITICAL";
					}
					errorTableOperations(tableName, testcaseId, errorType, errorMessage);

				} else {
					double fraction = ((double) trgColNotNullCnt / totalRecords);
					DecimalFormat twoDForm = new DecimalFormat("#.##");
					double percentLoaded = Double.valueOf(twoDForm.format(fraction * 100));
					logBuffer.append("Not Null Column Count for Column: " + queryList.get(0) + "." + queryList.get(1) + " :: " + trgColNotNullCnt + " out of " + totalRecords
							+ " records in the table (" + percentLoaded + " Percent Loaded)" + "\n" + filler + "(Query:: " + queryList.get(2) + ");");
				}
				if (queryList.size() == 99) {
					colNullCnt = trgDB.queryForObject(queryList.get(3), int.class);

					if (colNullCnt != 0) {
						logBuffer.append(" ");
						logBuffer.append("Null Column Count for Column: " + queryList.get(3) + " :: " + colNullCnt + ";");
						String error = "There should not be NULL values in the Column: " + queryList.get(1) + " as the corresponding Source coloumn is Not Nullable;";
						logBuffer.append("FAILURE: " + error);
						errorBuffer.append(error);
						if (isCritical.equalsIgnoreCase("Y")) {
							criticalErrorBuffer.append(error);
						}
					}
				}
			} catch (Exception e) {
				logBuffer.append("ERROR: An Error occured in the process.  Please check the log file;");
				logBuffer.append(e + ";");
			}
		}
	}

	/**
	 * This method validates referential integrity between the parent and child tables in the target staging database
	 * 
	 * @param parentTable
	 * 
	 */
	public int validateBusinessConditions(String childTable, String parentTable, String criticalFlag, String isRefCheckReq, String isTestCaseReq, int testcaseId) {
		int errorCode = 0;
		if ("N".equalsIgnoreCase(isTestCaseReq)) {
			logger.info(" ");
			logger.info("***** INTEGRITY CHECK IS NOT REQUIRED FOR THIS TABLE *****");
			logger.info(" ");
		} else {
			if ("Y".equalsIgnoreCase(isRefCheckReq)) {
				String validationHeader = "VALIDATE REFERENTIAL INTEGRITY IN TARGET TABLES";
				int validationHeaderPad = getHeaderPadding(validationHeader);
				String validationHeaderString = StringUtils.leftPad(validationHeader, validationHeaderPad, "");
				String subHeader = "Table Name: " + childTable + (parentTable.isEmpty() ? "" : (" Parent Table Name: " + parentTable));
				int subHeaderPad = getHeaderPadding(subHeader);
				String subHeaderString = StringUtils.leftPad(subHeader, subHeaderPad, "");
				String underLine = StringUtils.leftPad("", validationHeader.length(), "=");
				String underLineString = StringUtils.leftPad(underLine, validationHeaderPad, "");
				logger.info(underLineString);
				logger.info(validationHeaderString);
				logger.info(subHeaderString);
				logger.info(underLineString);

				if (parentTable.isEmpty()) {
					logger.info(" ");
					logger.error("***** PARENT TABLE NAME NOT FOUND. Please check the APPL_TBL_TEST_CASE_MAP table  *****");
					logger.info(" ");
				} else {
					if (parentTable.indexOf(",") != -1) {
						String[] parentTableArray = splitTableNames(parentTable);
						for (String parentTableName : parentTableArray) {
							int retVal = validateIntegrity(childTable, parentTableName, criticalFlag, testcaseId);
							if (errorCode == 0 && retVal != 0)
								errorCode = retVal;
						}
					} else {
						errorCode = validateIntegrity(childTable, parentTable, criticalFlag, testcaseId);
					}
				}
			} else {
				logger.info(" ");
				logger.info("***** INTEGRITY CHECK IS NOT REQUIRED FOR THIS TABLE *****");
				logger.info(" ");
			}
		}
		return errorCode;
	}

	private int validateIntegrity(String childTable, String parentTableName, String criticalFlag, int testcaseId) {
		Map<String, String> parentTableProps = null;
		JdbcTemplate trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");
		String trgSchema = env.getRequiredProperty("aws.stage.dbconn.schema");
		int errorCode = 0;
		try {
			parentTableProps = XmlUtils.getTableProps(parentTableName, xmlFileName);
		} catch (Exception e) {
			logger.info("ERROR: An Error occured in the process.  Please check the log file", e);
		}

		String parentKey = parentTableProps.get("primaryKey");
		StringBuilder query = new StringBuilder();
		query.append("SELECT COUNT(*) FROM (SELECT DISTINCT child." + parentKey + " FROM " + trgSchema + "." + childTable)
				.append(" child LEFT OUTER JOIN " + trgSchema + "." + parentTableName + " parent ON child." + parentKey + " = parent.")
				.append(parentKey + " WHERE parent." + parentKey + " IS NULL) AS ORPHAN");

		logger.info("Validating Integrity between PARENT: " + parentTableName + " AND CHILD: " + childTable + " ON KEY: " + parentKey);
		logger.info("Executing Query for Business Validations: " + query.toString());

		int orphanIdCount = 0;
		try {
			orphanIdCount = trgDB.queryForObject(query.toString(), int.class);
		} catch (Exception e) {
			errorCode = 2;
			logger.error("FAILURE:  Failed to execute Integrity Check Query. Please see the error log for details...", e);
		}

		if (orphanIdCount > 0) {
			errorType = "ERROR";
			if (criticalFlag.equalsIgnoreCase("Y")) {
				errorCode = 1;
				errorType = "CRITICAL";
			}
			String error = "ORPHAN IDs in child table " + childTable + " of parent table " + parentTableName + " are: " + orphanIdCount;
			errorTableOperations(childTable, testcaseId, errorType, error);
			logger.error(error);

		} else {
			logger.info("NO Orphan Records found in the Child Table " + childTable + " of Parent " + parentTableName);
		}

		return errorCode;
	}

	/**
	 * This method check for duplicate records in the identified tables that are not supposed to have duplicates in the target staging database
	 * 
	 * @param table
	 * @param criticalFlag
	 * @return
	 */
	public int validateDuplicateRecords(String table, String parentTable, String criticalFlag, String isRefCheckReq, String isTestCaseReq, int testcaseId) {
		int errorCode = 0;
		if ("N".equalsIgnoreCase(isTestCaseReq)) {
			logger.info(" ");
			logger.info("***** DUPLICATE ERROR CHECK IS NOT REQUIRED FOR THIS TABLE  *****");
			logger.info(" ");
		} else {
			Map<String, Map<String, String>> parentTableAndKeys = null;
			JdbcTemplate trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");
			String trgSchema = env.getRequiredProperty("aws.stage.dbconn.schema");
			try {
				parentTableAndKeys = XmlUtils.getParentTableAndKeyMap(xmlFileName);
			} catch (Exception e) {
				logger.error("ERROR: An Error occured in the process.  Please check the log file", e);
			}
			String validationHeader = "VALIDATE DUPLICATE RECORDS IN TARGET TABLES";
			int validationHeaderPad = getHeaderPadding(validationHeader);
			String validationHeaderString = StringUtils.leftPad(validationHeader, validationHeaderPad, "");
			String subHeader = "Table Name : " + table;
			int subHeaderPad = getHeaderPadding(subHeader);
			String subHeaderString = StringUtils.leftPad(subHeader, subHeaderPad, "");
			String underLine = StringUtils.leftPad("", validationHeader.length(), "=");
			String underLineString = StringUtils.leftPad(underLine, validationHeaderPad, "");
			logger.info(underLineString);
			logger.info(validationHeaderString);
			logger.info(subHeaderString);
			logger.info(underLineString);

			if (table != null && (parentTableAndKeys.get(table) == null || parentTableAndKeys.get(table).isEmpty())) {
				logger.info(" ");
				logger.info("***** DUPLICATE ERROR CHECK IS NOT REQUIRED FOR THIS TABLE *****");
				logger.info(" ");
			} else {
				String primaryKey = parentTableAndKeys.get(table).get("primaryKey");
				String alternateKey = parentTableAndKeys.get(table).get("alternateKey");
				String compositeKey = alternateKey == null ? primaryKey : primaryKey + "," + alternateKey;
				String dupCheckQuery = "SELECT COUNT(*) FROM (SELECT COUNT(" + primaryKey + ") FROM " + trgSchema + "." + table + " GROUP BY " + compositeKey + " HAVING COUNT(" + primaryKey
						+ ") > 1) DUPS";
				logger.info("Checking for Duplicates in the PARENT: " + table + " ON: " + primaryKey);
				logger.info("Executing Query for Duplicate Check: " + dupCheckQuery);
				String error = "";
				int duplicateCount = trgDB.queryForObject(dupCheckQuery, int.class);

				if (duplicateCount > 0) {

					errorType = "ERROR";
					error = "FAILURE: Duplicate Records in the Table " + table + " are: " + duplicateCount;
					logger.error(error);
					if (criticalFlag.equalsIgnoreCase("Y")) {
						errorCode = 1;
						errorType = "CRITICAL";
					}
					errorTableOperations(table, testcaseId, errorType, error);
				} else {
					logger.info("SUCCESS: NO Duplicate Records found in the Table " + table);
				}
			}
		}
		return errorCode;
	}

	/**
	 * This method checks to see if all the type enumerations are converted to match the EDG values when populating the stating tables
	 * 
	 * @param tableName
	 * @param criticalFlag
	 * @return
	 */
	public int validateTypeEnumerations(String tableName, String parentTable, String criticalFlag, String isRefCheckReq, String isTestCaseReq, int testcaseId) {
		int errorCode = 0;
		if ("N".equalsIgnoreCase(isTestCaseReq)) {
			logger.info(" ");
			logger.info("***** ENUMERATION CHECK IS NOT REQUIRED FOR THIS TABLE *****");
			logger.info(" ");
		} else {
			Map<String, List<String>> trgEdgValues = CsvUtils.getTargetEDGLookUp(tableName, csvFileName);
			StringBuilder errorString = new StringBuilder();
			String filler = " ";
			String reportHeader = "VALIDATE ENUMERATIONS(EDG Values) IN STAGING TABLES";
			int rptHeaderLeftPad = getHeaderPadding(reportHeader);
			String reportHeaderString = StringUtils.leftPad(reportHeader, rptHeaderLeftPad, "");
			String tableHeader = "Table Name: " + tableName;
			int tblHeaderLeftPad = Math.round((starFiller.length() - tableHeader.length()) / 2) + tableHeader.length();
			String tableHeaderString = StringUtils.leftPad(tableHeader, tblHeaderLeftPad, "");
			int errorCount = 0;
			String underLine = StringUtils.leftPad("", reportHeader.length(), "=");
			String underLineString = StringUtils.leftPad(underLine, rptHeaderLeftPad, "");
			logger.info(underLineString);
			logger.info(reportHeaderString);
			if (tableName != null) {
				logger.info(tableHeaderString);
			}
			logger.info(underLineString);
			if (trgEdgValues == null || trgEdgValues.isEmpty()) {
				logger.info(" ");
				errorType = "WARNING";
				errorMessage = "NO EDG VALUES FOUND FOR THE TABLE " + tableName;
				errorTableOperations(tableName, testcaseId, errorType, errorMessage);
				logger.error("***** " + errorMessage + " *****");
			}
			for (String key : trgEdgValues.keySet()) {
				List<String> enums = trgEdgValues.get(key);
				String[] trgAttributes = key.split(":");
				String trgTable = trgAttributes[0];
				String trgColumn = trgAttributes[1];
				logger.info(filler);
				logger.info(filler);
				String validationFor = "VALIDATING " + trgTable + "." + trgColumn + " ENUMERATIONS";
				logger.info(validationFor);
				logger.info(StringUtils.leftPad("", validationFor.length(), "-"));
				JdbcTemplate trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");
				String trgSchema = env.getRequiredProperty("aws.stage.dbconn.schema");
				String query = "SELECT distinct(" + trgColumn + ") FROM " + trgSchema + "." + trgTable;
				List<Map<String, Object>> data = trgDB.queryForList(query);
				logger.info("EDG Values: " + enums.toString());
				int numberOfErrors = 0;
				for (Map<String, Object> m : data) {
					Object columnObject = m.get(trgColumn);
					String columnValue = columnObject == null ? "NULL" : columnObject.toString();
					if (!enums.contains(columnValue)) {
						errorType = "ERROR";
						String error = "Value " + columnValue + " in the column " + trgTable + "." + trgColumn + " did not match to any EDG Value";
						if (criticalFlag.equalsIgnoreCase("Y")) {
							errorType = "CRITICAL";
						}
						errorTableOperations(tableName, testcaseId, errorType, error);
						logger.info("FAILURE: " + error);
						errorString.append(error + "\n");
						numberOfErrors++;
					} else {
						logger.info("SUCCESS: Value in the column " + trgTable + "." + trgColumn + " matched to the EDG Values");
					}
				}
				if (numberOfErrors == 0) {
					logger.info(filler);
					logger.info(filler);
					logger.info("	*** NO ENUMERATION ISSUES FOR " + trgTable + ":" + trgTable + "." + trgColumn + " ***");
				}
			}
			errorCount = errorString.toString().split("\n").length;

			if (errorCount > 0 && criticalFlag.equalsIgnoreCase("Y")) {

				errorCode = 1;
			}
		}
		return errorCode;
	}

	/**
	 * This method validates given table's current record count with record count from the previous day's load
	 * 
	 * @param trgTable
	 * @param criticalFlag
	 * @param testcaseId
	 */
	public int validateTargetRecordCountsWithPrevDay(String trgTable, String parentTable, String criticalFlag, String isRefCheckReq, String isTestCaseReq, int testcaseId) {
		int errorCode = 0;
		if ("N".equalsIgnoreCase(isTestCaseReq)) {
			logger.info(" ");
			logger.info("***** VALIDATE STAGING TABLE RECORD COUNTS WITH PREVIOUS DAY'S COUNTS CHECK IS NOT REQUIRED FOR THIS TABLE *****");
			logger.info(" ");
		} else {
			String reportHeader = "VALIDATE STAGING TABLE RECORD COUNTS WITH PREVIOUS DAY'S COUNTS";
			int rptHeaderLeftPad = getHeaderPadding(reportHeader);
			String reportHeaderString = StringUtils.leftPad(reportHeader, rptHeaderLeftPad, "");
			String tableHeader = "Table Name: " + trgTable;
			int tblHeaderLeftPad = Math.round((starFiller.length() - tableHeader.length()) / 2) + tableHeader.length();
			String tableHeaderString = StringUtils.leftPad(tableHeader, tblHeaderLeftPad, "");
			// logger.info(starFiller);

			String underLine = StringUtils.leftPad("", reportHeader.length(), "=");
			String underLineString = StringUtils.leftPad(underLine, rptHeaderLeftPad, "");
			logger.info(underLineString);
			logger.info(reportHeaderString);
			if (trgTable != null) {
				logger.info(tableHeaderString);
			}
			logger.info(underLineString);

			trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");
			String trgSchema = env.getRequiredProperty("aws.stage.dbconn.schema");
			String currentQuery = buildQuery(trgTable, trgSchema, null, null, 1, null, null);
			String previousQuery = "select appl_tbl_rec_cnt" + " from " + trgSchema + ".appl_tbl_load_trkr where appl_tbl_nme = '" + trgTable + "' and rec_cren_tm::timestamp::date = ("
					+ " select max(rec_last_upd_tm::timestamp::date)" + " from " + trgSchema + ".appl_avlb_smry" + " where appl_avlb_smry_stat_desc = 'AVAILABLE')";

			logger.info("Query for current record count: " + currentQuery);
			logger.info("Query for previous record count: " + previousQuery);
			logger.info("Executing Queries.....");
			int previousRecCount = 0;
			int currentRecCount = 0;

			try {
				previousRecCount = trgDB.queryForObject(previousQuery, int.class);
			} catch (EmptyResultDataAccessException e) {
				previousRecCount = 0;
			} catch (Exception e) {
				logger.error("FAILURE: Error in reading data from databse for Previous Day Count for " + trgTable, e);
			}
			try {
				currentRecCount = trgDB.queryForObject(currentQuery, int.class);
			} catch (Exception e) {
				logger.error("FAILURE: Error in reading data from databse for Current Day Count for " + trgTable, e);
			}
			logger.info(" ");
			logger.info("	Current record count: " + currentRecCount);
			logger.info("	Previous record count: " + previousRecCount);
			logger.info(" ");
			if (previousRecCount == 0) {
				errorType = "WARNING";
				errorMessage = "No data got loaded into " + trgTable + " table on previous day";
				logger.info("	***  NO DATA FOUND FROM PREVIOUS DAY... Please check the Database ***");
				errorTableOperations(trgTable, testcaseId, errorType, errorMessage);
			} else {
				if (currentRecCount == 0) {
					errorType = "CRITICAL";
					errorMessage = "No data got loaded into " + trgTable + " table today";
					if (criticalFlag.equalsIgnoreCase("Y")) {
						errorCode = 1;
					}
					logger.error(errorType + ":" + errorMessage);
					errorTableOperations(trgTable, testcaseId, errorType, errorMessage);
				} else if (currentRecCount != previousRecCount) {

					logger.info("Mismatch found between current and previous day record counts (" + currentRecCount + "::" + previousRecCount + ") for " + trgSchema + "." + trgTable);

				}

			}
		}
		return errorCode;
	}

	/**
	 * This method builds query based on the query type passed in a one of the parameters querytype = 1 ==> Record count for any given table considering join conditions and where clauses as
	 * appropriate querytype = 2 ==> Null count for any column in the table considering join conditions and where clauses as appropriate
	 * 
	 * @param tableName
	 * @param schemaPrefix
	 * @param colName
	 * @param fromClause
	 * @param joinCondition
	 * @param whereClause
	 * @param queryType
	 * @param rownumber
	 * @return
	 */
	private String buildQuery(String tableName, String schema, String colName, String fromClause, int queryType, String key, String keyVal) {
		StringBuilder query = new StringBuilder();
		switch (queryType) {
		case 1:
			query.append("SELECT COUNT(*) ");
			if (fromClause != null && !fromClause.isEmpty()) {
				query.append(fromClause);
			} else {
				query.append("FROM ").append(schema).append(".").append(tableName);
			}
			break;
		case 2:
			if (fromClause != null && !fromClause.isEmpty()) {
				query.append("SELECT COUNT(1) ").append(fromClause);
				if (fromClause.toUpperCase().indexOf("WHERE") == -1) {
					query.append(" WHERE ").append(colName).append(" IS NULL");
				} else {
					query.append(" AND ").append(colName).append(" IS NULL");
				}
			} else {
				query.append("SELECT COUNT(1) FROM ").append(schema).append(".").append(tableName).append(" WHERE ").append(colName).append(" IS NULL");
			}
			break;
		// TODO: This case needs removal
		case 3:
			query.append("SELECT COUNT(1) FROM ").append(schema).append(".").append(tableName).append(" WHERE ").append(colName).append(" IS NULL");
			break;
		case 4:
			query.append("SELECT COUNT(1) FROM ").append(schema).append(".").append(tableName).append(" WHERE ").append(colName).append(" IS NOT NULL");
			break;
		case 5:
			if (colName.equalsIgnoreCase(key)) {
				query.append("SELECT ").append(tableName).append(".").append(colName);
			} else {
				query.append("SELECT ").append(colName);
			}
			if (fromClause != null && !fromClause.isEmpty()) {
				query.append(" " + fromClause);
				if (fromClause.toUpperCase().indexOf("WHERE") == -1) {
					query.append(" WHERE ").append(tableName).append(".").append(key).append(" = ").append("'").append(keyVal).append("'");
				} else {
					query.append(" AND ").append(tableName).append(".").append(key).append(" = ").append("'").append(keyVal).append("'");
				}
			} else {
				query.append(" FROM ").append(schema).append(".").append(tableName).append(" WHERE ").append(tableName).append(".").append(key).append(" = ").append("'").append(keyVal).append("'");
			}
			break;
		case 6:
			query.append("SELECT COUNT(1) FROM ").append(schema).append(".").append(tableName).append(" WHERE ").append(colName).append("=''");
			break;
		case 7:
			query.append("SELECT ").append(colName);
			if (fromClause != null && !fromClause.isEmpty()) {
				query.append(" " + fromClause);

				query.append(" WHERE ").append(key).append(" = ").append("'").append(keyVal).append("'");
			} else {
				query.append(" FROM ").append(schema).append(".").append(tableName).append(" WHERE ").append(tableName).append(".").append(key).append(" = ").append("'").append(keyVal).append("'");
			}
		default:
		}

		return query.toString();
	}

	/**
	 * 
	 * @param trgTable
	 * @param parentTable
	 * @param criticalFlag
	 * @param isRefCheckReq
	 * @param isTestCaseReq
	 * @param testcaseId
	 * @return
	 */
	public int runAdhocQueries(List<String> tablesLoaded, String razorEnv) {

		int errorCode = 0;
		String reportHeader = "RESULT OF ADHOC QUERIES EXECUTION";
		int rptHeaderLeftPad = getHeaderPadding(reportHeader);
		String reportHeaderString = StringUtils.leftPad(reportHeader, rptHeaderLeftPad, "");

		List<Map<String, String>> queryParamsList = null;
		trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");
		try {
			queryParamsList = XmlUtils.getAdhocQuries(xmlFileName);
		} catch (ParserConfigurationException | SAXException | IOException e) {
			logger.error("		**ERROR in reading adhoc queries", e);
		}
		// This query is to check if that particular adhoc query completed its run for today. if yes, we don't run it again otherwise we run it.
		List<String> adhocQueryRunCompleted = new ArrayList<String>();
		try {
			String adhocTestCompleteCheckQuery = "SELECT appl_tbl_nme FROM " + trgSchema
					+ ".appl_tbl_appl_test_trkr WHERE appl_tbl_nme LIKE 'ADHOC%' AND appl_tbl_appl_test_run_dt = now() ::timestamp::date";
			adhocQueryRunCompleted = (List<String>) trgDB.queryForList(adhocTestCompleteCheckQuery, String.class);
		} catch (Exception e) {
			logger.info("FAILURE: ERROR Excuting the Query to Fectch the adhoc query names for which execution is completed" + e.toString(), e);
		}
		// Iterates through the adhoc quires in QueryMapper.xml
		for (Map<String, String> queryParam : queryParamsList) {
			String schemaPrefix = queryParam.get("schemaPrefix");
			String adhocQuery = queryParam.get("selectQuery");
			String resultType = queryParam.get("resultType");
			String queryTables = queryParam.get("queryTables");
			String expectedResult = queryParam.get("expectedResult");
			String queryName = queryParam.get("queryName");
			trgSchema = env.getRequiredProperty("aws.stage.dbconn.schema");
			if (!adhocQueryRunCompleted.contains(queryName)) {
				// Retrieve testcaseid, criticality flag and testcaserun req indicator based on the QueryName to proceed furthur.
				List<Map<String, Object>> adhocTestMapQueryResult = null;
				try {
					String adhocTestMapQuery = "SELECT map.appl_test_case_id,map.appl_test_case_cntl_ind,map.appl_test_case_reqd_ind FROM " + trgSchema + ".appl_tbl_test_case_map map"
							+ " WHERE map.appl_tbl_nme = '" + queryName + "'";
					adhocTestMapQueryResult = trgDB.queryForList(adhocTestMapQuery);
				} catch (Exception e) {
					logger.info("FAILURE: ERROR Excuting the Query to Fectch the " + queryName + " details from appl_tbl_test_case_map" + e.toString(), e);
				}
				String criticalFlag = null;
				String isTestCaseReq = null;
				int testCaseId = 0;
				for (Map<String, Object> m : adhocTestMapQueryResult) {
					Object testCaseIdObject = m.get("appl_test_case_id");
					Object criticalFlagObject = m.get("appl_test_case_cntl_ind");
					Object testCaseReqFlagObject = m.get("appl_test_case_reqd_ind");
					testCaseId = testCaseIdObject == null ? null : ((BigDecimal) testCaseIdObject).intValue();
					criticalFlag = criticalFlagObject == null ? "N" : criticalFlagObject.toString();
					isTestCaseReq = testCaseReqFlagObject == null ? "Y" : testCaseReqFlagObject.toString();
					// we run current adhocquery only if "isTestCaseReq" is "Y" based on the retrieved value from "appl_tbl_test_case_map"
					if ("Y".equalsIgnoreCase(isTestCaseReq)) {
						boolean isQueryTablesLoaded = true;

						if (queryTables.indexOf(",") != -1) {
							List<String> queryTablesArray = Arrays.asList(splitTableNames(queryTables));
							isQueryTablesLoaded = tablesLoaded.containsAll(queryTablesArray);

						} else {
							isQueryTablesLoaded = tablesLoaded.contains(queryTables);
						}
						if (isQueryTablesLoaded) {
							boolean isTableEntryReq = true;
							loggerUtils.createLogFile(queryName, razorEnv);
							String tableHeader = "Table Name: " + queryTables;
							int tblHeaderLeftPad = Math.round((starFiller.length() - tableHeader.length()) / 2) + tableHeader.length();
							String tableHeaderString = StringUtils.leftPad(tableHeader, tblHeaderLeftPad, "");
							String underLine = StringUtils.leftPad("", reportHeader.length(), "=");
							String underLineString = StringUtils.leftPad(underLine, rptHeaderLeftPad, "");
							logger.info(underLineString);
							logger.info(reportHeaderString);
							logger.info(underLineString);
							if (queryTables != null) {
								logger.info(tableHeaderString);
							}
							Class<?> cls = null;
							try {
								cls = Class.forName(resultType);
							} catch (ClassNotFoundException e) {
								isTableEntryReq = false;
								logger.error("ERROR: Can't get the class representation for \"" + resultType + "\"", e);
							}
							String result ="";
							
							if (schemaPrefix.equalsIgnoreCase("target")) {
								trgSchema = env.getRequiredProperty("aws.stage.dbconn.schema");
								adhocQuery = adhocQuery.replace("SRC_SCHEMA", trgSchema);
								logger.info("Executing Adhoc Query: " + adhocQuery);
								try{
								result = trgDB.queryForObject(adhocQuery, cls).toString();
								}catch(Exception e){
									isTableEntryReq = false;
									logger.info("Can't execute adhoc query");
								}
								
							} else {
								// pass schemaPrefix (example "clm" for DATRTS and "target" for Staging) through xml
								try{
								String jdbcTemplate = schemaPrefix + "JdbcTemplate";
								srcSchemaString = schemaPrefix + ".dbconn.schema";
								srcSchema = env.getRequiredProperty(srcSchemaString);
								srcDB = (JdbcTemplate) applicationContext.getBean(jdbcTemplate);
								adhocQuery = adhocQuery.replace("SRC_SCHEMA", srcSchema);
								logger.info("Executing Adhoc Query: " + adhocQuery);
								result = srcDB.queryForObject(adhocQuery, cls).toString();
									}catch(Exception e){
										isTableEntryReq = false;
										logger.info("Can't execute adhoc query");
									}
							}
                             if(isTableEntryReq){
							String message = "The result for the " + queryName + " query: " + result;
							errorType = "INFO";
							errorTableOperations(queryName, testCaseId, errorType, message);
							logger.info(message);
							String insertForTracking = "INSERT INTO " + trgSchema + ".appl_tbl_appl_test_trkr(appl_tbl_nme,appl_tbl_appl_test_stat,appl_tbl_appl_test_run_dt)" + " VALUES ('"
									+ queryName + "','COMPLETED',current_date::timestamp::date)";
							trgDB.execute(insertForTracking);
                             }
						} else {
							// ToDo: uncomment only when we enable console log
							// logger.info("");
							// logger.info("***** RESPECTIVE TABLES WERE NOT LOADED AT THIS TIME TO RUN " + queryName + " QUERY *****");
							// logger.info("");
						}

					} else {
						// ToDo: uncomment only when we enable console log
						// logger.info("");
						// logger.info("***** " + queryName + " QUERY EXECUTION IS NOT REQUIRED TO RUN FOR TODAYS VALIDATION *****");
						// logger.info("");
					}
				}
			}
		}
		return errorCode;
	}

	public String getMatching(String matcher) {
		Pattern p = Pattern.compile("AMOUNT AVAILABLE TO PAY 571[, ]?\\$?([0-9]*[\\.]?(\\d\\d)?)");
		// Pattern.compile("'(.*?)'");
		Matcher m = p.matcher(matcher);
		String str = null;
		if (m.find()) {
			str = m.group(1); // " that is awesome"
		}
		return str;
	}

	private static int getHeaderPadding(String header) {
		int padding = Math.round((starFiller.length() - header.length()) / 2) + header.length();
		return padding;
	}

	private SQLColumn loadMetadata(JdbcTemplate template, String query, String tableName) {
		SQLColumn column = new SQLColumn();
		try {
			template.query(query, new ResultSetExtractor<Object>() {
				@Override
				public Integer extractData(ResultSet rs) {
					int columnCount = 0;
					try {
						ResultSetMetaData rsmd = rs.getMetaData();
						columnCount = rsmd.getColumnCount();
						column.setColumnName(rsmd.getColumnName(1));
						column.setColumnType(rsmd.getColumnTypeName(1));
						column.setColumnTypeCode(rsmd.getColumnType(1));
						column.setTableName(tableName);
					} catch (Exception e) {
						logger.error("************ ERROR in getting metadata for the query", e);
					}
					return columnCount;
				}
			});
		} catch (Exception e) {
			// e.printStackTrace();
			logger.error("ERROR: An Error occured in the process.  Please check the log file", e);
		}
		return column;

	}

	public class SQLColumn {

		String columnName;
		String columnType;
		int columnTypeCode;
		String tableName;

		/**
		 * @return the columnName
		 */
		public String getColumnName() {
			return columnName;
		}

		/**
		 * @param columnName
		 *            the columnName to set
		 */
		public void setColumnName(String columnName) {
			this.columnName = columnName;
		}

		/**
		 * @return the columnType
		 */
		public String getColumnType() {
			return columnType;
		}

		/**
		 * @param columnType
		 *            the columnType to set
		 */
		public void setColumnType(String columnType) {
			this.columnType = columnType;
		}

		/**
		 * @return the columnTypeCode
		 */
		public int getColumnTypeCode() {
			return columnTypeCode;
		}

		/**
		 * @param typeCode
		 *            the columnTypeCode to set
		 */
		public void setColumnTypeCode(int typeCode) {
			this.columnTypeCode = typeCode;
		}

		/**
		 * @return the tableName
		 */
		public String getTableName() {
			return tableName;
		}

		/**
		 * @param tableName
		 *            the tableName to set
		 */
		public void setTableName(String tableName) {
			this.tableName = tableName;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "SQLColumn [columnName=" + columnName + ", columnType=" + columnType + ", columnTypeCode=" + columnTypeCode + ", tableName=" + tableName + "]";
		}
	}

	/**
	 * This method returns the queries for ErrorTable based on the errorType that we pass.
	 * 
	 * @param trgTable
	 * @param errorType
	 * @param testcaseId
	 * @param queryType
	 * @param testcaseErrorObjId
	 * @return
	 */
	public static String getErrorQueries(String trgTable, String errorType, int testcaseId, String queryType, int testcaseErrorObjId) {
		String query = null;
		if (insertQuery.equalsIgnoreCase(queryType)) {
			query = "INSERT into " + trgSchema + ".appl_test_case_err (appl_tbl_nme,appl_test_case_err_typ,appl_test_case_id) values('" + trgTable + "','" + errorType + "'," + testcaseId + ")";
		} else if (updateQuery.equalsIgnoreCase(queryType)) {
			query = "UPDATE " + trgSchema + ".appl_test_case_err SET appl_test_case_err_typ='" + errorType + "'" + "WHERE appl_tbl_nme ='" + trgTable + "' AND appl_test_case_id ='" + testcaseId
					+ "' AND DATE(rec_cren_tm) = now() ::timestamp::date";
		} else if (selectQuery.equalsIgnoreCase(queryType)) {
			query = "SELECT appl_test_case_err_obj_id,appl_test_case_err_typ FROM " + trgSchema + ".appl_test_case_err WHERE appl_tbl_nme ='" + trgTable + "' AND appl_test_case_id ='" + testcaseId
					+ "' AND DATE(rec_cren_tm) = now() ::timestamp::date  ORDER BY appl_test_case_err_obj_id DESC LIMIT 1";
		} else if (selectUpdateQuery.equalsIgnoreCase(queryType)) {
			query = "SELECT EXISTS(SELECT appl_test_case_err_obj_id FROM " + trgSchema + ".appl_test_case_err WHERE appl_tbl_nme ='" + trgTable + "' AND appl_test_case_id ='" + testcaseId
					+ "'  AND DATE(rec_cren_tm) = now() ::timestamp::date)";
		}
		return query;
	}

	/**
	 * This method returns the queries for ErrorDetailTable based on the errorType that we pass.
	 * 
	 * @param trgTable
	 * @param errorType
	 * @param queryType
	 * @param testcaseErrorObjId
	 * @param errorMsg
	 * @return
	 */
	public static String getErrorDetailQueries(String trgTable, String errorType, String queryType, int testcaseErrorObjId, String errorMsg) {
		String query = null;
		if (insertQuery.equalsIgnoreCase(queryType)) {

			query = "INSERT into " + trgSchema + ".appl_test_case_err_dtl (appl_test_case_err_obj_id,appl_test_case_err_dtl_typ,appl_test_case_err_dtl_desc) VALUES(" + testcaseErrorObjId + ",'"
					+ errorType + "','" + errorMsg + "')";

		}

		return query;
	}

	/**
	 * This method sets "testcaseErrObjId" value that is generated and prevErrorType(values that is there in table for that particular table and testcase on that day)
	 * 
	 * @param queryResults
	 */
	public static void setErrTbleValues(List<Map<String, Object>> queryResults) {

		for (Map<String, Object> m : queryResults) {

			Object testCaseErrObjIdObject = m.get("appl_test_case_err_obj_id");
			Object testCaseErrTypeObject = m.get("appl_test_case_err_typ");
			testcaseErrObjId = testCaseErrObjIdObject == null ? null : ((BigDecimal) testCaseErrObjIdObject).intValue();
			prevErrorType = testCaseErrTypeObject == null ? null : testCaseErrTypeObject.toString();

		}

	}

	/**
	 * This method inserts the record into "appl_test_case_err" table for very first time, In next occurrence if we get errorType(ex: ERROR,CRITICAL) which has higher priority than the errorType in
	 * the current existing record we have to update that row, how ever we make sure for the current date we have only one record for each table for every testcaseId (If that testcaseId has some
	 * errors). and It also inserts every occurrence of ERROR INTO "appl_test_case_err_dtl" irrespective of any conditions along with the respective objectId generated on the current date for
	 * respective table with respective testcaseId in the "appl_test_case_err" table.
	 * 
	 * @param trgTable
	 * @param testcaseId
	 * @param errorType
	 * @param errorMessage
	 */
	private synchronized static void errorTableOperations(String trgTable, int testcaseId, String errorType, String errorMessage) {
		String query = null;

		query = getErrorQueries(trgTable, errorType, testcaseId, selectUpdateQuery, testcaseErrObjId);
		List<Boolean> isRecordExists = trgDB.queryForList(query, Boolean.class);

		if (isRecordExists.get(0)) {
			if (errorTypePriorityMap.get(errorType) > errorTypePriorityMap.get(prevErrorType)) {
				query = getErrorQueries(trgTable, errorType, testcaseId, updateQuery, testcaseErrObjId);
				trgDB.execute(query);
			}

		} else {
			query = getErrorQueries(trgTable, errorType, testcaseId, insertQuery, testcaseErrObjId);
			trgDB.execute(query);
		}
		query = getErrorQueries(trgTable, errorType, testcaseId, selectQuery, testcaseErrObjId);
		List<Map<String, Object>> queryresult = trgDB.queryForList(query);
		setErrTbleValues(queryresult);
		query = getErrorDetailQueries(trgTable, errorType, insertQuery, testcaseErrObjId, errorMessage);
		//System.out.println(query);
		trgDB.execute(query);
	}

	/**
	 * This method is used to seperate the tablenames string based on ,.
	 * 
	 * @param CommaSepTableNames
	 * @return
	 */
	public String[] splitTableNames(String CommaSepTableNames) {
		String[] tableArray = CommaSepTableNames.split(",");
		return tableArray;
	}

}
