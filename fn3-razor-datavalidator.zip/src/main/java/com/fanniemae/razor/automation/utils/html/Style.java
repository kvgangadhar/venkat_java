package com.fanniemae.razor.automation.utils.html;

public class Style {
	private String headerElement = "";
	private String bodyElement = "";
	private String paraElement = "";
	private String borderElement = "";
	private String tableHeaderElement = "";
	private String columnElement = "";
	
	public Style setHeading(String headingType, String headingColor, String headingFont, String headingalignment){
		headerElement = headerElement + "\n " + headingType + "{ color: " + headingColor + "; font-family: " + headingFont + "; text-align: " + headingalignment +"; }";
		return this;
	}
	public Style setBody(String bgColor){
		bodyElement = "\n body { background-color: " + bgColor + "; }";
		return this;
	}
	
	public Style setParagraph (String font, String size, String color){
		paraElement = "\n p { font-family: " + font + "; font-size: " + size + "; color: " + color + "; }";
		return this;
	}
	
	public Style setTableBorder(String border, String borderCollapse){
		borderElement = "\n table,th,td { border: " + border + "; border-collapse: " + borderCollapse + "; }";
		return this;
	}
	
	public Style setTableHeader(String color, String bgColor, String textAlignment){
		tableHeaderElement = "\n thead { color: " + color + "; background-color: " + bgColor + "; text-align: " + textAlignment + "; }";
		return this;
	}

	public Style setColum(int paddingSize, String textAlignment){
		columnElement = "\n td { padding: " + paddingSize +"px; text-align: " + textAlignment + "; }";
		return this;
	}
	@Override
	public String toString(){
		String styleSheet = "<style> " + bodyElement + headerElement + paraElement + borderElement + tableHeaderElement + columnElement + "\n</style>";
		return styleSheet;
	}
	
	public static void main (String[] args){
		Style style = new Style();
		style.setHeading("h1", "Red", "helvetica", "center")
		      .setHeading("h3", "Green", "arial", "left")
		      .setBody("blue")
		      .setParagraph("arial", "12", "blue");
		//System.out.println(style.toString());	
	}
}
