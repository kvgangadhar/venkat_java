/**
 * 
 */
package com.fanniemae.razor.automation.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.fanniemae.razor.automation.common.CommonConstants;
import com.fanniemae.razor.automation.dto.MappingDTO;
import com.fanniemae.razor.automation.dto.SourceDTO;

/**
 * @author gbusrk
 *
 */
public class ExcelUtils_bkp implements CommonConstants {

	private static final String FILE_NAME = "src/test/resources/data/Expense_Attributes_WIP_V7.xlsx";

	public static SourceDTO processExcel(String fileName) throws Exception {
		Row row = null;
		SourceDTO sourceDTO = null;
		DataFormatter formatter = new DataFormatter();
		Workbook workbook = WorkbookFactory.create(new File(fileName));
		Sheet sheet = workbook.getSheetAt(0);
		for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
			Map<String, List<MappingDTO>> sourceMap = null;
			List<MappingDTO> mappingDTOList = null;
			List<String> srcColumns = null;
			List<String> trgColumns = null;
			MappingDTO mappingDTO = null;
			row = sheet.getRow(rowIndex);
			String sourceName = formatter.formatCellValue(row.getCell(EXCEL_SOURCE_INDEX));
			String srcTableName = formatter.formatCellValue(row.getCell(EXCEL_SOURCE_TABLE_INDEX));
			String trgTableName = formatter.formatCellValue(row.getCell(EXCEL_TARGET_TABLE_INDEX));
			String srcColName = formatter.formatCellValue(row.getCell(EXCEL_SOURCE_COLUMN_INDEX));
			String trgColName = formatter.formatCellValue(row.getCell(EXCEL_TARGET_COLUMN_INDEX));
			if (sourceDTO == null) {
				sourceDTO = new SourceDTO();
				sourceMap = new HashMap<>();
			} else {
				sourceMap = sourceDTO.getSourceMap();
				if (sourceMap.get(sourceName) != null) {
					mappingDTOList = sourceDTO.getSourceMap().get(sourceName);
				}
			}
			if (mappingDTOList == null) {
				mappingDTOList = new ArrayList<>();
			} else {
				List<MappingDTO> matchingSource = mappingDTOList.stream()
						.filter(o -> o.getSrcTableName().equals(srcTableName)).collect(Collectors.toList());
				if (matchingSource != null && !matchingSource.isEmpty()) {
					mappingDTO = matchingSource.get(0);
					srcColumns = matchingSource.get(0).getSrcColumns();
					trgColumns = matchingSource.get(0).getTrgColumns();
				} 				
			}
			if(mappingDTO == null){
					mappingDTO = new MappingDTO();
					srcColumns = new ArrayList<>();
					trgColumns = new ArrayList<>();
					mappingDTO.setSrcTableName(srcTableName);
					mappingDTO.setTrgTableName(trgTableName);
					mappingDTOList.add(mappingDTO);
			}
			if (srcColumns != null && srcColName != null && trgColumns != null && trgColName != null) {
				srcColumns.add(srcColName);
				trgColumns.add(trgColName);
			}else{
				throw new Exception("Invalid Column mapping " + sourceName );
			}
			mappingDTO.setSrcColumns(srcColumns);
			mappingDTO.setTrgColumns(trgColumns);
			sourceMap.put(sourceName, mappingDTOList);
			sourceDTO.setSourceMap(sourceMap);
		}
		return sourceDTO;
	}

	public static void main(String[] args) throws Exception {
		Map<String, List<MappingDTO>> sourceMap = processExcel(FILE_NAME).getSourceMap();
		List<MappingDTO> mappingDTOList = sourceMap.get("ARROW");
		int size = mappingDTOList.size();
		System.out.println("Number of mappingDTOs in the List: " + size);
		for(MappingDTO mappingDTO: mappingDTOList){
			System.out.println("********************************************");
			System.out.println("Source Table: " + mappingDTO.getSrcTableName());
			System.out.println("Source Columns: " + mappingDTO.getSrcColumns());
			System.out.println("Target Table: " + mappingDTO.getTrgTableName());
			System.out.println("Target Columns: " + mappingDTO.getTrgColumns());
			System.out.println("********************************************");
		}
	}

}
