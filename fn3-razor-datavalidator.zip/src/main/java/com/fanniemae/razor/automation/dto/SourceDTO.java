/*
 * Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.razor.automation.dto;

import java.util.List;
import java.util.Map;

public class SourceDTO {
	private Map<String,List<MappingDTO>> sourceMap;
	/*private String sourceName;
	private List<MappingDTO> mappingDTOList;
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	public List<MappingDTO> getMappingDTOList() {
		return mappingDTOList;
	}
	public void setMappingDTOList(List<MappingDTO> mappingDTOList) {
		this.mappingDTOList = mappingDTOList;
	}*/
	public Map<String,List<MappingDTO>> getSourceMap() {
		return sourceMap;
	}
	public void setSourceMap(Map<String,List<MappingDTO>> sourceMap) {
		this.sourceMap = sourceMap;
	}
}
