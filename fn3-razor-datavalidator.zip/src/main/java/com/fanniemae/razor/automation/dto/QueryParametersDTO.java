package com.fanniemae.razor.automation.dto;

public class QueryParametersDTO {

	private String sourceTableName;
	private String targetTableName;
	private String alternateSource;
	private String srcKey;
	private String trgKey;
	private String fromClause;
	private String selectClause;
	/**
	 * @return the sourceTableName
	 */
	public String getSourceTableName() {
		return sourceTableName;
	}
	/**
	 * @param sourceTableName the sourceTableName to set
	 */
	public void setSourceTableName(String sourceTableName) {
		this.sourceTableName = sourceTableName;
	}
	/**
	 * @return the targetTableName
	 */
	public String getTargetTableName() {
		return targetTableName;
	}
	/**
	 * @param targetTableName the targetTableName to set
	 */
	public void setTargetTableName(String targetTableName) {
		this.targetTableName = targetTableName;
	}
	/**
	 * @return the alternateSource
	 */
	public String getAlternateSource() {
		return alternateSource;
	}
	/**
	 * @param alternateSource the alternateSource to set
	 */
	public void setAlternateSource(String alternateSource) {
		this.alternateSource = alternateSource;
	}
	/**
	 * @return the srcKey
	 */
	public String getSourceKey() {
		return srcKey;
	}
	/**
	 * @param srcKey to set
	 */
	public void setSourceKey(String srcKey) {
		this.srcKey = srcKey;
	}
	/**
	 * @return the trgKey
	 */
	public String getTargetKey() {
		return trgKey;
	}
	/**
	 * 
	 * @param trgKey to set
	 */
	public void setTargetKey(String trgKey) {
		this.trgKey = trgKey;
	}
	/**
	 * @return the fromClause
	 */
	public String getFromClause() {
		return fromClause;
	}
	/**
	 * @param fromClause the fromClause to set
	 */
	public void setFromClause(String fromClause) {
		this.fromClause = fromClause;
	}
	/**
	 * @return the selectClause
	 */
	public String getSelectClause() {
		return selectClause;
	}
	/**
	 * @param selectClause the selectClause to set
	 */
	public void setSelectClause(String selectClause) {
		this.selectClause = selectClause;
	}
	
}
