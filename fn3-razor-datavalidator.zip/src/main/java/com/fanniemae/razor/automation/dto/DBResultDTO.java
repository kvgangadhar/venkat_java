/*
 * Copyright (c) 2014 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.razor.automation.dto;

/**
 * Represents one entry of database result set
 * @author q2uscv
 *
 */
public class DBResultDTO {
	
    private String fieldValue;
    private boolean isFieldRequired;
    private boolean isFieldEnabled;

    public DBResultDTO() {
        super();
    }

    public DBResultDTO(String fieldValue, boolean isFieldRequired, boolean isFieldEnabled) {
        super();
        this.fieldValue = fieldValue;
        this.isFieldRequired = isFieldRequired;
        this.isFieldEnabled = isFieldEnabled;
    }

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public boolean isFieldRequired() {
		return isFieldRequired;
	}

	public void setFieldRequired(boolean isFieldRequired) {
		this.isFieldRequired = isFieldRequired;
	}

	public boolean isFieldEnabled() {
		return isFieldEnabled;
	}

	public void setFieldEnabled(boolean isFieldEnabled) {
		this.isFieldEnabled = isFieldEnabled;
	}
}
