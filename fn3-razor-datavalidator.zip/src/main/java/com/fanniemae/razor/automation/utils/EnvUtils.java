/*
 * Copyright (c) [2014] Fannie Mae. All rights reserved.
 * 
 * Unpublished -- Rights reserved under the copyright laws of the United States
 * and international conventions. Use of a copyright notice is precautionary only
 * and does not imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction is
 * prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.razor.automation.utils;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fanniemae.razor.automation.common.CommonConstants;
import com.fanniemae.testeng.automation.exceptions.TestingException;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;
import com.fanniemae.testeng.automation.xml.JDomXmlUtils;

/**
 * 
 * @author q2uscv
 *
 */
@Component
public class EnvUtils {
	
	@Value("${env}")
	private String environment;
	
	@Value("${dbconn.url}")
	private String dbUrl;
	
	@Value("${dbconn.username}")
	private String dbUserName;
	
	@Value("${dbconn.password}")
	private String dbPassword;
	
	@Value("${aws.dbconn.url}")
	private String awsDbUrl;
	
	@Value("${aws.dbconn.username}")
	private String awsDbUserName;
	
	@Value("${aws.dbconn.password}")
	private String awsDbPassword;
	
	@Value("${razor.RESTfulService.baseURI}")
	private String razorRestServiceBaseURL;
	
	@Value("${unix.hostName}")
	private String unixServer;

	@Value("${unix.userName}")
	private String unixLoginId;

	@Value("${unix.password}")
	private String unixPassword;
	
//	@Value("${dtf.unix.hostName}")
//	private String dtfUnixServer;
//
//	@Value("${dtf.unix.userName}")
//	private String dtfUnixLoginID;
//
//	@Value("${dtf.unix.password}")
//	private String dtfUnixPassword;
//	
//	@Value("${dtf.unix.target.dir}")
//	private String dtfTargetDir;
	
	@Value("${ldap.userName}")
	private String ldapUserId;

	@Value("${ldap.password}")
	private String ldapPassword;
	
	@Value("${aws.env.role}")
	private String awsRole;
	
	@Value("${aws.s3.request.bucketName}")
	private String requestBucket;
	
	@Value("${aws.sqs.bulkRequestQueue.name}")
	private String bulkRequestQueueName;
	
	@Value("${aws.sqs.bulkRequestQueue.url}")
	private String bulkRequestQueueURL;
	
	@Value("${aws.sqs.singleCDSQueue.name}")
	private String singleCDSQueueName;
	
	@Value("${aws.sqs.singleCDSQueue.url}")
	private String singleCDSQueueURL;
	
	@Value("${aws.sqs.bulkResponseQueue.name}")
	private String bulkResponseQueueName;
	
	@Value("${aws.sqs.bulkResponseQueue.url}")
	private String bulkResponseQueueURL;
		
	public String getFirefoxProfileName() throws TestingException {
        final String firefoxProfileNameXPath = "//firefox-profile[@enabled='true']/profile-name";
        return getConfigValue(firefoxProfileNameXPath);
    }

    public String getProxyHostnameFor(String appName) throws TestingException {
        final String proxyHostNameXPath = "//proxies/proxy[@name='%s']/hostname";
        return getConfigValue(proxyHostNameXPath, appName);
    }

    public String getProxyPortFor(String appName) throws TestingException {
        final String proxyPortXPath = "//proxies/proxy[@name='%s']/port";
        return getConfigValue(proxyPortXPath, appName);
    }

    public String getProxyUsernameFor(String appName) throws TestingException {
        final String proxyUserNameXPath = "//proxies/proxy[@name='%s']/username";
        return getConfigValue(proxyUserNameXPath, appName);
    }

    public String getProxyPasswordFor(String appName) throws TestingException {
    	final String proxyPasswordXPath = "//proxies/proxy[@name='%s']/password";
        return getConfigValue(proxyPasswordXPath, appName);
    }

    public String getConfigValue(String configElementXPathTemplate, Object... args) throws TestingException {
    	final String configElementXPath = String.format(configElementXPathTemplate, args);
        CucumberLogUtils.logDebug("Executing XPath against local environment file: " + configElementXPath);
        String envFilePath = "/conf/env/" + environment + ".xml";
        String configElementValue = null;

        try {
            configElementValue = JDomXmlUtils.getValueByXpathFromResourcePath(envFilePath, configElementXPath);
        } catch (IOException ioException) {
            throw new TestingException("IO Error while reading the xml file from the config Path: " + configElementXPath, ioException);
        }

        return configElementValue;
    }
    
    
    //TODO - Revisit where to get the user details for test.xml or loclUsers.xml
//    public String getUserName(String role) throws TestingException {
//        final String userIdXPath = "//role/user[@id='%s']/userId";
//        return getConfigValue(userIdXPath, role);
//    }
//    
//    public String getPassword(String role) throws TestingException {
//        final String userPasswordXPath = "//role/user[@id='%s']/password";
//        System.out.println(EncryptionUtils.decrypt(getConfigValue(userPasswordXPath, role)));
//        return EncryptionUtils.decrypt(getConfigValue(userPasswordXPath, role));
//    }


    public String getDbUrl() {
		return dbUrl;
	}

	public String getDbUserName() {
		return dbUserName;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public String getAwsDbUrl() {
		return awsDbUrl;
	}

	public String getAwsDbUserName() {
		return awsDbUserName;
	}

	public String getAwsDbPassword() {
		return awsDbPassword;
	}

	public String getRazorRestServiceBaseURL() {
		return razorRestServiceBaseURL;
	}

	public String getUnixServer() {
		return unixServer;
	}

	public String getUnixLoginId() {
		return unixLoginId;
	}

	public String getUnixPassword() {
		return unixPassword;
	}

//	public String getDtfUnixServer() {
//		return dtfUnixServer;
//	}
//
//	public String getDtfUnixLoginID() {
//		return dtfUnixLoginID;
//	}
//
//	public String getDtfUnixPassword() {
//		return dtfUnixPassword;
//	}
//
//	public String getDtfTargetDir() {
//		return dtfTargetDir;
//	}

	public String getEnvironment() {
		return environment;
	}

	public String getLdapUserId() {
		return ldapUserId;
	}

	public String getLdapPassword() {
		return ldapPassword;
	}

	public String getAwsRole() {
		return awsRole;
	}
	
	public String getBucketName(String bucketKey) {
		if(bucketKey.equals(CommonConstants.S3_PRIVATE_BUCKET)) {
			return requestBucket;	
		} else {
			CucumberLogUtils.logError("Bucket Name not configured");
			return null;
		}
	}
	
	public String getBulkRequestQueueName() {
		return bulkRequestQueueName;
	}
	
	public String getsingleCDSQueueURL() {
		return singleCDSQueueURL;
	}
	public String getBulkRequestQueueURL() {
		return bulkResponseQueueURL;
}
	public String getBulkResponseQueueURL() {
		return bulkResponseQueueURL;
}
	

}
