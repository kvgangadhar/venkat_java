package com.fanniemae.razor.automation.common;

/**
 * This class will have all the constants values of all the possible key's which will be used 
 * to store object instances in CommonCache.
 */
public interface CommonConstants {
	
	 String ONE_SPACE = " ";
	 String UNDERSCORE = "_";
	 String BLANK = "";
	 String COLON = ":";
	
	 String LDAP_USER_ID = "ldap.userName";
	 String LDAP_USER_PASSWORD = "ldap.Password";
	 String DATE_FORMAT = "yyyyMMdd";
	

	//Date related
	 String LONG_DATE_TIME_FORMAT              = "ddMMyyHHmmss";
	 String LONG_DATE_TIME_FORMAT2              = "yyMMddHHmmss";
	 String SHORT_DATE_FORMAT                  = "MM/dd/yyyy";
	 String TODAYS_DATE_TIME_PLACEHOLDER       = "todaysDateTime()";
	 String TODAYS_DATE_PLACEHOLDER            = "todaysDate()";
	 String TOMORROW_DATE_PLACEHOLDER          = "tomorrowDate()";
	 String TODAYS_DATE_TIME_IN_MILLSEC_PLACEHOLDER       = "todaysDateTimeInMilliSec()";
	 String LONG_DATE_TIME_IN_MILLSEC_FORMAT              = "ddMMyyHHmmssSSS";
	
	
	//DB related
	/** The Constant EXISTING_FORM_NAME. */
	 String EXISTING_FORM_NAME = "EXISTING_FORM_NAME";
	
	/** The Constant USE_THE_INPUT_MATCHING. */
	 String USE_THE_INPUT_MATCHING = "USE_THE_INPUT_MATCHING";
	
	/** The Constant USE_THE_DATE_INPUT_MATCHING. */
	 String USE_THE_DATE_INPUT_MATCHING = "USE_THE_DATE_INPUT_MATCHING";
	
	/** The Constant USE_THE_IN_CONDITION. */
	 String USE_THE_IN_CONDITION = "USE_THE_IN_CONDITION";
	
	/** The Constant USE_THE_LIKE_CONDITION. */
	 String USE_THE_LIKE_CONDITION = "USE_THE_LIKE_CONDITION";
	
	/** The Constant USE_SUBQUERY_CONDITION. */
	 String USE_SUBQUERY_CONDITION = "USE_SUBQUERY_CONDITION";
	
	/** The Constant USE_THE_GREATER_AND_EQUAL_DATE_INPUT */
	 String USE_GREATER_AND_EQUAL_DATE = "USE_GREATER_AND_EQUAL_DATE";
	 
	 String NOT_NULL_CONDITION = "Not NULL";
	 
	 //Source to Staging DB mapping Constants
	 int EXCEL_SOURCE_INDEX = 5;
	 int EXCEL_SOURCE_TABLE_INDEX = 6;
	 int EXCEL_SOURCE_COLUMN_INDEX = 7;
	 int EXCEL_SOURCE_KEY_INDEX = 8;
	 int EXCEL_TARGET_TABLE_INDEX = 12;
	 int EXCEL_TARGET_COLUMN_INDEX = 13;
	 int EXCEL_TARGET_KEY_INDEX = 14;
	 
	 /** S3 ffile location configuration to load from properties file */
	 String S3_PRIVATE_BUCKET = "Runtime-Private";

}
