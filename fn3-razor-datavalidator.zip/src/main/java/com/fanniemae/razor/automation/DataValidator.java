package com.fanniemae.razor.automation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.fanniemae.razor.automation.steps.impl.DatabaseImpl;
import com.fanniemae.razor.automation.utils.html.Body;
import com.fanniemae.razor.automation.utils.html.HtmlBuilder;
import com.fanniemae.razor.automation.utils.html.Row;
import com.fanniemae.razor.automation.utils.html.Style;
import com.fanniemae.razor.automation.utils.html.Table;
import com.fanniemae.razor.automation.utils.LoggerUtils;
import com.fanniemae.razor.config.ApplicationConfig;
import com.fanniemae.testeng.automation.utils.LocalConfUtils;

@Component
@ComponentScan(basePackages = "com.fanniemae.razor")
public class DataValidator {
	
	private static JdbcTemplate trgDB;
	private static String configFile = "./conf/local/localConf.properties";
	public static String razorEnv = "local";
	Logger logger = Logger.getLogger(DataValidator.class.getName());
	boolean runAdhocQueries = true;
	DateFormat dateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
	Date date = new Date();
	String timestamp = dateTimeFormat.format(date);
	DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	String dt = dateFormat.format(date);
	private String reportsOutput;
	public static void main(String[] args) {

		DataValidator app = new DataValidator();

		if (args.length != 0) {
			razorEnv = args[0];
		   configFile = "/export/appl/fn3devl/datavalidator/conf/" + razorEnv + "Conf.properties";
		}
		app.startValidations();
	}

	/**
	 * Main method gets called from Autosys to initiate the validations process
	 */

	public void startValidations() {
		System.getProperties().setProperty("razor_env_path", razorEnv);
		System.getProperties().setProperty("configurationFile", configFile);
		logger.info("BEGIN: RAZOR DATALOAD AUTOMATION TESTS IN " + razorEnv.toUpperCase() + " ON " + new Date().toString());
		logger.info("CONIFG FILE: " + configFile);
		try (final AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext()) {
			applicationContext.register(ApplicationConfig.class);
			applicationContext.refresh();

			Properties props = new Properties();
			int errorCode = 0;
			boolean isCritical = false;
			boolean isTestFailed = false;
			boolean isReportGenReq = false;
			try {
				FileInputStream fis = new FileInputStream(configFile);
				props.load(fis);
			} catch (FileNotFoundException fnfe) {
				fnfe.printStackTrace();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}

			String stgDbUserName = props.getProperty("aws.stage.dbconn.username");
			logger.info("Staging database User:  " + stgDbUserName.toUpperCase());
			//String mappingFileName = props.getProperty("aws.stage.dataload.mappingFile");
			String trgSchema = props.getProperty("aws.stage.dbconn.schema");
			trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");
			String dataLoadTableFetchError = "";
			// If tables are not in completed state and RAZOR IS still AVAILABLE?
			String tableLoadCompleteQuery = "select DISTINCT(appl_tbl_nme)" + " from " + trgSchema + ".appl_tbl_load_trkr" + " where appl_tbl_load_stat_desc = 'COMPLETED'"
					+ " and appl_tbl_run_dt = (select MAX(appl_avlb_smry_run_dt) " + "from " + trgSchema + ".appl_avlb_smry)";

			String tableTestCompleteQuery = "SELECT appl_tbl_nme FROM " + trgSchema + ".appl_tbl_appl_test_trkr " + "WHERE appl_tbl_appl_test_stat = 'COMPLETED' "
					+ " AND appl_tbl_appl_test_run_dt = current_date::timestamp::date";

			logger.info("Data Load Complete Query: " + tableLoadCompleteQuery);
			logger.info("Validation Complete Query: " + tableTestCompleteQuery);
			List<String> tableLoadCompleteQueryResults = new ArrayList<String>();
			try {
				tableLoadCompleteQueryResults = (List<String>) trgDB.queryForList(tableLoadCompleteQuery.toString(), String.class);
			} catch (Exception e) {

				dataLoadTableFetchError = "FAILURE: ERROR Excuting the Query to Fectch the table names for which data load is completed successfully " + e.toString();
				logger.debug(dataLoadTableFetchError, e);
			}
			List<String> tableTestCompleteQueryResults = new ArrayList<String>();
			try {
				tableTestCompleteQueryResults = (List<String>) trgDB.queryForList(tableTestCompleteQuery.toString(), String.class);
			} catch (Exception e) {

				dataLoadTableFetchError = "FAILURE: ERROR Excuting the Query to Fectch the table names for which data load is completed successfully " + e.toString();
				logger.info(dataLoadTableFetchError, e);
			}

			List<String> tablesBeingValidated = removeElementsFromList(tableLoadCompleteQueryResults, tableTestCompleteQueryResults);
			logger.info(" ");
			logger.info("Tables that are being validated in this run: " + tablesBeingValidated.toString());
			DatabaseImpl impl = (DatabaseImpl) applicationContext.getBean(DatabaseImpl.class);
			LoggerUtils loggerUtils = (LoggerUtils) applicationContext.getBean(LoggerUtils.class);
			for (String tableName : tablesBeingValidated) {
				if (!dataLoadTableFetchError.isEmpty()) {
					logger.fatal(dataLoadTableFetchError);
				}
				String testCaseMapQuery = "SELECT lkup.appl_test_case_id,lkup.appl_test_case_nme,map.appl_test_case_cntl_ind,map.appl_prnt_tbl_nme,map.appl_ref_chk_reqd_ind,map.appl_test_case_reqd_ind"
						+ " FROM " + trgSchema + ".appl_tbl_test_case_map map" + " INNER JOIN " + trgSchema + ".appl_test_case_lkup lkup" + " ON lkup.appl_test_case_id = map.appl_test_case_id"
						+ " WHERE map.appl_tbl_nme = '" + tableName + "'";

				// Get the test cases needed from this table.
				List<Map<String, Object>> testCaseMapQueryResult = trgDB.queryForList(testCaseMapQuery);
				Object parentTableObject = !testCaseMapQueryResult.isEmpty() ? testCaseMapQueryResult.get(0).get("appl_prnt_tbl_nme") : null;
				String parentTable = parentTableObject == null ? "" : parentTableObject.toString();

				String criticalFlag = null;
				String isRefCheckReq = null;
				String isTestCaseReq = null;
				String methodName = null;
				int testCaseId = 0;
				boolean testCaseInProgress = false;
				boolean testTableInProgress = false;

				if (!parentTable.isEmpty() && parentTable != null && !tableLoadCompleteQueryResults.contains(parentTable)) {
					logger.debug("parent table not found");
					continue;
				}
				loggerUtils.createLogFile(tableName,razorEnv);
				logger.info("Test Case Map Query: " + testCaseMapQuery);
				isTestFailed = false;
				if (!testCaseMapQueryResult.isEmpty()) {
					isReportGenReq = true;
					// Set this test table in progress in appl_tbl_appl_test_trkr
					String insertForTracking = "INSERT INTO " + trgSchema + ".appl_tbl_appl_test_trkr(appl_tbl_nme,appl_tbl_appl_test_stat,appl_tbl_appl_test_run_dt)" + " VALUES ('" + tableName
							+ "','IN PROGRESS',current_date::timestamp::date)";
					trgDB.execute(insertForTracking);
					impl.startValidations(tableName);
					for (Map<String, Object> m : testCaseMapQueryResult) {
						testCaseInProgress = false;
						Object testCaseIdObject = m.get("appl_test_case_id");
						Object testCaseNameObject = m.get("appl_test_case_nme");
						Object criticalFlagObject = m.get("appl_test_case_cntl_ind");
						Object refCheckFlagObject = m.get("appl_ref_chk_reqd_ind");
						Object testCaseReqFlagObject = m.get("appl_test_case_reqd_ind");
						testCaseId = testCaseIdObject == null ? null : ((BigDecimal) testCaseIdObject).intValue();
						methodName = testCaseNameObject == null ? null : testCaseNameObject.toString();
						criticalFlag = criticalFlagObject == null ? "N" : criticalFlagObject.toString();
						isRefCheckReq = refCheckFlagObject == null ? "N" : refCheckFlagObject.toString();
						isTestCaseReq = testCaseReqFlagObject == null ? "Y" : testCaseReqFlagObject.toString();
						// TODO: Once the flag for testCase required is enabled in db, checking for testCAseId == 0 should be cleared out
						if (testCaseId == 0 || !parentTable.isEmpty() && !tableLoadCompleteQueryResults.contains(parentTable)) {
							continue;
						}
						String insertForTestCaseTracking = "INSERT INTO " + trgSchema + ".appl_test_case_trkr (appl_tbl_nme,appl_test_case_id,appl_test_case_stat,appl_test_case_strt_tm)" + " VALUES('"
								+ tableName + "'," + testCaseId + "," + "'IN PROGRESS'" + ",now())";
						trgDB.execute(insertForTestCaseTracking);
						Method validationMethod = null;

						try {
							validationMethod = impl.getClass().getMethod(methodName, String.class, String.class, String.class, String.class, String.class, int.class);
						    throw new NoSuchMethodException();
						} catch (NoSuchMethodException e) {
							logger.debug("	*** Error in loading method " + methodName + ".  Method Not Found.  Please check test case lookup table...");
							e.printStackTrace();
						} catch (SecurityException e1) {
							e1.printStackTrace();
						}
						try {
							errorCode = (Integer) validationMethod.invoke(impl, tableName, parentTable, criticalFlag, isRefCheckReq, isTestCaseReq, testCaseId);
							if (errorCode == 1 && !isCritical)
								isCritical = true;
						} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e1) {
							logger.error("	*** Error occured in the process.  Please check the logs...");
							e1.printStackTrace();
						}

						String updateTestCaseToCompleted = "UPDATE " + trgSchema + ".appl_test_case_trkr " + "SET appl_test_case_stat = 'COMPLETED'," + "appl_test_case_end_tm = now()"
								+ " WHERE appl_tbl_nme = '" + tableName + "'" + " AND appl_test_case_id = '" + testCaseId + "'" + " AND rec_cren_tm = (select max(rec_cren_tm) from " + trgSchema
								+ ".appl_test_case_trkr where appl_tbl_nme = '" + tableName + "' AND appl_test_case_id = '" + testCaseId + "')";
						String updateTestCaseToFailed = "UPDATE " + trgSchema + ".appl_test_case_trkr " + "SET appl_test_case_stat = 'FAILED'," + "appl_test_case_end_tm = now(),"
								+ "appl_test_case_fail_rsn_txt = 'FAILED'" + " WHERE appl_tbl_nme = '" + tableName + "'" + " AND appl_test_case_id = '" + testCaseId + "'"
								+ " AND rec_cren_tm = (select max(rec_cren_tm) from " + trgSchema + ".appl_test_case_trkr where appl_tbl_nme = '" + tableName + "' AND appl_test_case_id = '"
								+ testCaseId + "')";
						if (errorCode == 0) {
							// turn to completed only if the test case is not in progress
							if (!testCaseInProgress) {
								trgDB.update(updateTestCaseToCompleted);
							}
						} else {
							trgDB.update(updateTestCaseToFailed);
							isTestFailed = true;
						}
					}	// for - testcases

					// All test cases for the table are done -- Update table as COMPLETED
					String updateTblTrkrStatusToCompleted = "UPDATE " + trgSchema + ".appl_tbl_appl_test_trkr SET appl_tbl_appl_test_stat = 'COMPLETED' " + "WHERE appl_tbl_nme = '" + tableName + "'"
							+ " AND rec_cren_tm = (select max(rec_cren_tm) from " + trgSchema + ".appl_tbl_appl_test_trkr where appl_tbl_nme = '" + tableName + "')";
					String updateTblTrkrStatusToFailed = "UPDATE " + trgSchema + ".appl_tbl_appl_test_trkr SET appl_tbl_appl_test_stat = 'FAILED' " + "WHERE appl_tbl_nme = '" + tableName + "'"
							+ " AND rec_cren_tm = (select max(rec_cren_tm) from " + trgSchema + ".appl_tbl_appl_test_trkr where appl_tbl_nme = '" + tableName + "')";
					if (isTestFailed) {
						// ToDo Need to handle Critical (1), Error (2) and Warning(3) and insert records into the error table accordingly
						trgDB.update(updateTblTrkrStatusToFailed);
					} else if (!isTestFailed && !testTableInProgress) {
						trgDB.update(updateTblTrkrStatusToCompleted);
					}

				} else {
					logger.warn("WARNING:  No Test Case mapping found in APPL_TBL_TEST_CASE_MAP for the table " + tableName);
				}

				impl.endValidations(tableName);
				if (runAdhocQueries) {
					errorCode = impl.runAdhocQueries(tableLoadCompleteQueryResults,razorEnv);
					runAdhocQueries = false;

				}
			}
			if(!tablesBeingValidated.isEmpty() && isReportGenReq) generateReport(trgSchema);
			if(isCritical){
				logger.info("*****************************************************************************************************");
				logger.info("*****************************************************************************************************");
				logger.info("*****************************************************************************************************");
				logger.info(" ");
				logger.fatal("CRITICAL ERRORS FOUND IN THE PROCESS.  EXITING THE APPLICATION AND SENDING ALARM FOR FUTHER ACTION....");
				logger.info(" ");
				logger.info("*****************************************************************************************************");
				logger.info("*****************************************************************************************************");
				logger.info("*****************************************************************************************************");
				System.exit(1);
			}
		}
	} 
private void generateReport(String trgSchema) {
		
		List<String> headerList = new ArrayList<String>();
		headerList.addAll(Arrays.asList("Table Name","Test Case Name","Error Type","Error Description","Test Run Date"));
		List<Body> bodyElements = new ArrayList<Body>();
		for(int i=3;i>=0;i--){
			String errorType = getReportType(i); 
			String[] errorTypes = errorType.split(":");
			List <Map<String, Object>> reportQueryResult = getQueryResults(errorTypes[0],trgSchema);
			Body bodyElement = new Body();
			Table htmlTable = new Table();
			String noErrorMsg = "";
			if("Data Validation Adhoc Query Results".equals(errorTypes[1])){
				headerList.set(0, "Adhoc Query Name");
				headerList.set(3,"Adhoc Query Result");
			}
			if(reportQueryResult.isEmpty()){
				noErrorMsg = "No "+errorTypes[1]+" found for this run ";
				bodyElement.setSubHeading(errorTypes[1], "h3")
				   		   .setTextBlock(noErrorMsg);
				bodyElements.add(bodyElement);
			}
			else{
				Row headerRow = new Row();
				headerRow.setColumns(headerList,true);
				htmlTable.setHeader(headerRow);
				List<Row> dataRows = new ArrayList<Row>();
				for (Map<String, Object> m : reportQueryResult){
					List<String> columnList = new ArrayList<String>();
					columnList.add(m.get("appl_tbl_nme").toString());
					columnList.add(m.get("appl_test_case_id").toString() + "-" + m.get("appl_test_case_nme").toString());
					columnList.add(m.get("appl_test_case_err_dtl_typ").toString());
					columnList.add(m.get("appl_test_case_err_dtl_desc").toString());
					columnList.add(m.get("rec_cren_tm").toString());
					Row dataRow = new Row();
					dataRow.setColumns(columnList,false);
					dataRows.add(dataRow);
				}
				htmlTable.setRows(dataRows);
			    bodyElement.setSubHeading(errorTypes[1], "h3")
						   .setTextBlock(noErrorMsg)
						   .setTable(htmlTable);
				bodyElements.add(bodyElement);
			}
		}
			String fileName = "DataValidationSummary_" + timestamp;
			HtmlBuilder htmlBuilder = new HtmlBuilder();
			reportsOutput = null;
			if (razorEnv.equalsIgnoreCase("local")) {
				reportsOutput = LocalConfUtils.getRootDir() + File.separator + "Logs" + File.separator + dt;
			} else {
				reportsOutput = "/export/appl/fn3" + razorEnv + "/datavalidator/log/" + dt;
				logger.info(":: OUTPUT DIRECTORY: " + reportsOutput);
			}
			htmlBuilder.setStyle(buildStyleSheet())
					   .setHeading("Data Validation Report", "h1")
					   .setDiv(bodyElements)
					   .setTitle("Data Validation Report")
					   .buildHtml(reportsOutput+File.separator + fileName);
					   
	}
	private Style buildStyleSheet() {
	Style style = new Style();
	style.setHeading("h1", "Black", "helvetica", "center")
      .setHeading("h3", "black", "helvetica", "left")
      .setBody("white")
      .setParagraph("helvetica", "20", "blue")
      .setTableBorder("1px solid black", "collapse")
      .setTableHeader("white", "#1d4165","center")
      .setColum(5, "left");
	return style;
}

	private List <Map<String, Object>> getQueryResults(String errorCriteria,String trgSchema){
		String reportQuery = "select err.appl_tbl_nme,err.appl_test_case_id,lkup.appl_test_case_nme,dtl.appl_test_case_err_dtl_typ,dtl.appl_test_case_err_dtl_desc,dtl.rec_cren_tm "
				+ "from " + trgSchema + ".appl_test_case_err err join " + trgSchema + ".appl_test_case_err_dtl dtl on err.appl_test_case_err_obj_id = dtl.appl_test_case_err_obj_id "
				+ "join " + trgSchema +".appl_test_case_lkup lkup on err.appl_test_case_id = lkup.appl_test_case_id::char "
				+ "where  to_char(dtl.rec_cren_tm, 'YYYY-MM-DD HH24') = to_char(current_timestamp, 'YYYY-MM-DD HH24')"  // to_char(current_timestamp, 'YYYY-MM-DD HH24:MI')
				//+ "where  dtl.rec_cren_tm::date = '2018-07-18'" 
				+ "and dtl.appl_test_case_err_dtl_typ = '" + errorCriteria + "'";
		List <Map<String, Object>> reportQueryResult = trgDB.queryForList(reportQuery);
		logger.info("Report Sql: " + reportQuery);
		return reportQueryResult;
	}
	private String getReportType(int type){
		String reportType = null;
		switch (type){
			case 0: reportType = "INFO:Data Validation Adhoc Query Results";
			break;
			case 1: reportType = "WARNING:Data Validation Warnings";
			break;
			case 2: reportType = "ERROR:Data Validation Errors";
			break;
			case 3: reportType = "CRITICAL:Data Validation Critical Errors";
			break;
			default: reportType = "Invalid Report Type";
			break;
		}
		return reportType;
	}

	private List<String> removeElementsFromList(List<String> list1, List<String> list2) {
		List<String> ret = list1.stream().filter(o -> !list2.contains(o)).collect(Collectors.toList());
		return ret;
	}

	
}
