package com.fanniemae.razor.automation.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.stereotype.Component;

import com.fanniemae.razor.automation.common.CommonConstants;
import com.fanniemae.testeng.automation.exceptions.TestingException;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;
import com.fanniemae.testeng.automation.utils.DateUtils;

@Component
public class LocalDateUtils {

	public static String fetchNextBusinessDay(String dateStr, int workingDaysToAdd, String dateFormat) throws TestingException 
	{
		Date date = DateUtils.stringToDate(dateStr, dateFormat);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
	
        // add the working days
        for (int i=0; i<workingDaysToAdd; i++)
            do {
                cal.add(Calendar.DAY_OF_MONTH, 1);
            } while ( ! isWorkingDay(cal));
        
        CucumberLogUtils.logDebug("Date changed to - " + DateUtils.dateToString(cal.getTime(), dateFormat));
        return DateUtils.dateToString(cal.getTime(), dateFormat);
    }

    private static boolean isWorkingDay(Calendar cal) {
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayOfWeek == Calendar.SUNDAY || dayOfWeek == Calendar.SATURDAY){
            return false;
        }
        else {
        	return true;
        }
    }
    
    public static String getLocalDateTimebyFormat(String dateFormat) {
    	LocalDateTime localDateTime = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);

	    String formattedDateTime = localDateTime.format(formatter);
		CucumberLogUtils.logDebug("date Time - " + formattedDateTime);
		return formattedDateTime;
    }
    
   
  //TODO use latest Java8 Date utilities
    public static Date getDateFormat(String dateString) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date utilDate = null;
		try {
			utilDate = formatter.parse(dateString);
		} catch (ParseException e) {
			CucumberLogUtils.logFail("Error in date format ", false);
		}
		return utilDate;
	}
    
    public static void main(String[] args) throws TestingException{
//		String dateInput = "02/03/2017 13:25:10";
//		String dateFormat = "MM/dd/yyyy HH:mm:ss";
//		int daysToAdd = 4;
//		LocalDateUtils.fetchNextBusinessDay(dateInput, daysToAdd, dateFormat);
		String dateStr = LocalDateUtils.getLocalDateTimebyFormat(CommonConstants.LONG_DATE_TIME_IN_MILLSEC_FORMAT);
		System.out.println("Date - " + dateStr);
	}
    
    //TODO use latest Java8 Date utilities
	public static XMLGregorianCalendar toXMLGregorianCalendar(String dateString) {
		Date date = getDateFormat(dateString);
		GregorianCalendar gCalendar = new GregorianCalendar();
		gCalendar.setTime(date);
		XMLGregorianCalendar xmlCalendar = null;
		try {
			xmlCalendar = DatatypeFactory.newInstance()
					.newXMLGregorianCalendar(gCalendar);
		} catch (DatatypeConfigurationException ex) {
			CucumberLogUtils.logFail("Error in date format ", false);
		}
		return xmlCalendar;
	}
	
	

	public static String getLogTime() {
		return getLocalDateTimebyFormat("yyyy-MM-dd HH:mm:ss:SSS");
	}


	//TODO use latest Java8 Date utilities
	public static String getTomorrowTimeStampByFormat(String format) {
		DateFormat dateFormat;
		dateFormat = new SimpleDateFormat(format);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		return dateFormat.format(cal.getTime());

	}
	
	

}
