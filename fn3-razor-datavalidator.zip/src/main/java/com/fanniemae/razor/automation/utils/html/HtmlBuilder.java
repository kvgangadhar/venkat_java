package com.fanniemae.razor.automation.utils.html;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class HtmlBuilder {

	private String title;
	private Style style;
	private Date date = new Date();
	private String divTag = "";
	private String heading = "";
	SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");
	public HtmlBuilder setHeading(String heading, String headingType) {
		this.heading = "<"+headingType+">" + heading + "</"+headingType+">";;
		return this;
	}
	public HtmlBuilder setDiv(List<Body> bodyElements){
		for (Body bodyElement:bodyElements){
		divTag = divTag + "<div> " + bodyElement.toString() + "</div>";
		}
		return this;
	}
	
	public HtmlBuilder setStyle(Style style){
		this.style = style;
		return this;
	}
	
	public HtmlBuilder setTitle(String title){
		this.title = title;
		return this;
	}
	public void buildHtml(String fileName){
		File file = new File(fileName + ".html");
		FileWriter fileWriter = null;
		BufferedWriter bufferedWriter = null;
		try{
			fileWriter = new FileWriter(file);
			bufferedWriter = new BufferedWriter(fileWriter);
			
			String htmlPage = "<!DOCTYPE html> <html> "
					+ "<head> " + style.toString() + " </head>"
					+ "<body> " + heading + divTag + " </body> </html>" ;
			bufferedWriter.write(htmlPage);
			bufferedWriter.flush();
			fileWriter.flush();
		}
		catch (IOException ioe){
			ioe.printStackTrace();
		}
	}
}
