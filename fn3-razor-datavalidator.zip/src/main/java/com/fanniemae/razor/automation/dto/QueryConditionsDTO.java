/**
 * 
 */
package com.fanniemae.razor.automation.dto;

import java.util.List;
import java.util.Map;

/**
 * @author sxusyp
 *
 */
public class QueryConditionsDTO {
	
	private String source;
	private Map<String,QueryParametersDTO> sourceContditions;  //Rename to queryParameters
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public Map<String, QueryParametersDTO> getSourceContditions() {
		return sourceContditions;
	}
	public void setSourceContditions(Map<String, QueryParametersDTO> sourceContditions) {
		this.sourceContditions = sourceContditions;
	}
		
}
