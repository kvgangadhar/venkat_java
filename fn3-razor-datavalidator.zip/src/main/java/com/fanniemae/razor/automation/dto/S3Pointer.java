package com.fanniemae.razor.automation.dto;

public class S3Pointer {
    private String s3BucketName;
    private String s3Key;
    private String requestId;
    private String claimTransactionId;
	public String getS3BucketName() {
		return s3BucketName;
	}
	public void setS3BucketName(String s3BucketName) {
		this.s3BucketName = s3BucketName;
	}
	public String getS3Key() {
		return s3Key;
	}
	public void setS3Key(String s3Key) {
		this.s3Key = s3Key;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getClaimTransactionId() {
		return claimTransactionId;
	}
	public void setClaimTransactionId(String claimTransactionId) {
		this.claimTransactionId = claimTransactionId;
	}
    
    
    
}
