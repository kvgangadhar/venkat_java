/*package com.fanniemae.razor.automation.utils.html;

import java.util.ArrayList;
import java.util.List;

public class BuildHtml {

	
	public static void main(String[] args) {
		BuildHtml html = new BuildHtml();
		List<String> tableHeader = html.getHeaderData();
		List<String> tableData = html.getData();
		List<Column> headerList = new ArrayList<Column>();
		List<Column> columnList = new ArrayList<Column>();
		for(String cdata:tableHeader){
			Column column = new Column();
			column.setColumn(cdata, true);
			headerList.add(column);
		}
		Row row = new Row();
		row.setColumns(headerList);
		Table table = new Table();
		table.setHeader(row);
		List<Row> dataRows = new ArrayList<Row>();
		Row dataRow1 = new Row();
		columnList = new ArrayList<Column>();
		for(String cdata:tableData){
			Column column = new Column();
			column.setColumn(cdata, false);
			columnList.add(column);
		}
		dataRow1.setColumns(columnList);
		dataRows.add(dataRow1);
		table.setRows(dataRows);
		
		Body body = new Body();
		body.setHeading("Data Validation Report", "h1")
			.setSubHeading("Report for LN table", "h3")
			.setTable(table);
		HtmlBuilder htmlBuilder = new HtmlBuilder();
		htmlBuilder.setDiv(body)
				   .setTitle("Data Validation Report")
				   .buildHtml("C://Developers//DataValidationSummary");
	}
	private List<String> getData() {
		List<String> data = new ArrayList<String>(); 
		data.add("Header1");
		data.add("Header2");
		data.add("H3");
		data.add("H4");
		return data;
	}
	public List<String> getHeaderData(){
		List<String> data = new ArrayList<String>(); 
		data.add("H1");
		data.add("H2");
		data.add("Header3");
		data.add("Header4");
		return data;
	}

}
*/