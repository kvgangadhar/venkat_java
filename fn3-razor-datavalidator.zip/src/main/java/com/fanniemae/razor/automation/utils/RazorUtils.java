package com.fanniemae.razor.automation.utils;

import static com.fanniemae.razor.automation.common.CommonConstants.LONG_DATE_TIME_FORMAT2;
import static com.fanniemae.razor.automation.common.CommonConstants.SHORT_DATE_FORMAT;
import static com.fanniemae.razor.automation.common.CommonConstants.TODAYS_DATE_PLACEHOLDER;
import static com.fanniemae.razor.automation.common.CommonConstants.TODAYS_DATE_TIME_PLACEHOLDER;
import static com.fanniemae.razor.automation.common.CommonConstants.TOMORROW_DATE_PLACEHOLDER;
import static com.fanniemae.razor.automation.common.CommonConstants.TODAYS_DATE_TIME_IN_MILLSEC_PLACEHOLDER;
import static com.fanniemae.razor.automation.common.CommonConstants.LONG_DATE_TIME_IN_MILLSEC_FORMAT;

import java.util.HashMap;
import java.util.Map;

import com.fanniemae.testeng.automation.utils.CucumberLogUtils;

public final class RazorUtils {

    public static String convertPlaceholders(String value) {
		String convertedValue = value;
		for (Converter converters : Converter.values()) {
			convertedValue = converters.convert(convertedValue);
		}
		return convertedValue;
	}

	private enum Converter {
		
		TODAYS_DATE_TIME {
			public String convert(String value) {
				if (value.contains(TODAYS_DATE_TIME_PLACEHOLDER)) {
					return value.replace(TODAYS_DATE_TIME_PLACEHOLDER, LocalDateUtils.getLocalDateTimebyFormat(LONG_DATE_TIME_FORMAT2));
				}
				return value;
			}
		},
		TODAYS_DATE_TIME_IN_MILLSEC {
			public String convert(String value) {
				if (value.contains(TODAYS_DATE_TIME_IN_MILLSEC_PLACEHOLDER)) {
					return value.replace(TODAYS_DATE_TIME_IN_MILLSEC_PLACEHOLDER, LocalDateUtils.getLocalDateTimebyFormat(LONG_DATE_TIME_IN_MILLSEC_FORMAT));
				}
				return value;
			}
		},
		
		TODAYS_DATE {
			public String convert(String value) {
				if (value.contains(TODAYS_DATE_PLACEHOLDER)) {
					return value.replace(TODAYS_DATE_PLACEHOLDER, LocalDateUtils.getLocalDateTimebyFormat(SHORT_DATE_FORMAT));
				}
				return value;
			}
		},
		
		TOMORROW_DATE {
			public String convert(String value) {
				if (value.contains(TOMORROW_DATE_PLACEHOLDER)) {
					return value.replace(TOMORROW_DATE_PLACEHOLDER, LocalDateUtils.getTomorrowTimeStampByFormat(SHORT_DATE_FORMAT));
				}
				return value;
			}
		};
		
		public abstract String convert(String value);
	}
	
	public static void commonValidation(boolean actualValue, boolean expectedValue, String validationMsg){
        if (actualValue == expectedValue) {
            CucumberLogUtils.logPass(validationMsg + " :: SUCCESS", true);
        } else {
            CucumberLogUtils.logFail(validationMsg + " :: FAILED", true);
        }
	}
	
   public static void commonStringValidation(String actualValue, String expectedValue){
        if (actualValue.equalsIgnoreCase(expectedValue)) {
            CucumberLogUtils.logPass("ACTUAL STRING :: " +actualValue+" :: MATCHES EXPECTED STRING :: "+expectedValue, true);
        } else {
            CucumberLogUtils.logFail("ACTUAL STRING :: " +actualValue+" :: DOES NOT MATCH EXPECTED STRING :: "+expectedValue, true);
        }
    }
   
   public static Map<String, String> generateUniqueParam(Map<String, String> requestParam) {
	   Map<String, String> modifiedParamMap = new HashMap<>();
		requestParam.forEach((String key, String value) -> {
			String temp = RazorUtils.convertPlaceholders(value);
			CucumberLogUtils.logDebug("Actual-"  + value + " &  NewValue-" + temp);
			modifiedParamMap.put(key, temp);
		});
		return modifiedParamMap;
				
	}
   
   
}
