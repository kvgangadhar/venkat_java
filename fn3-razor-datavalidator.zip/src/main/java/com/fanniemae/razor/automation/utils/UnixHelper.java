/*
 * Copyright (c) 2013 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.razor.automation.utils;


import java.io.File;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fanniemae.testeng.automation.exceptions.TestingException;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;
import com.fanniemae.testeng.automation.utils.SSHUtils;

/**
 * Unit Helper implementation class to run Unix commands 
 * @author q2uscv
 *
 */
@Component
public class UnixHelper {
	
	@Autowired
	private EnvUtils envUtils;
	
	private static final String COMMAND_LATEST_FILE = "ls -1 %s | tail -1";
	private static final String COMMAND_LINECOUNT_FOR_LATEST_FILE = COMMAND_LATEST_FILE + " | xargs -i wc -l {}";
	
	/**
	 * Verify if directory is Empty. 
	 * @param directory
	 * @throws TestingException
	 */
    public void verifyDirectoryIsEmpty(String directory) throws TestingException {
        if (countNumberOfFilesInDir(directory) == 0)
            CucumberLogUtils.logPass("Directory is empty", false);
        else
            CucumberLogUtils.logFail("Directory is not empty", false);
    }

    /**
     * Verify if file Exiists in the given direcory location
     * @param files
     * @param directory
     * @return
     * @throws TestingException
     */
    public boolean verifyFilesExists(String files, String directory) throws TestingException {
        String[] fileList = files.split(",");
        for (String file : fileList) {
            String fileAbsolutePath = directory + "/" + file;
            if (!verifyFileExistsInremoteServer(fileAbsolutePath)) {
                CucumberLogUtils.logFail("File " + fileAbsolutePath + " doesnt exists", false);
                return false;
            }
        }
        CucumberLogUtils.logPass("Files " + files + " exists", false);
        return true;
    }

    public boolean verifyFileExistsInremoteServer(String fileWithAbsolutePath) throws TestingException {
        return SSHUtils.fileExists(envUtils.getUnixServer(), envUtils.getUnixLoginId(), envUtils.getUnixPassword(),
                fileWithAbsolutePath);
    }

    /**
     * Fetch number of files in the directory
     * @param dirPath
     * @return
     * @throws TestingException
     */
    public Integer countNumberOfFilesInDir(String dirPath) throws TestingException {
        return SSHUtils.countFilesInDirectory(envUtils.getUnixServer(), envUtils.getUnixLoginId(),
        		envUtils.getUnixPassword(), dirPath);
    }
    
    /**
     * Fetch latest file in the directory matching with the filename Regex
     * @param remoteDirPath
     * @param fileName
     * @return
     * @throws TestingException
     */
    public String getLatestFileNameFromDirectory(String remoteDirPath, String fileName) throws TestingException {
    	String latestFileCommand =  String.format(COMMAND_LATEST_FILE, remoteDirPath+fileName);
    	System.out.println("latestFileCommand = " + latestFileCommand);
    	List<String> results = SSHUtils.executeCommand(envUtils.getUnixServer(), envUtils.getUnixLoginId(), envUtils.getUnixPassword(), latestFileCommand);
    	if(CollectionUtils.isNotEmpty(results)) {
    		return results.get(0);
    	} else { 
    		return null;
    	}
    }
    
    /**
     * Fetch row cound in the latest file matching with the filename Regex
     * @param directoryPath
     * @param fileName
     * @return
     * @throws TestingException
     */
    public String fetchNumOfLinesinLatestFile(String directoryPath, String fileName) throws TestingException {
    	//SystemCredentials credentials = new SystemCredentials(unixServer, unixLoginId, unixPwdEncrypted);
    	String latestFileCommand =  String.format(COMMAND_LINECOUNT_FOR_LATEST_FILE, directoryPath+fileName);
    	CucumberLogUtils.logDebug("latestFileCommand = "  + latestFileCommand);
    	List<String> results = SSHUtils.executeCommand(envUtils.getUnixServer(), envUtils.getUnixLoginId(), envUtils.getUnixPassword(), latestFileCommand);
    	if(CollectionUtils.isNotEmpty(results)) {
    		return results.get(0).split(" ")[0].trim();
    	} else { 
    		return null;
    	}
    }
    
    public void downloadFile(String remoteDirPath, String fileName, String localDirPath) throws TestingException {
    	//localDirPath = "/temp";
    	CucumberLogUtils.logInfo("About to download file - " + fileName);
    	String fileNameWithoutDirPath = this.getFileNameWithoutDirPath(fileName);
    	SSHUtils.downloadFile(envUtils.getUnixServer(), envUtils.getUnixLoginId(), envUtils.getUnixPassword(), remoteDirPath, fileNameWithoutDirPath, localDirPath);
    }
    
    public void downloadFile(String fileNameWithPath, String localDirPath) throws TestingException {
    	File file = new File(fileNameWithPath);
    	String remoteDirPath = file.getPath();
    	String fileNameWithoutPath = file.getName();
    	CucumberLogUtils.logInfo("About to download file - " + fileNameWithoutPath);
    	SSHUtils.downloadFile(envUtils.getUnixServer(), envUtils.getUnixLoginId(), envUtils.getUnixPassword(), remoteDirPath, fileNameWithoutPath, localDirPath);
    }

    public String getFileNameWithoutDirPath(String fileNameWithDirPath) {
    	String fileNameWithoutDirPath = "";
    	if(StringUtils.isNotBlank(fileNameWithDirPath)) {
        	int index = fileNameWithDirPath.lastIndexOf("/");
        	fileNameWithoutDirPath = fileNameWithDirPath.substring(index+1);
    	}
    	CucumberLogUtils.logDebug("FileName cleansed - "  + fileNameWithoutDirPath);
    	return fileNameWithoutDirPath;
    }
    
    public String getLatestSubmittedDTFReport() throws TestingException, InterruptedException {
//    	String unixCommandToGetLatestRunFile = "find /appl/fbjtest/src/dtf/reports/ -mindepth 1 -mmin -3 | grep username";
    	//TODO
    	String unixCommandToGetLatestRunFile = "Write the actual command";
    	String fileName = null;
    	
    	//TODO Enhance this logic to run asynchronously
    	while (fileName == null) {
    		List<String> results = SSHUtils.executeCommand(envUtils.getUnixServer(), envUtils.getUnixLoginId(), envUtils.getUnixPassword(), unixCommandToGetLatestRunFile);
        	if(CollectionUtils.isNotEmpty(results)) {
        		CucumberLogUtils.logToConsole("Latest fileName = " + results.get(0) );
        		fileName = results.get(0);
        	} else {
        		CucumberLogUtils.logToConsole("Unable to find latest DTF report file. Sleeping for 3 minutes");
        		Thread.sleep(120000);
        	}
    	}
    	return fileName;
    }
 }
