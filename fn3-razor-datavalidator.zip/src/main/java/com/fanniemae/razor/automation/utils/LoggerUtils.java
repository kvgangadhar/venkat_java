package com.fanniemae.razor.automation.utils;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.stereotype.Component;

import com.fanniemae.razor.automation.DataValidator;
import com.fanniemae.testeng.automation.utils.LocalConfUtils;
@Component
public class LoggerUtils {
	@Autowired
	private GenericApplicationContext applicationContext;
	Logger logger = Logger.getLogger(DataValidator.class.getName());
	FileAppender myFileAppender;
	DateFormat dateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
	Date date = new Date();
	String timestamp = dateTimeFormat.format(date);
	DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	String dt = dateFormat.format(date);
	String reportsOutput = null;
	boolean isSkippingValidation = false;
	/**
	 * This method opens log file with name based on the tablename passed.
	 * 
	 * @param tableName
	 */
	public void createLogFile(String tableName, String razorEnv) {

		if (razorEnv.equalsIgnoreCase("local")) {
			reportsOutput = LocalConfUtils.getRootDir() + File.separator + "Logs" + File.separator + dt;
		} else {
			reportsOutput = "/export/appl/fn3" + razorEnv + "/datavalidator/log/" + dt;
			//logger.info(":: OUTPUT DIRECTORY: " + reportsOutput);
		}

		ConfUtils.setBaseResultsDir(reportsOutput);

		PatternLayout patternLayout = new PatternLayout();
		patternLayout.setConversionPattern("[%p] %d{MM-dd-yyyy HH:mm:ss} - %m%n");

		try {
			myFileAppender = new FileAppender(patternLayout, reportsOutput + File.separator + tableName + "_" + timestamp + ".log", false);
			myFileAppender.setThreshold(Level.INFO);
			BasicConfigurator.resetConfiguration();
			BasicConfigurator.configure(myFileAppender);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	


}
