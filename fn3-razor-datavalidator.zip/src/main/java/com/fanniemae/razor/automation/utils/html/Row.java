package com.fanniemae.razor.automation.utils.html;

import java.util.List;

public class Row {
	private String font,size;
	private List<Column> columns;
	private String tableRow = "";
	private StringBuilder row;
	public Row setFont(String font){
		this.font = font;
		return this;
	}
	public Row setColor(String size){
		this.size = size;
		return this;
	}
	
	public Row setColumns(List<String> columnData,boolean isHeader){
		row = new StringBuilder();
		for(String columnString:columnData){
			row.append(addColumn(columnString,isHeader)) ;
		}
		return this;
	}
	public String addColumn(String column, boolean isHeader){
		String tag = isHeader?"<th>":"<td>";
		String endTag = tag.replace("<","</");
		String columnString = tag + column + endTag;
		return columnString;
	}
	@Override
	public String toString(){
		tableRow = "<tr> " + row + " </tr>";
		return tableRow;
	}
}
