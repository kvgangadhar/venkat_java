package com.fanniemae.razor.automation.utils.html;

public class Column {

	private String column,font,size;
	private String tag,endTag;
	public String getColumn(){
		return column;
	}
	
	/*public void setColumn(String column, boolean isHeader){
		tag = isHeader?"<th>":"<td>";
		endTag = tag.replace("<","</");
		this.column = tag + column + endTag;
	}*/
	
}
