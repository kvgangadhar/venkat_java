package com.fanniemae.razor.aws.utils.LamdbaClient;

import com.amazonaws.services.lambda.invoke.LambdaFunction;

public interface LambdaService {
	//razor01-devl-BulkResponseHandler
	@LambdaFunction(functionName="razor01-devl-BulkResponseHandler")
	String fetchAddress(String addr);
}
