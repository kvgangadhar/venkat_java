/*
 * Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.razor.config;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fanniemae.razor.automation.steps.impl.DatabaseImpl;
import com.fanniemae.sharedservices.evas.VaultFactory;
import com.fanniemae.sharedservices.evas.exception.ServiceException;
import com.fanniemae.sharedservices.evas.vault.Vault;
import com.fanniemae.sharedservices.evas.vault.object.PasswordObject;
import com.fanniemae.testeng.automation.utils.EncryptionUtils;

@Configuration
@ComponentScan(basePackages = "com.fanniemae.razor")
@PropertySource(value="file:${configurationFile}")
public class ApplicationConfig {

	@Autowired
	private Environment env;
	
	private String awsAccessKeyId = null;
	private String awsSecretAccessKey = null;
	private String razorEnv = null;
	
	public ApplicationConfig() {
		razorEnv = System.getProperty("razor_env_path");
	}
	
	@Bean(name = "stagingDataSource")
    public DataSource stagingDataSource() {
    	BasicDataSource dataSource = new BasicDataSource();   
    	String password = null;
    	String envCode = env.getRequiredProperty("db.envcode");
    	String appCode = env.getRequiredProperty("db.appcode");
        dataSource.setDriverClassName(env.getRequiredProperty("aws.stage.dbconn.driver"));
        dataSource.setUrl(env.getRequiredProperty("aws.stage.dbconn.url"));
        dataSource.setUsername(env.getRequiredProperty("aws.stage.dbconn.username"));
        dataSource.setInitialSize(Integer.parseInt(env.getRequiredProperty("aws.stage.dbconn.cache.min")));
        dataSource.setMaxActive(Integer.parseInt(env.getRequiredProperty("aws.stage.dbconn.cache.max")));
    	if(isLocalEnviorment()){
    		password = EncryptionUtils.decrypt(env.getRequiredProperty("aws.stage.dbconn.password"));
	        dataSource.setPassword(password);
    	}else{
			try {
				password = getPasswordFromPAM(env.getRequiredProperty("aws.stage.dbconn.object.id"),envCode,appCode);
				dataSource.setPassword(password);
			} catch (IllegalStateException | ServiceException  e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
        return dataSource;
    }
    
	@Bean(name = "stagingJdbcTemplate") 
    public JdbcTemplate stagingJdbcTemplate(DataSource stagingDataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(stagingDataSource);
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        return jdbcTemplate;
    }
	
	/*@Bean(name = "srcJdbcTemplate") 
    public JdbcTemplate srcJdbcTemplate(DataSource srcDataSource) {
		String userName = env.getRequiredProperty("clm.dbconn.username");
		if(userName != null) {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(srcDataSource);
	        jdbcTemplate.setResultsMapCaseInsensitive(true);
	        return jdbcTemplate;
		} else {
			return null;
		}
        
    }*/
	
	@Bean(name = "srcDataSource")
	@Lazy(value = true)
    public DataSource srcDataSource(String srcPrefix) throws IllegalStateException, ServiceException {
    	BasicDataSource dataSource = new BasicDataSource(); 
    	String userName = env.getRequiredProperty(srcPrefix + ".dbconn.username");
    	String schema = env.getRequiredProperty(srcPrefix + ".dbconn.schema");
    	String envCode = env.getRequiredProperty("db.envcode");
    	String appCode = env.getRequiredProperty("db.appcode");
    	String connectionProperty = "schemaName="+schema;
    	String password;
        dataSource.setDriverClassName(env.getRequiredProperty(srcPrefix + ".dbconn.driver"));
        dataSource.setUrl(env.getRequiredProperty(srcPrefix + ".dbconn.url"));
        dataSource.setUsername(env.getRequiredProperty(srcPrefix + ".dbconn.username"));
        dataSource.setInitialSize(Integer.parseInt(env.getRequiredProperty(srcPrefix + ".dbconn.cache.min")));
        dataSource.setMaxActive(Integer.parseInt(env.getRequiredProperty(srcPrefix + ".dbconn.cache.max")));
        dataSource.setConnectionProperties(connectionProperty);
    	if(isLocalEnviorment() && (userName != null)){
    		password = EncryptionUtils.decrypt(env.getRequiredProperty(srcPrefix + ".dbconn.password"));
	        dataSource.setPassword(password);
    	}
    	else{
    		password = getPasswordFromPAM(env.getRequiredProperty(srcPrefix + ".dbconn.object.id"),envCode,appCode);
    		dataSource.setPassword(password);
    	}
        return dataSource;
    }
	
	@Bean(name = "databaseImpl")
	public DatabaseImpl databaseImpl(){
		return new DatabaseImpl();
	}
	   
    private boolean isLocalEnviorment(){
    	return razorEnv.equals("local")  ? true : false; 
    }
    
    private boolean isAWSAccessKeyProvided(){
    	return ((null == awsAccessKeyId)
    			&& (null == awsSecretAccessKey))  ? true : false; 
    }
    private String getPasswordFromPAM(String objID, String envCode, String appCode) throws ServiceException{
    	PasswordObject	passwordObj;
		Vault vault = VaultFactory.getVault(appCode, envCode);
		passwordObj  = (PasswordObject)vault.getVaultObject(objID);
    	return passwordObj.getPassword();
    }
}
