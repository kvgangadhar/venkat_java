package com.fanniemae.razor.config;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
@ComponentScan(basePackages = "com.fanniemae.razor")
@PropertySource(value="file:${configurationFile}")
public class StagingConfig {

	@Autowired
	private Environment env;
	
	@Bean(name = "stagingDataSource")
    public DataSource dataSource() {
    	BasicDataSource dataSource = new BasicDataSource();    
    	if(isLocalEnviorment()){
    	        dataSource.setDriverClassName(env.getRequiredProperty("aws.stage.dbconn.driver"));
    	        dataSource.setUrl(env.getRequiredProperty("aws.stage.dbconn.url"));
    	        dataSource.setUsername(env.getRequiredProperty("aws.stage.dbconn.username"));
    	        dataSource.setPassword(env.getRequiredProperty("aws.stage.dbconn.password"));
    	        dataSource.setInitialSize(Integer.parseInt(env.getRequiredProperty("aws.stage.dbconn.cache.min")));
    	        dataSource.setMaxActive(Integer.parseInt(env.getRequiredProperty("aws.stage.dbconn.cache.max")));
    	}else{
    		//Do to - Get from PAM
    	}
        return dataSource;
    }
    
	@Bean(name = "stagingJdbcTemplate") 
    public JdbcTemplate jdbcTemplate(DataSource transactionDataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(transactionDataSource);
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        return jdbcTemplate;
    }
        
    private boolean isLocalEnviorment(){
    	return System.getProperty("razor_env_path").equals("local") ? true : false; 
    }
}
