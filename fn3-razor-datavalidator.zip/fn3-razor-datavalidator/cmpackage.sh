#!/bin/sh

set -x
mkdir conf
mkdir cmpackage 
mkdir jil
mkdir -p config/conf
mv -vf conf/$ICART_LENV_NAME/*  ./config/conf/
mv -vf jilfiles/$ICART_LENV_NAME/*  ./jil/
mv -vf datavalidator.jar  cmpackage
mv -vf jil cmpackage
mv -vf data cmpackage
mv -vf scripts cmpackage

cd config/
mv -vf conf ../cmpackage

echo "Pre deploy for dataload is successful for $ENVIRONMENT."


exit 0

