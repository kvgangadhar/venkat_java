echo 'Job starting on ' `date`
#Path of the log file
DIR_PATH=/appl/$USER/datavalidator/log/
#No of days to retain
NO_OF_DAYS=2

declare -a attargs
for (( index=0; index<=$NO_OF_DAYS; index++ ))
do
        DATE=`date +%Y%m%d --date="-$index day"`
        attargs+=("-ve  $DATE" )
done
attargs+=("-ve FN3#cmd#RazorDataValidatorNotification")
attargs+=("-ve FN3#cmd#RazorDataValidator")
attargs+=("-ve FN3#cmd#DeleteRazorDataValidationLogs")
attargs+=("-ve Test")
PATHS="${attargs[@]}"
DATE1=`date +%d`
if [ "$DATE1" -gt 9 ]; then
files=`ls "$DIR_PATH" | grep $PATHS`
else
files=`ls "$DIR_PATH" | grep $PATHS`
fi
for file in $files
do
echo "Folder getting deleted": $file
rm -rf $DIR_PATH$file
done
echo 'Complete'
