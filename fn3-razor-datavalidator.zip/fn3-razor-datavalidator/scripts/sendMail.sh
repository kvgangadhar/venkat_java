echo 'Job starting...'
#Path of the log file
DIR_PATH=/appl/$USER/datavalidator/log/
#Today's date
DATE=`date +%Y%m%d`
DATE_HR=`date +%Y%m%d%H`

#Finding list of file from with '_YYYYMMDDHH*' format
for att in $(find $DIR_PATH$DATE/ -name "*_$DATE_HR*.log"); do
  attargs+=( "-a"  "$att" )
done

#Uncomment this line for viewing the file to be attached
echo "${attargs[@]}"

echo 'Sending email...'
if [ ${#attargs[@]} -eq 0 ]; then
echo "${attargs[@]} is empty"
echo 'Email not sent.'
else
        if [ "$USER" = "fn3devl" ]; then
        echo | mail -s "RAZOR Data Validation Logs - $DATE" "${attargs[@]}"  venkatarao_veerapaneni@fanniemae.com sarma_paturu@fanniema
e.com
        elif [ "$USER" = "fn3acpt" ]; then
                echo | mail -s "RAZOR Data Validation Logs - $DATE" "${attargs[@]}" venkatarao_veerapaneni@fanniemae.com sarma_paturu@fanniema
        elif [ "$USER" = "fn3prod" ]; then
                echo | mail -s "RAZOR Data Validation Logs - $DATE" "${attargs[@]}" RAZOR_IT_Support@fanniemae.com
        fi
echo 'Email sent.'
fi
echo 'Job completed'
