package com.fanniemae.razor.automation.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fanniemae.testeng.automation.utils.CucumberLogUtils;


/**
 * commonCache class contains instances of all the page implementation classes which will be 
 * used in the  automation application, which enables a centralized access point for navigating through 
 * the application page for testing scenario which involves navigating through back and forth through various pages. 
 * @author q2uscv
 */
@Scope(value = "singleton")
@Component
public final class CommonCache {
    
    /** commonCache instance */
    //private static CommonCache commonCache;

    
    /** cache implementation as a Map.   */
    private Map<String, Object> cache;

    /**
     * Overriding default constructor to stop class instances.
     */
    public CommonCache() {
    	cache = new HashMap<String, Object>();
    }
    
    /**
     * Returns the commonCache instance.
     * @return commonCache for the entire automation code.
     */
//    public static synchronized CommonCache getInstance() {
//        if (null == commonCache){
//            commonCache =  new CommonCache();
//        }
//        return commonCache;
//    }
    
    /**
     * Returns the instance of any object of the class of type T which is passed as the parameter.
     * If the instance is already created in the cache then it is returned if instance is not created
     * then new instance will be stored in the cache and returned. If the instanceName or type is null then 
     * a null value is returned from the cache.
     * @param t of Type instance.
     * @return T instance
     */
    @SuppressWarnings("unchecked")
    public <T> T getFromCache(Class<T> type, String instanceName) {
    	T typeInstance = null;
    	try {
    		if (null != instanceName && type != null) {
    			typeInstance = (T) this.cache.get(instanceName);
    	    	if (typeInstance == null) {
    	    		typeInstance = type.newInstance();
    	    		this.cache.put(instanceName, typeInstance);
    	    	} 
    		}

    	} catch (Exception exception) {
    		exception.printStackTrace();
    		typeInstance = null;
    	}
    	return typeInstance;
    }

    /**
     * To clear the cache after every scenario
     */
	public void clearAllCache() {
		CucumberLogUtils.logInfo("Clearing all the Cache");
		this.cache = new HashMap<>();
	}
	
	/**
     * To clear a specific instance of the cache 
     */
	public void clearCache(String instanceName) {
		CucumberLogUtils.logInfo("Clearing the Cache for instance - " + instanceName);
		if (null != instanceName) {
			this.cache.remove(instanceName);
		}
	}
	
	public void clearAllCacheExceptLookUpCodes() {
		CucumberLogUtils.logInfo("Clearing all the Cache except Lookup Codes");
		this.cache.keySet().removeIf(s -> !s.equals(CommonCacheConstants.LOOKUP_CODE_CACHE));
	}
}
