package com.fanniemae.razor.automation.common;

import com.jayway.restassured.http.ContentType;

/**
 * Enum of Service End Points and its details
 * @author q2uscv
 *
 */
public enum ServiceEndPointMappingsEnum {
	SINGLE_REQUEST_CONTROLLER_WITH_REQ_PARAMS_POST("request/single-claim?requestid=<requestId>&payload=<payload>","POST", ContentType.JSON),
	BULK_REQUEST_CONTROLLER_WITH_REQ_PARAMS_POST("request/bulk-claim?requestid=<requestId>&payload=<payload>","POST", ContentType.JSON),
	//CDX End point
	//SINGLE_REQUEST_CONTROLLER_WITH_REQ_PARAMS_POST("api/razor/processclaimdata?requestid=<requestId>&payload=<payload>","POST", ContentType.JSON),
	//SINGLE_REQUEST_CONTROLLER_WITH_REQ_PARAMS_POST("request/single-claim","POST", ContentType.JSON),
	SINGLE_RESPONSE_CONTROLLER_WITH_REQ_PARAMS_POST("responsehandler/response/single-claim?requestid=<requestId>","POST", ContentType.JSON);
	
	private String url;
    private String acceptedRequestMethod;
    private ContentType requestContentType;
    
    /**
     * named constructor.
     *
     * @param url
     */
    ServiceEndPointMappingsEnum(final String url,final String requestMethod,ContentType requestContentType) {
        this.url = url;
        this.acceptedRequestMethod = requestMethod;
        this.requestContentType = requestContentType;
    }

	/**
	 * @return the url
	 */
	public String getUrl()
	{
		return url;
	}

	/**
	 * @return the acceptedRequestMethod
	 */
	public String getRequestMethod()
	{
		return acceptedRequestMethod;
	}

	/**
	 * @return the requestContentType
	 */
	public ContentType getRequestContentType()
	{
		return requestContentType;
	}

}
