package com.fanniemae.razor.automation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.fanniemae.razor.automation.steps.impl.DatabaseImpl;
import com.fanniemae.razor.automation.utils.ConfUtils;
import com.fanniemae.razor.automation.utils.XmlUtils;
import com.fanniemae.razor.config.ApplicationConfig;
import com.fanniemae.testeng.automation.utils.LocalConfUtils;

@Component
@ComponentScan(basePackages = "com.fanniemae.razor")
public class DataValidatorLocal {

	private JdbcTemplate trgDB;
	private static String trgSchema;
	private static String configFile = "./conf/local/localConf.properties";
	private static String razorEnv = "local";
	private static final String underBarFiller = StringUtils.leftPad("", 100, "_");
	private static String tableKey = "";
	static Logger logger = Logger.getLogger(DataValidatorLocal.class.getName());

	public static void main(String[] args) {

		DataValidatorLocal app = new DataValidatorLocal();

		Set<String> tablesToValidate = new LinkedHashSet<>();
		if (args.length > 0) {
			tableKey = args[0];
			tablesToValidate.addAll(Arrays.asList(args));
			tablesToValidate.remove(tableKey);
		}
		app.startValidations(tablesToValidate);
	}

	/**
	 * Main method gets called from Autosys to initiate the validations process
	 * 
	 * @param tablesToValidate
	 */

	public void startValidations(Set<String> tablesToValidate) {
		System.getProperties().setProperty("razor_env_path", razorEnv);
		System.getProperties().setProperty("configurationFile", configFile);
		logger.info("BEGIN: RAZOR DATALOAD AUTOMATION TESTS IN " + razorEnv.toUpperCase() + " ON " + new Date().toString());
		logger.info("CONIFG FILE: " + configFile);
		try (final AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext()) {
			applicationContext.register(ApplicationConfig.class);
			applicationContext.refresh();

			Properties props = new Properties();
			try {
				FileInputStream fis = new FileInputStream(configFile);
				props.load(fis);
			} catch (FileNotFoundException fnfe) {
				fnfe.printStackTrace();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}

			String stgDbUserName = props.getProperty("aws.stage.dbconn.username");
			logger.info("Staging database User:  " + stgDbUserName.toUpperCase());
			String mappingFileName = props.getProperty("aws.stage.dataload.mappingFile");
			trgSchema = props.getProperty("aws.stage.dbconn.schema");
			trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");
			FileAppender myFileAppender;
			DateFormat dateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			Date date = new Date();
			String timestamp = dateTimeFormat.format(date);
			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			String dt = dateFormat.format(date);
			String dataLoadTableFetchError = "";
			String reportsOutput = null;
			// TODO: Need to change this behavior to point to a specific folder for deployment readyness

			reportsOutput = LocalConfUtils.getRootDir() + File.separator + "Logs" + File.separator + dt;

			ConfUtils.setBaseResultsDir(reportsOutput);

			PatternLayout patternLayout = new PatternLayout();
			patternLayout.setConversionPattern("[%p] %d{MM-dd-yyyy HH:mm:ss} - %m%n");

			if ("ALL".equalsIgnoreCase(tableKey)) {
				String TableNamesQuery = "select appl_tbl_nme from TRG_SCHEMA.appl_mstr_tbl_list";
				try {
					tablesToValidate.addAll((List<String>) trgDB.queryForList(TableNamesQuery, String.class));
					System.out.println(tablesToValidate);
				} catch (Exception e) {
					logger.info("FAILURE: ERROR Excuting the Query to Fectch the table names from table 'appl_tbl_nme' " + e.toString(), e);

				}
			}

			logger.info("Table that are being validated in this run: " + tablesToValidate.toString());
			for (String tableName : tablesToValidate) {

				System.out.println(tableName);
				try {
					myFileAppender = new FileAppender(patternLayout, reportsOutput + File.separator + tableName + "_" + timestamp + ".log", false);
					myFileAppender.setThreshold(Level.INFO);
					BasicConfigurator.resetConfiguration();
					BasicConfigurator.configure(myFileAppender);
				} catch (IOException e) {
					e.printStackTrace();
				}
				logger.info("BEGIN: RAZOR DATALOAD AUTOMATION TESTS IN " + razorEnv.toUpperCase() + " FOR " + tableName + " " + new Date().toString());
				logger.info(underBarFiller);
				logger.info("");
				logger.info("Mapping File: " + mappingFileName + "| Config File: " + configFile);
				logger.info(" ");
				if (!dataLoadTableFetchError.isEmpty()) {
					logger.fatal(dataLoadTableFetchError);
				}
				// Query to get the critical, testcasereqflag, RefcheckFlag , parent tablename and testcaseId from  table "appl_tbl_test_case_map"
				String testCaseMapQuery = "SELECT lkup.appl_test_case_id,lkup.appl_test_case_nme,map.appl_test_case_crtl_flag,map.prnt_appl_tbl_nme,map.appl_ref_chk_reqd_ind,map.appl_test_case_reqd_ind"
						+ " FROM " + trgSchema + ".appl_tbl_test_case_map map"
						+ " INNER JOIN "+ trgSchema + ".appl_test_case_lkup lkup"
						+ " ON lkup.appl_test_case_id = map.appl_test_case_id"
						+ " WHERE map.appl_tbl_nme = '" + tableName + "'"; 				Set<String> parentTableSet = new LinkedHashSet<>();
				HashMap<Integer, String> isRefCheckReqMap = new HashMap<Integer, String>();
				HashMap<Integer, String> isTestCheckReqMap = new HashMap<Integer, String>();
				List<Map<String, Object>> testCaseMapQueryResult = null;
				int testCaseId = 0;
				String isRefCheckReq =null;
				String isTestCaseReq =null;
				String parentTable =null;
				String iscritical =null;
				try {
					// parentTableList = (List<String>) trgDB.queryForList(ParentTableNameQuery, String.class);
					testCaseMapQueryResult = trgDB.queryForList(testCaseMapQuery);

				} catch (Exception e) {
					logger.info("FAILURE: ERROR Excuting the Query to Fectch the table names from table  " + tableName + e.toString(), e);

				}
				if (!testCaseMapQueryResult.isEmpty()) {
					for (Map<String, Object> m : testCaseMapQueryResult) {
						Object parentTableObject = m.get("prnt_appl_tbl_nme");
						Object testCaseIdObject = m.get("appl_test_case_id");
						Object refCheckFlagObject = m.get("appl_ref_chk_reqd_ind");
						Object testCaseReqFlagObject = m.get("appl_test_case_reqd_ind");
						Object criticalFlagObject = m.get("appl_test_case_crtl_flag");
						testCaseId = testCaseIdObject == null ? null : ((BigDecimal) testCaseIdObject).intValue();
						isRefCheckReq = refCheckFlagObject == null ? StringUtils.EMPTY : refCheckFlagObject.toString();
						isTestCaseReq = testCaseReqFlagObject == null ? StringUtils.EMPTY : testCaseReqFlagObject.toString();
						parentTable = parentTableObject == null ? StringUtils.EMPTY : parentTableObject.toString();
						iscritical = criticalFlagObject == null ? StringUtils.EMPTY : criticalFlagObject.toString();
						parentTableSet.add(parentTable);
						isRefCheckReqMap.put(testCaseId, isRefCheckReq);
						isTestCheckReqMap.put(testCaseId, isTestCaseReq);
					}
				} else {
					logger.warn("WARNING:  No Test Case mapping found in APPL_TBL_TEST_CASE_MAP for the table " + tableName);
				}

				DatabaseImpl impl = (DatabaseImpl) applicationContext.getBean(DatabaseImpl.class);
				impl.startValidations(tableName);
				// TestCaseId: 1

				impl.validateTargetRecordCountsWithPrevDay(tableName, iscritical, parentTable, isRefCheckReqMap.get(1), isTestCheckReqMap.get(1),1);

				// TestCaseId: 2

				impl.validateTargetNullCounts(tableName, iscritical, parentTable, isRefCheckReqMap.get(2), isTestCheckReqMap.get(2),2);

				// TestCaseId: 3

				if (!parentTableSet.iterator().next().isEmpty()) {
					if (parentTableSet.iterator().next().indexOf(",") != -1) {
						String[] parentTableArray = parentTableSet.iterator().next().split(",");
						for (String parentTableName : parentTableArray) {
							System.out.println("Parent Table Name : " + parentTableName);
							impl.validateBusinessConditions(tableName, parentTableName, iscritical, isRefCheckReqMap.get(3), isTestCheckReqMap.get(3),3);
						}
					} else {
						impl.validateBusinessConditions(tableName, parentTableSet.iterator().next(), iscritical, isRefCheckReqMap.get(3), isTestCheckReqMap.get(3),3);
						System.out.println("Parent Table Name : " + parentTableSet.iterator().next());
					}
				} else {
					logger.info("**************************************************************************************************");
					logger.info("*************BUSINESS VALIDATIONS: VALIDATING REFERENTIAL INTEGRITY FOR TARGET TABLES*************");
					logger.info("**************************************************************************************************");
					logger.info(" ");
					logger.info(" *** INTEGRITY CHECK IS NOT REQUIRED FOR THIS TABLE.  Skipping...");
					logger.info(" ");
				}

				// TestCaseId: 4

				impl.validateDuplicateRecords(tableName, iscritical, parentTable,isRefCheckReqMap.get(4), isTestCheckReqMap.get(4),4);

				// TestCaseId: 5

				impl.validateTypeEnumerations(tableName, iscritical, parentTable, isRefCheckReqMap.get(5), isTestCheckReqMap.get(5),5);

				// TestCaseId: 6

				impl.runAdhocQueries(tableName, iscritical, parentTable, isRefCheckReqMap.get(5), isTestCheckReqMap.get(6),6);

				// TestCaseId: 7

				impl.validateSTColumnData(tableName, parentTable, iscritical, isRefCheckReqMap.get(7) , isTestCheckReqMap.get(7),7);

				// TestCaseId: 8

				impl.validateSTColumnNullCounts(tableName, parentTable, iscritical,isRefCheckReqMap.get(8), isTestCheckReqMap.get(8),8);

				// TestCaseId: 9

				impl.validateSTRecordCounts(tableName, parentTable, iscritical,isRefCheckReqMap.get(9), isTestCheckReqMap.get(9),9);

				logger.info(" ");
				logger.info("END: RAZOR DATALOAD AUTOMATION TESTS FOR " + tableName + " " + new Date().toString());

			}
		}
	}
}