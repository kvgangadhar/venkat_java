/*
 * Copyright (c) 2014 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.razor.automation.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;

import com.fanniemae.razor.automation.common.CommonCache;
import com.fanniemae.razor.automation.common.CommonCacheConstants;
import com.fanniemae.razor.automation.dto.Json2XmlPath;
import com.fanniemae.testeng.automation.common.Constants;
import com.fanniemae.testeng.automation.exceptions.TestingErrorCode;
import com.fanniemae.testeng.automation.exceptions.TestingException;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;
import com.fanniemae.testeng.automation.xml.XmlUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class CommonUtils {

	private static final String PLACE_HOLDER_REGEX = "<[^>]*>";

	private static final String XML_NS_DELIMITER = ":";

	public static final int LINE_LENGTH = 100;

	public static final String RESULT_DATA_DIR = "data";
	
	@Autowired
	private CommonCache commonCache;


	public static Map<String, String> getRegExMetaCharMap() {
		Map<String, String> regExMetaCharMap = new HashMap<String, String>();

		regExMetaCharMap.put("\\|", "\\\\|");
		regExMetaCharMap.put("\\+", "\\\\+");
		regExMetaCharMap.put("\\(", "\\\\(");
		regExMetaCharMap.put("\\)", "\\\\)");

		return regExMetaCharMap;
	}

	public static String getCompareFailMessage(String expected, String actual) {
		String failedMessage = "\nExpected value: \"" + expected
				+ "\" \n not in the actual message list: \"" + actual + "\" \nare not matching.";
		failedMessage = WordUtils.wrap(failedMessage, LINE_LENGTH);

		return failedMessage;
	}

	public static List<String> getPolishedInputMessages(List<String> inputMessageList) {
		List<String> polishedMessages = new ArrayList<String>();

		for (String inputMessage : inputMessageList) {
			String polishedMessage = CommonUtils.polishInput(inputMessage);
			polishedMessages.add(polishedMessage);
		}

		return polishedMessages;
	}

	/**
	 * Given the message with place holders and special characters this method
	 * will creates equivalent regex and returns it.
	 */
	public static String polishInput(String inputLine) {
		String polishedLine = inputLine;

		polishedLine = cleanOutSpaces(inputLine);
		polishedLine = escapeRegExMetaChars(polishedLine);
		polishedLine = polishedLine.replaceAll(PLACE_HOLDER_REGEX,
				Constants.REG_EX_WILD_CARD_CHAR);
		
		polishedLine = Constants.REG_EX_WILD_CARD_CHAR + polishedLine;

		if (!polishedLine.endsWith(Constants.REG_EX_WILD_CARD_CHAR)) {
			polishedLine = polishedLine + Constants.REG_EX_WILD_CARD_CHAR;
		}

		return polishedLine;
	}

	/**
	 * Trim and remove extra spaces
	 *
	 * Author: q2urak
	 * @param inputLine
	 * @return
	 */
	public static String cleanOutSpaces(String inputLine)
	{
		String cleanLine = "";

		if(StringUtils.isNotBlank(inputLine))
		{
			cleanLine = inputLine.trim();
			cleanLine = cleanLine.replaceAll(Constants.REG_EX_EXTRA_SPACE, Constants.WHITE_SPACE);
		}

		return cleanLine;
	}

	private static String escapeRegExMetaChars(String polishedLine) {
		Map<String, String> regExMetaCharMap = getRegExMetaCharMap();

		if (StringUtils.isNotBlank(polishedLine)) {
			for (Entry<String, String> metaCharEntry : regExMetaCharMap
					.entrySet()) {
				polishedLine = polishedLine.replaceAll(metaCharEntry.getKey(),
						metaCharEntry.getValue());
			}

		}
		return polishedLine;
	}

	/**
	 * This method calls {@code CucumberLogUtils#logFail(String)} using the information
	 * available in given {@code testingException}
	 */
	public static void writeFailMessageToReport(
			TestingException testingException) {
		TestingErrorCode errorCode = testingException.getErrorCode();

		String errorString = "";

		if(errorCode != null) {
			errorString = errorCode.getCode() + ":"
					+ errorCode.getDescription() + "\n"
					+ testingException.getMessage();
		} else {
			errorString = testingException.getMessage();
		}

		CucumberLogUtils.logFail(errorString, false);
	}

	/**
	 * Writes the {@code content} to file with given {@code fileName} under the
	 * resultDir
	 *
	 * @throws IOException
	 */
	public static void writeStringToResultdir(String fileName, String content)
			throws IOException {
		File resultFile = new File(ConfUtils.getResultsDataDir(), fileName);
		FileUtils.writeStringToFile(resultFile, content, "UTF-8");
	}

	/**
	 * Copies the file to results directory.
	 * @throws TestingException 
	 */
	public static void writeFileToResultsDir(File sourceFile)
			throws IOException, TestingException {
		String newFilename = com.fanniemae.testeng.automation.filesystem.FileUtils.appendToFileName(sourceFile.getName(), System.currentTimeMillis()+""); 
		com.fanniemae.testeng.automation.filesystem.FileUtils.copyFile(sourceFile.getAbsolutePath(), 
		    ConfUtils.getResultsDataDir(), newFilename);
	}



	/**
	 * Creates a testing exception with given {@code message} and
	 * {@code exception}
	 * 
	 * @param message
	 *            the exception message indicating the reason for the exception
	 *            and context info.
	 * 
	 * @param exception
	 *            the original exception.
	 */
	public static TestingException createTestingException(String message,
			Throwable exception) {
		return new TestingException(message, exception);
	}

	/**
	 * Joins the given map of strings with delimiters.
	 * 
	 * @param elementDelim
	 *            The delimiter that needs to be used to join map entries
	 * 
	 * @param keyValue
	 *            The delimiter to be used between key, value of each entry of
	 *            the map
	 * 
	 * @param mapTobeJoined
	 *            the map to be joined as described above.
	 */
//	public static String joinStringMap(String elementDelim,
//			String keyValueDelim, Map<String, ?> mapTobeJoined) {
//		return Joiner.on(elementDelim)
//				.withKeyValueSeparator(keyValueDelim).join(mapTobeJoined);
//	}

//	/**
//	 * Joines the given collection of strings by using the given
//	 * {@code delimiter}
//	 * 
//	 * @param delimeter
//	 *            The delimiter to be used between entries while joining.
//	 * 
//	 * @return The joined string as described above.
//	 */
//	public static String joinStringCollection(String delimiter,
//			Collection<?> listTobeJoined) {
//
//		return Joiner.on(delimiter).skipNulls().join(listTobeJoined);
//	}
//
//	/**
//	 * Splits the given {@code delimitedString} on the {@code delimiter}
//	 * 
//	 * @param delimiter
//	 *            The separator on which the given string had to be split.
//	 * 
//	 * @param the
//	 *            string that is to be split.
//	 * 
//	 * @param the
//	 *            list of string those are split on delimiter as described
//	 *            above.
//	 */
//	public static List<String> splitDelimitedString(String delimiter,
//			String delimitedString) {
//		List<String> tokens = new ArrayList<String>();
//
//		if (StringUtils.isNotBlank(delimiter)
//				&& StringUtils.isNotBlank(delimitedString)) {
//
//			try {
//				tokens = Splitter.on(delimiter).splitToList(delimitedString);
//				tokens = ArrayListUtils.trimStringList(tokens);
//			} catch (Exception exception) {
//				String message = "Error occured while splitting the string: "
//						+ delimitedString + " with the delimiter: " + delimiter;
//				throw new TestingRuntimeException(message, exception);
//			}
//		}
//
//		return tokens;
//	}

	/**
	 * This method removes all prefixes as specified in by the list
	 * {@code prefixList} and all the namespace declarations in the given
	 * {@code xmlContentWithNs}
	 * 
	 * @param xmlContentWithNs
	 *            the xml content which needs clean up.
	 * 
	 * @param prefixList
	 *            the list of element prefixes to be cleaned up. No need to
	 *            specify the prefix delimiter. Ex: "ns" or "ns1" is enough, no
	 *            need of "ns:" or "ns1:"
	 */
	public static String removeNameSpacesIntheXml(String xmlContentWithNs,
			List<String> prefixList) {

		if (StringUtils.isNotBlank(xmlContentWithNs)) {

			for (String prefix : prefixList) {

				if (!prefix.endsWith(XML_NS_DELIMITER)) {
					prefix = prefix + XML_NS_DELIMITER;
				}

				xmlContentWithNs = xmlContentWithNs.replaceAll(prefix,
						Constants.BLANK);
			}

			xmlContentWithNs = xmlContentWithNs.replaceAll("xmlns.*?>", ">");
		}

		return xmlContentWithNs;
	}

	public static void sleep(long timeinMilliSeconds){
		try {
			Thread.sleep(timeinMilliSeconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	

   /**
    * Compare ActualList from UI grid and expected list from DataTable
    * @param actualList
    * @param expectedList
    * @return
    */
   public static boolean isDataSameInLists(List<Map<String,String>> actualList, List<Map<String,String>> expectedList) {
		boolean status = false;
		
		if(!CollectionUtils.isEmpty(actualList) && !CollectionUtils.isEmpty(expectedList)) {
			int rowCount = expectedList.size();
			if(actualList.size() == rowCount) {
				for(int index=0; index < rowCount; index++) {
					Map<String, String> actualMap = actualList.get(index);
					Map<String, String> expectedMap = expectedList.get(index);
					if(!actualMap.equals(expectedMap)) {
						status = false;
						CucumberLogUtils.logToConsole("-----------------------------------");
						CucumberLogUtils.logToConsole("Actual Values ::: ");
						printToConsole(actualMap);
						CucumberLogUtils.logToConsole("-----------------------------------");
						CucumberLogUtils.logToConsole("Expected Values ::: ");
						printToConsole(expectedMap);
						CucumberLogUtils.logToConsole("-----------------------------------");
						break;
					} else {	
						status = true;
					}
				}
			}
		}
		return status;
	}
   
   public static boolean compareBothList(List<Map<String, Object>> listOfDataFromSource, List<Map<String, Object>> listOfDataFromTarget) {
         boolean isMissing = !checkSize(listOfDataFromSource, listOfDataFromTarget);
         for (Map<String, Object> dataMap : listOfDataFromSource) {
             if (!listOfDataFromTarget.contains(dataMap)) {
                 CucumberLogUtils.logInfo("Additional data present in source: " + dataMap);
                 isMissing = true;
             } else {
                 listOfDataFromTarget.remove(dataMap);
             }
         }
         for (Map<String, Object> dataMap : listOfDataFromTarget) {
             isMissing = true;
             CucumberLogUtils.logInfo("Additional data present in target (missing in source): " + dataMap);
         }

         return !isMissing;
     }
   
   public static boolean checkSize(List<Map<String, Object>> listOfDataFromSource, List<Map<String, Object>> listOfDataFromTarget) {
       if (listOfDataFromSource.size() != listOfDataFromTarget.size()) {
           CucumberLogUtils.logInfo("Number of rows in source and target systems are not matching");
           return false;
       }
       return true;
   }

   private static void printToConsole(Map<String, String> map) {
  		for(String s: map.keySet()){
  			CucumberLogUtils.logToConsole(s + ":");
  			CucumberLogUtils.logToConsole(map.get(s));
		}
  	}

  	/**
  	 * Replaces the tokens in the soruce String with the matching values
  	 * @param soruceString
  	 * @param map
  	 * @return
  	 */
	public static String stringTokenReplacer(String soruceString, Map<String, String> map, boolean isinvalidReqParamPath) {
  		String replacedString = soruceString;
  		if(StringUtils.isNotBlank(soruceString)) {
  			for (Map.Entry<String, String> e : map.entrySet()) {
  				String tokenStr = "<"+ e.getKey() +">";
  				if(isinvalidReqParamPath && e.getKey().equals(CommonCacheConstants.REQUEST_ID)) {
  					if(StringUtils.isBlank(e.getValue())) {
  						replacedString = replacedString.replaceAll(tokenStr, "");
  					} else {
  						replacedString = replacedString.replaceAll(tokenStr, e.getValue()+"_1");
  					}
  				}
  				replacedString = replacedString.replaceAll(tokenStr, e.getValue());
  			}
  		}
  		return replacedString;
  	}

	public static String convertInputStream2String(InputStream input) throws IOException {
		//TODO UTF_8 charset encoding
		try (BufferedReader buffer = new BufferedReader(new InputStreamReader(input))) {
            return buffer.lines().collect(Collectors.joining("\n"));
	    }
	}
	
	public void addMapValuesToCache(Map<String, String> map, String cacheKey) {
		Map<String, String> formValuesMap = commonCache.getFromCache(HashMap.class, cacheKey);
		Set<String> keys = map.keySet();
		for (String key : keys) {
			formValuesMap.put(key, map.get(key));
		}
	}
	
	/**
	 * To append the existing Key
	 * @param key
	 * @param value
	 * @param cacheKey
	 */
	public void updateMapValuesToCache(String key, String value, String cacheKey) {
		Map<String, String> formValuesMap = commonCache.getFromCache(HashMap.class, cacheKey);
		formValuesMap.put(key, value);
	}

	/**
	 * Gets the key.
	 *
	 * @param inputString the input string
	 * @return the key
	 */
	static String getKey(String inputString) {
		String key = null;
		Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(inputString);
		while (m.find()) {
			return m.group(1);
		}
		return key;
	}
	
	/**
	 * To compare values in JSON and XML for specific fields
	 * @param jsonStr
	 * @param xmlContent
	 * @param pathList
	 * @throws JsonProcessingException
	 * @throws IOException
	 */
	public static void compareJsonWithXML(String jsonStr, String xmlContent, List<Json2XmlPath> pathList) throws JsonProcessingException, IOException {
		JsonNode jsonNode = JsonUtils.readJsonStringToNode(jsonStr);
		XmlUtils xmlUtil = new XmlUtils(xmlContent);
		Document doc = xmlUtil.getDoc();
		pathList.forEach(json2XmlPath -> {
			String jsonValue = JsonUtils.getNodeValue(jsonNode, json2XmlPath.getJsonPath());
			String xmlValue = xmlUtil.get_data(incrementArrayNumInXpath(json2XmlPath.getxPath()));
			if(!jsonValue.equals(xmlValue)) {
				String errorMsg = "Json Value- " + jsonValue + " at JSON Path " +  json2XmlPath.getJsonPath() 
									+ " does not matchg with XML value- " + xmlValue + " at XPath " +  json2XmlPath.getxPath();
				CucumberLogUtils.logError("JSON and XML Values are not matching. " + errorMsg );
				CucumberLogUtils.logFail(errorMsg, false);
			}
		});
		//Control reaches here in case of comparision is success
		CucumberLogUtils.logPass("JSON and SOAP XML comparision succeess", false);
	}
	
	/**
	 * Xpath is currently based on a beginning index-1. 
	 * This method can be used inorder to sync with JsonPath which is based on beginning index-0
	 * @param inputString
	 * @return
	 */
	private static String incrementArrayNumInXpath(String inputString) {
		//Fetch the Matching Strings with arrayNum from the xpath 	
	 	Matcher m = Pattern.compile("\\w+(\\[([^)]?)\\])").matcher(inputString);
		String incrementedString = null ;
		while (m.find()) {
			String word = m.group(0);
			//Fetch the matching string with []
			Matcher m1 = Pattern.compile("\\[([^)]?)\\]").matcher(word);
			while (m1.find()) {
				int i = (Integer.parseInt(m1.group(1))+1);
				incrementedString =  word.replaceAll("\\[([^)]?)\\]" , "[" + String.valueOf(i) + "]");
			}
			inputString = inputString.replace(word, incrementedString);
		}
		return inputString;
	 }
	
}
