package com.fanniemae.razor.aws.utils;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.fanniemae.razor.automation.utils.EnvUtils;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;

@Component
public class AWSSqsUtils {
	@Autowired	
	private EnvUtils envUtils;
	
	private AmazonSQS sqs = null;
	private AmazonSQS getSqsClient(String username, String password, String awsRole) {
		ClientConfiguration clientConf = AWSCommonUtils.getAWSClientConfig(Protocol.HTTP);
		try {
			CucumberLogUtils.logInfo("Fetching SQS client for UserID - " + username + " and Role - " + awsRole);
			BasicSessionCredentials basicSessionCredentials = AWSCommonUtils
					.getBasicSessionCredentials(username, password, awsRole);
			
			sqs = AmazonSQSClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(basicSessionCredentials))
					.withClientConfiguration(clientConf).withRegion(Regions.US_EAST_1).build();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqs;
	}
	
	/**
     * gets messages from your queue
     * @param queueUrl
     * @return
     */
	public List<Message> getMessagesFromQueue( String userName,
			String userPassword, String awsRole){
       sqs = getSqsClient(userName, userPassword, awsRole);
       List<Message> messages = sqs.receiveMessage(envUtils.getBulkResponseQueueURL()).getMessages();
       return messages;
    }
 
    /**
     * deletes a single message from your queue.
     * @param queueUrl
     * @param message
     */
    public void deleteMessageFromQueue(Message message){
        String messageRecieptHandle = message.getReceiptHandle();
        System.out.println("message deleted : " + message.getBody() + "." + message.getReceiptHandle());
        sqs.deleteMessage(new DeleteMessageRequest(envUtils.getBulkResponseQueueURL(), messageRecieptHandle));
    }
    
    public void sendMessagetoQueue(String userName, String password, String awsRole, String qUrl, String message){
    	 System.out.println("---   START AWSHandler::sendMessageToQueue() Sending message to SQS Queue: " + qUrl + "   ---");
    	 sqs = getSqsClient(userName, password, awsRole);
    	 sqs.sendMessage(new SendMessageRequest(qUrl, message));
        System.out.println("---   END AWSHandler::sendMessageToQueue() Message successfully sent to SQS!   ---");
    }

}
