package com.fanniemae.razor.automation.utils;

import static com.fanniemae.razor.automation.common.CommonConstants.USE_THE_DATE_INPUT_MATCHING;
import static com.fanniemae.razor.automation.common.CommonConstants.USE_THE_INPUT_MATCHING;
import static com.jayway.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazonaws.HttpMethod;
import com.fanniemae.razor.automation.common.CommonCacheConstants;
import com.fanniemae.razor.automation.common.CommonConstants;
import com.fanniemae.razor.automation.common.ServiceEndPointMappingsEnum;
import com.fanniemae.razor.request.ClaimDecisionRequest;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;


/**
 * Utility to handle REST Service calls
 * @author q2uscv
 *
 */
@Component
public class RestEndPointUtils {
	
	@Autowired
	private EnvUtils envUtils;
	
	@Autowired CommonUtils commonUtils;
	
	private Map<String, String> generatedMap;
	
	public String fetchResultStringUsingGet(String RestEndPointRelativeURL, String input) {
		RestAssured.baseURI = envUtils.getRazorRestServiceBaseURL();
		String result = null;
		
		Response res = given().expect().statusCode(200).then().get(RestEndPointRelativeURL);
		result = res.getBody().asString();
		System.out.println("After calling REST");
		return result;
	}
	
	/**
	 * Fetch API response based on the ServiceName configured in ServiceEndPointMappings Enum and uses the parthMap for pathVariables
	 * @param serviceName
	 * @param requestPathMap
	 * @return
	 */
	public Response fetchAPIResponse(String serviceName, Map<String, String> requestPathMap) {
		RestAssured.baseURI = envUtils.getRazorRestServiceBaseURL();
		ServiceEndPointMappingsEnum serviceEndPoint = getServiceEndpointMappints(serviceName);
		String restEndPointRelativeURL = serviceEndPoint.getUrl();
		String requestMethod = serviceEndPoint.getRequestMethod();
		CucumberLogUtils.logInfo("About to call REST service " + restEndPointRelativeURL);
		Response res = null;
		
		//To be used in the validation steps
		generatedMap = requestPathMap;
		if (HttpMethod.GET.name().equalsIgnoreCase(requestMethod)) {
			if(requestPathMap != null) {
				restEndPointRelativeURL = CommonUtils.stringTokenReplacer(restEndPointRelativeURL, requestPathMap, false);
			}
			res = given().expect().statusCode(200).when().get(restEndPointRelativeURL);
		}
		CucumberLogUtils.logDebug("REST call completed succesfully");
		return res;
	}
	
	
	/**
	 * Fetch API response based on the ServiceName configured in ServiceEndPointMappings Enum and uses the parthMap for pathVariables
	 * @param serviceName
	 * @param requestPathMap
	 * @return
	 */
	public Response fetchAPIwithParamMap(String serviceName, Map<String, String> requestPathMap) {
		RestAssured.baseURI = envUtils.getRazorRestServiceBaseURL();
		
		ServiceEndPointMappingsEnum serviceEndPoint = getServiceEndpointMappints(serviceName);
		String restEndPointRelativeURL = serviceEndPoint.getUrl();
		ContentType contentType = serviceEndPoint.getRequestContentType();
		String requestMethod = serviceEndPoint.getRequestMethod();
		CucumberLogUtils.logInfo("About to call REST service " + restEndPointRelativeURL);
		Response res = null;
		if (HttpMethod.GET.name().equalsIgnoreCase(requestMethod)) {
			res = given().contentType(contentType).parameters(requestPathMap).expect().statusCode(200).when().get(restEndPointRelativeURL);
		} else if (HttpMethod.POST.name().equalsIgnoreCase(requestMethod)) {
			res = given().contentType(contentType).parameters(requestPathMap).expect().statusCode(200).when().post(restEndPointRelativeURL);
		}
		CucumberLogUtils.logDebug("REST call completed succesfully");
		return res;
	}
	
	/**
	 * Fetch API response based on the ServiceName configured in ServiceEndPointMappings Enum and uses the parthMap for pathVariables
	 * @param serviceName
	 * @param requestPathMap
	 * @return
	 */
	public Response fetchAPIwithJsonInputParam(String serviceName, Object jsonObj) {
		RestAssured.baseURI = envUtils.getRazorRestServiceBaseURL();
		ServiceEndPointMappingsEnum serviceEndPoint = getServiceEndpointMappints(serviceName);
		String restEndPointRelativeURL = serviceEndPoint.getUrl();
		ContentType contentType = serviceEndPoint.getRequestContentType();
		String requestMethod = serviceEndPoint.getRequestMethod();
		CucumberLogUtils.logInfo("About to call REST POST service " + restEndPointRelativeURL);
		
		Response res = null;
		if (HttpMethod.POST.name().equalsIgnoreCase(requestMethod)) {
			ClaimDecisionRequest req = (ClaimDecisionRequest) jsonObj;
			
			CucumberLogUtils.logInfo("With JSON payload - " + req.toString());
			
			res = given().contentType(contentType).body(req).expect().statusCode(200).when().post(restEndPointRelativeURL);
//			res = given().contentType(contentType).contentType("application/json; charset=UTF-8").
//				       body(address).expect().statusCode(200).when().post("/mockApp/address/");
		}
		CucumberLogUtils.logInfo("REST call completed succesfully");
		return res;
	}
	
	public Response fetchAPIwithJsonInputParam(String serviceName, JsonNode jsonObj, Map<String, String> requestPathMap,
			int stautsCode, boolean isinvalidReqParamPath, String payLoadType) {
		RestAssured.baseURI = envUtils.getRazorRestServiceBaseURL();
		ServiceEndPointMappingsEnum serviceEndPoint = getServiceEndpointMappints(serviceName);
		String restEndPointRelativeURL = serviceEndPoint.getUrl();
		ContentType contentType = serviceEndPoint.getRequestContentType();
		String requestMethod = serviceEndPoint.getRequestMethod();
		CucumberLogUtils.logInfo("About to call REST POST service " + restEndPointRelativeURL);
		
		//Generate Unique values if required
		Map<String, String> tempMap = RazorUtils.generateUniqueParam(requestPathMap);
		generatedMap = new HashMap<>();
		//Use already generated unique values
		//TODO Check if this 2nd loop can be avoided
		tempMap.forEach((String key, String value) -> {
			String inputData = this.convertColumnValue(value);
			generatedMap.put(key, inputData);
			//Fix for RequestID to replace with the generated value in ResponseHandler payload
			if((null != payLoadType) && payLoadType.equalsIgnoreCase("RES") 
					&& key.equalsIgnoreCase(CommonCacheConstants.REQUEST_ID)) {
				generatedMap.put(CommonCacheConstants.REQUEST_ID_RESP_PATH, inputData);
			}
		});
		
		tempMap = null;
		Response res = null;
		if(requestPathMap != null) {
				restEndPointRelativeURL = CommonUtils.stringTokenReplacer(restEndPointRelativeURL, generatedMap, isinvalidReqParamPath);
		}
		CucumberLogUtils.logInfo("Rest Endpoint relatiive URL - " + restEndPointRelativeURL);
		if (HttpMethod.POST.name().equalsIgnoreCase(requestMethod)) {
			if((null == payLoadType) || payLoadType.equalsIgnoreCase("REQ")) {
				String requestId = generatedMap.get(CommonCacheConstants.REQUEST_ID);
				if(null != jsonObj.get(CommonCacheConstants.REQUEST_ID)) {
					JsonUtils.replaceNodeWithNewValue(jsonObj, CommonCacheConstants.REQUEST_ID, requestId, "String");
				}
				String claimTransId = generatedMap.get(CommonCacheConstants.CLAIM_TRANS_ID);
				if((null !=  JsonUtils.getNodeValue(jsonObj, CommonCacheConstants.CLAIM_TRANS_ID_REQ_PATH) && (claimTransId != null))) {
					JsonUtils.replaceNodeWithNewValue(jsonObj, CommonCacheConstants.CLAIM_TRANS_ID_REQ_PATH, claimTransId, "String");
					//Generating unique ClaimHeader Info ID for each request
					JsonUtils.replaceNodeWithNewValue(jsonObj, CommonCacheConstants.CLAIM_HEADER_INFO_ID_REQ_PATH, claimTransId.substring(3), "Number");
				}
			} else {
				String requestIdResp = generatedMap.get(CommonCacheConstants.REQUEST_ID);
				String requestIDOriginal = JsonUtils.getNodeValue(jsonObj,CommonCacheConstants.REQUEST_ID_RESP_PATH);
				if(StringUtils.isNotBlank(requestIDOriginal)) {
					JsonUtils.replaceNodeWithNewValue(jsonObj, CommonCacheConstants.REQUEST_ID_RESP_PATH, requestIdResp, "String");
				}
				String claimTransIdResp = generatedMap.get(CommonCacheConstants.CLAIM_TRANS_ID);
				String claimTransIdOriginal = JsonUtils.getNodeValue(jsonObj, CommonCacheConstants.CLAIM_TRANS_ID_RESP_PATH);
				if(StringUtils.isNotBlank(claimTransIdOriginal) && (claimTransIdResp != null)) {
					JsonUtils.replaceNodeWithNewValue(jsonObj, CommonCacheConstants.CLAIM_TRANS_ID_RESP_PATH, claimTransIdResp, "String");
					//Generating unique ClaimHeader Info ID for each request
					JsonUtils.replaceNodeWithNewValue(jsonObj, CommonCacheConstants.CLAIM_HEADER_INFO_ID_RESP_PATH, claimTransIdResp.substring(3), "Number");
				}
			}
			
			String payload = JsonUtils.write2String(jsonObj);
			CucumberLogUtils.logInfo("With JSON payload - " + payload);
			if(stautsCode == 0) {
				stautsCode = 200;
			}
			res = given().relaxedHTTPSValidation().contentType(contentType).body(payload).expect().statusCode(stautsCode).when().post(restEndPointRelativeURL);
		}
		CucumberLogUtils.logInfo("REST call completed succesfully. Response - " + res.asString());
		return res;
	}

	/**
	 * Call the Service with same JSON Payload
	 * @param serviceName
	 * @param jsonObj
	 * @param requestPathMap
	 * @return
	 */
	public Response fetchAPIwithSameJsonInputParam(String serviceName, Object jsonObj, Map<String, String> requestPathMap, int responseCode) {
		RestAssured.baseURI = envUtils.getRazorRestServiceBaseURL();
		ServiceEndPointMappingsEnum serviceEndPoint = getServiceEndpointMappints(serviceName);
		String restEndPointRelativeURL = serviceEndPoint.getUrl();
		ContentType contentType = serviceEndPoint.getRequestContentType();
		String requestMethod = serviceEndPoint.getRequestMethod();
		CucumberLogUtils.logInfo("About to call REST POST service " + restEndPointRelativeURL);
		
		Response res = null;
		if(requestPathMap != null) {
			restEndPointRelativeURL = CommonUtils.stringTokenReplacer(restEndPointRelativeURL, generatedMap, false);
		}
		if (HttpMethod.POST.name().equalsIgnoreCase(requestMethod)) {
			ClaimDecisionRequest req = (ClaimDecisionRequest) jsonObj;
			req.setRequestId(generatedMap.get(CommonCacheConstants.REQUEST_ID));
			String payload = JsonUtils.convertJSON2String(req);
			CucumberLogUtils.logInfo("With JSON payload - " + payload);
			
			res = given().relaxedHTTPSValidation().contentType(contentType).body(payload).expect().statusCode(responseCode).when().post(restEndPointRelativeURL);
		}
		CucumberLogUtils.logInfo("RESPONSE : " + res.asString());
		CucumberLogUtils.logInfo("REST call completed succesfully");
		return res;
	}
	
	/**
	 * Fetch Service deails based on the ServiceName
	 * @param serviceName
	 * @return
	 */
	private ServiceEndPointMappingsEnum getServiceEndpointMappints(String serviceName) {
		serviceName = StringUtils.replace(serviceName.toUpperCase(),
				CommonConstants.ONE_SPACE, CommonConstants.UNDERSCORE);
		ServiceEndPointMappingsEnum serviceEndPoint = ServiceEndPointMappingsEnum
				.valueOf(serviceName);
		return serviceEndPoint;
	}
	
	public void putRequestPayloadDetailsInCache(String requestID, String claimTransactionID, String jsonPaylod, String requestType ) {
		Map<String, String> valuesMap = new HashMap<>();
		valuesMap.put(CommonCacheConstants.REQUEST_ID, requestID);
		valuesMap.put(CommonCacheConstants.REQUEST_PAYLOAD, jsonPaylod);
		valuesMap.put(CommonCacheConstants.CLAIM_TYPE, requestType);
		/*if(requestType.equalsIgnoreCase("batch")){
			valuesMap.put(CommonCacheConstants.S3_BATCH_FILE_PATH, this.fetchS3BatchRequestPayloadPath(requestID));
		}*/
		valuesMap.put(CommonCacheConstants.S3_FILE_PATH, this.fetchS3RequestPayloadPath(requestID, claimTransactionID, false));
		commonUtils.addMapValuesToCache(valuesMap, CommonCacheConstants.REQUEST_PAYLOAD);
	}
	
	public void putRespPayloadDetailsInCache(String requestID, String claimTransactionID, String jsonPaylod, String requestType ) {
		Map<String, String> valuesMap = new HashMap<>();
		valuesMap.put(CommonCacheConstants.REQUEST_ID, requestID);
		valuesMap.put(CommonCacheConstants.REQUEST_PAYLOAD, jsonPaylod);
		valuesMap.put(CommonCacheConstants.CLAIM_TYPE, requestType);
		//TODO - move to response Payload
		commonUtils.addMapValuesToCache(valuesMap, CommonCacheConstants.REQUEST_PAYLOAD);
	}
	
	public void updateRequestPayloadCache(String key, String value) {
		commonUtils.updateMapValuesToCache(key, value, CommonCacheConstants.REQUEST_PAYLOAD);
	}
	
	/**
	 * Convert column value with the autogenerated fields
	 *
	 * @param columnName the column name
	 * @param inputValue the column value
	 * @param existingFormValues the existing form values
	 * @return the string
	 */
	public String convertColumnValue(String inputValue) {
		if (inputValue.contains(USE_THE_INPUT_MATCHING)) {
			return generatedMap
					.get(CommonUtils.getKey(inputValue));
		} else if (inputValue.contains(USE_THE_DATE_INPUT_MATCHING)) {
			return generatedMap
					.get(CommonUtils.getKey(inputValue));
		} else {
			return inputValue;
		}
	}
	
	private String fetchS3RequestPayloadPath(String requestID, String claimTransactionID, boolean isBatch) {
		String date = LocalDateUtils.getLocalDateTimebyFormat(CommonConstants.DATE_FORMAT);
		String s3FilePath = null;
		if(isBatch){
			s3FilePath = date.concat("/").concat(requestID).concat(".json"); 
		}else{
			s3FilePath = date.concat("/").concat(requestID).concat("/").concat(claimTransactionID).concat(".json"); 
		}
		return s3FilePath;
	}
	
	private String fetchS3BatchRequestPayloadPath(String requestID) {
		String s3FilePath = null;
		if(requestID != null){
			String date = LocalDateUtils.getLocalDateTimebyFormat(CommonConstants.DATE_FORMAT);
			s3FilePath = date.concat("/").concat(requestID).concat("/");
		}
		return s3FilePath;
	}
	
	/**
	 * Fetch S3 SOAP XML file location 
	 * @param responseID
	 * @param claimTransactionID
	 * @param isBatch
	 * @return
	 */
	public String fetchS3BKFSResponseXMLPath(String responseID, String claimTransactionID, boolean isBatch) {
		String xmlS3FileDir = "responseToExternalClient";
		String date = LocalDateUtils.getLocalDateTimebyFormat(CommonConstants.DATE_FORMAT);
		String s3XMLFilePath = null;
		//Convert 32 bit Integer to normal Integer to get the correct folder name
		Integer responseIdInt = Integer.parseInt(responseID);
		if(isBatch){
			s3XMLFilePath = date.concat("/").concat(responseIdInt.toString()).concat(".xml"); 
		}else{
			s3XMLFilePath = xmlS3FileDir.concat("/").concat(responseIdInt.toString()).concat("/").concat(claimTransactionID).concat(".xml"); 
		}
		return s3XMLFilePath;
	}
	

	public Map<String, String> getGeneratedMap() {
		return generatedMap;
	}

}
