package com.fanniemae.razor.automation.utils;

public enum LookupCodeTypes {
	CLAIM_TYPE ("Claim Type"),
	MEASUREMENT_TYPE("Measurement Type"),
	FLOOD_ZONE_CD ("Flood Zone Cd"),
	INVESTOR_BUCKET_CD ("Investor  Bucket Cd"),
	CLAIM_SOURCE_ID("Claim Source ID"),
	CURTAILMENT_REASON("Curtailment Reason"),
	CLAIM_STATUS ("Claim Status"),
	BANKRUPTCY_CHATPER_CD ("Bankruptcy Chapter Cd");
	
	private String lookupCodeType;
	
	LookupCodeTypes(String error) {
		lookupCodeType = error;
	}
	
	public String getLookupCodeType(){
		return lookupCodeType;
	}
	
}
