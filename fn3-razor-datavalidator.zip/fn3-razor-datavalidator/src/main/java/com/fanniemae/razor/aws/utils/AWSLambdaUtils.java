package com.fanniemae.razor.aws.utils;

import org.springframework.stereotype.Component;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;

/**
 * Utility AWS Lambda Java client 
 * @author q2uscv
 *
 */
@Component
public class AWSLambdaUtils {

	//@Autowired
	//private AWSCommonUtils awsCommonUtils;

	public InvokeResult invokeLambdaUsingInvokeRequest(String lambdaName, String reqObj, String username, String password) {
		AWSLambda lambdaClient = getAWSLamdbaClient(username, password);
		InvokeRequest invokeRequest = new InvokeRequest();
        invokeRequest.setFunctionName(lambdaName);
        invokeRequest.setInvocationType("RequestResponse"); // ENUM RequestResponse or Event
        
        //TODO - THis is currently working with String. Need to change to Object
        invokeRequest.withFunctionName(lambdaName).withPayload(reqObj);
        
        InvokeResult invokeRes = lambdaClient.invoke(invokeRequest);
        return invokeRes;
 	}
	
//	public static void invokeLambdaUsingInvokerFactory(String username, String password) {
//		
//		AWSLambda lambdaClient = getAWSLamdbaClient(username, password);
//		final LambdaService lambdaService = LambdaInvokerFactory.builder()
//				 .lambdaClient(lambdaClient)
//				 .build(LambdaService.class);
//		Address addr = new Address();
//		addr.setState("Virginia");
//		addr.setCountry("USA");
//		String responseStr = lambdaService.fetchAddress(addr);
//		System.out.println("RespnoseStr - " + responseStr);
//	}
	
	public  AWSLambda  getAWSLamdbaClient(String username, String password) {
		ClientConfiguration clientConf = AWSCommonUtils.getAWSClientConfig(Protocol.HTTPS);
		AWSLambda lambdaClient= null;
		try {
			BasicSessionCredentials basicSessionCredentials = (BasicSessionCredentials) AWSCommonUtils
					.getBasicSessionCredentials(username, password, "DEVL-RAZOR01-DEVELOPER");
			lambdaClient = AWSLambdaClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(basicSessionCredentials))
					.withClientConfiguration(clientConf).withRegion(Regions.US_EAST_1).build();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lambdaClient;
	}

}
