/*
 * Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.razor.automation.utils;


import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fanniemae.razor.aws.utils.AWSS3Utils;
import com.fanniemae.sharedservices.evas.VaultFactory;
import com.fanniemae.sharedservices.evas.vault.Vault;
import com.fanniemae.sharedservices.evas.vault.object.PasswordObject;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;
import com.fanniemae.testeng.automation.utils.EncryptionUtils;

/**
 * Utility class to fetch PAM/EPV passwords
 * @author q2uscv
 *
 */

public class EnterprisePwdVaultUtils {
	private String envCode;
	private String appCode;
	
	@Autowired
	private EnvUtils envUtils;
	
	/*public EnterprisePwdVaultUtils(String envCode,String appCode) {
		this.envCode = envCode;
		this.appCode = appCode;
	}*/
	
	public final PasswordObject getPAMCredentialsUsingEPV(String objID) {
		Vault vault = VaultFactory.getVault(appCode, envCode);
		PasswordObject	passwordObj  = (PasswordObject)vault.getVaultObject(objID);
		final String userId = passwordObj.getAccountID();
		System.out.println("PAM Account ID - " + userId);
		return passwordObj;
	}
	
	/*public PasswordObject getPAMCredentialsUsingKeys(String objIDName, String awsAccessKeyId, String awsSecretAccessKey) {
		String bucketName = this.buildS3PamBktName();
		System.out.println("Bkt Name - " + bucketName);
		String objId = appCode+"_"+ objIDName;
		System.out.println("Obj ID - " + objId);
		InputStream is =  new AWSS3Utils().getS3ObjectContentWithAccessKey(bucketName, objId, awsAccessKeyId, awsSecretAccessKey);
		return this.convertInStream2PasswordObj(is);
	}
	
	public PasswordObject getPAMCredentialsUsingSTS(String objIDName) {
		String ldapUserId = envUtils.getLdapUserId();
		String ldapPassword = EncryptionUtils.decrypt(envUtils.getLdapPassword());
		String awsRole = envUtils.getAwsRole();
		String bucketName = this.buildS3PamBktName();
		System.out.println("Bkt Name - " + bucketName);
		String objId = appCode+"_"+ objIDName;
		System.out.println("Obj ID - " + objId);
		InputStream is =  new AWSS3Utils().getS3ObjectContent(bucketName, objId, ldapUserId, ldapPassword, awsRole);
		return this.convertInStream2PasswordObj(is);
	}*/
	
	/*public String buildS3PamBktName() {
		String awsVaultRef = System.getProperty("AWS_VREF");
		return "fnma-"+awsVaultRef+"-app-"+appCode.toLowerCase()+"-"+envCode.toLowerCase();
	}*/
	
	private PasswordObject convertInStream2PasswordObj(InputStream is) {
		PasswordObject passObj = null;
		try {
			Properties prop = new Properties();
			prop.load(is);
			
			final String userId = prop.getProperty("Account");
			final String pwd = prop.getProperty("Password");
			final String address = prop.getProperty("ddress");
			passObj = new PasswordObject(userId, pwd, address, null);
			System.out.println("*** PAM pass Account ID - " + passObj.getAccountID());
			is.close();
		} catch (IOException e) {
			CucumberLogUtils.logFail("Failed to read PAM credentials from S3 ", false);
		}
		return passObj;
	}
	
	//TODO remove code
	public void getPAMCredentialsFromS3Test(String bucketName, String objId) {
		System.out.println("Bkt Name - " + bucketName);
		System.out.println("Obj ID - " + objId);
		AWSS3Utils s3Utils = new AWSS3Utils();
		InputStream is = s3Utils.getS3ObjectContentWithAccessKey(bucketName, objId, 
				System.getProperty("AWS_ACCESS_KEY_ID"), System.getProperty("AWS_SECRET_ACCESS_KEY"));
			String value;
			try {
				value = CommonUtils.convertInputStream2String(is);
				is.close();
				System.out.println("*** Output from S3 file -- " + value);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
	
	/*public static void main(String[] args) throws IOException {
		//-DAPP_CD=<YourAppCode> and -DENV_CD=<AppVaultEnvCode: 
		System.out.println("Started");
		EnterprisePwdVaultUtils vault = new EnterprisePwdVaultUtils("D", "FN3");
//		vault.getPAMCredentialsUsingEPV("POSTGRESQL_ACCT");
	}*/
}
