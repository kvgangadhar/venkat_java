package com.fanniemae.razor.automation.common;

/**
 * This class will have all the constants values of all the possible key's which will be used 
 * to store object instances in CommonCache.
 */
public interface CommonCacheConstants {
	
	 String DB_VALIDATION_FORM_VALUES = "dbValidationformValues";
	 String USER_ROLE = "userRole";
	 String USER_LOGIN= "userLogin";
	 String REQUEST_PAYLOAD = "requestPayLoad";
	 String REQUEST_ID = "requestId";
	 String CLAIM_TRANS_ID = "claimTransactionId";
	 String CLAIM_TRANS_ID_REQ_PATH = "validateClaim[0]/claimTransactionId";
	 String CLAIM_HEADER_INFO_ID_REQ_PATH = "validateClaim[0]/claimHeaderInfoId";
	 String CLAIM_TYPE = "claimType";
	 String S3_FILE_PATH = "s3FilePath";
	 String S3_BATCH_FILE_PATH = "s3BatchFilePath";
	 String MAPPING_FILE = "MappingFile";
	 String MAPPING_SOURCE = "MappingSource";
	 String DATA_SOURCE = "DataSource";
	 String STAGING_TABLE = "StagingTable";
	 String SOURCE_SCHEMA_PREFIX = "SrcSchemaPrefix";
	 String SOURCE_TYPE = "SourceType";
	 String RESPONSE_PAYLOAD = "responsePayLoad";
	 String RESPONSE_ID = "responseId";
	 String REQUEST_ID_RESP_PATH = "validateClaimResponse[0]/requestId";
	 String CLAIM_TRANS_ID_RESP_PATH = "validateClaimResponse[0]/claimTransactionId";
	 String CLAIM_HEADER_INFO_ID_RESP_PATH = "validateClaimResponse[0]/claimHeaderInfoId";
	 String STAGING_CHILD_TABLE = "stgChildTable";
	 String LOOKUP_CODE_CACHE = "lookupCodes";
	 String VALIDATION_TYPE = "ValidationType";
	 
}
