package com.fanniemae.razor.automation.utils;


import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.stereotype.Component;

import com.fanniemae.razor.automation.dto.JSONReplacerElement;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.joda.JodaModule;

/**
 * JSON Utility classes for JSON validation or traversal 
 * @author q2uscv
 *
 */
@Component
public class JsonUtils {


	/**
	 * Method used to see if any node has a matching value with input
	 * @param jsonString
	 * @param value
	 * @throws Throwable
	 */
	public static void checkForNodeWithMatchingValue(String jsonString, String value) throws Throwable{
		ObjectMapper mapper = new ObjectMapper();
		// Get the beginning node of the json
		JsonNode root  = mapper.readValue(jsonString.getBytes(), JsonNode.class);
		int count = getNumberOfOccurencesRecursively(root, value);
		if(count >0){
			CucumberLogUtils.logPass("   " + count + " nodes found with matching value. ", false);
		}else{
			CucumberLogUtils.logFail(" No node found with matching value - " + value, false);
		}
	}


	/**
	 * Recursive method used to count all occurrences
	 * @param node
	 * @param searchString
	 * @return
	 */
	public static int getNumberOfOccurencesRecursively(JsonNode node, String searchString) {
		int count = 0;
		// If size > 0 then node has children.
		if(node.size() > 0) {
			// Used to iterate through the children ***** DO NOT USE ITERATOR HERE***** 
			for(JsonNode childNode : node){
				// Pass in child node will add count to current iterations count and return
				count += getNumberOfOccurencesRecursively(childNode, searchString);
			}

		} else {
			// If no children then check the value to see if it contains the value string;
			CucumberLogUtils.logDebug("Node text = " + node.asText());
			if(node.asText().contains(searchString)){
				count++;
			}
		}

		return count;
	}
	
//	public static byte[] readJSONFile( String fileName) throws IOException {
//		byte[] jsonData = Files.readAllBytes(Paths.get(fileName));
//		return jsonData;
//	}
	
	public static byte[] readJSONFile(String fileName) throws IOException {
		System.out.println("Reading file - " + fileName);
		InputStream is =JsonUtils.class.getClassLoader().getResourceAsStream(fileName);
		byte[] jsonData = IOUtils.toByteArray(is);
		System.out.println(fileName + " loaded succesfully");
		return jsonData;
	}
	
	/**
	 * Deserialize data from JSON String
	 * @param jsonString
	 * @param valueType
	 * @return
	 */
	public static <T> T convertJSONString2JSON(String jsonString, Class<T> valueType)  {
		T jsonObject = null;
		try {
			jsonObject = convertByteArray2JSON(jsonString.getBytes(), valueType);
			CucumberLogUtils.logDebug(jsonObject.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	public static <T> T convertByteArray2JSON(byte[] jsonData, Class<T> valueType) throws IOException {
		ObjectMapper objectMapper = initializeMapper();
		
		//convert json string to object
		T jsonObject = null;
		try {
			jsonObject = objectMapper.readValue(jsonData, valueType);
		} catch (JsonParseException e) {
			CucumberLogUtils.logError("Exception occured while Parsing JSON ");
			throw new IOException(e);
		} catch (JsonMappingException e) {
			CucumberLogUtils.logError("JSON mapping exception occured ");
			throw new IOException(e);
		} 
		return jsonObject;
	}
	
	/**
	 * Serialize/Convert JSON Object to String
	 * @param jsonObj
	 * @return
	 */
	public static String convertJSON2String(Object jsonObj) {
		String jsonString = null;
		try {
			ObjectMapper objectMapper = initializeMapper();
			jsonString = objectMapper.writeValueAsString(jsonObj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return jsonString;
	}
	
	private static ObjectMapper initializeMapper() throws IOException {
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		//Register Java Time module for serialization
		//objectMapper.registerModule(new JavaTimeModule());

		//Register Joda Time module for serialization
		objectMapper.registerModule(new JodaModule());
		
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
//		objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper;
	}
	
	/**
	 * Deserialize data from JSON File
	 * @param fileName
	 * @param valueType
	 * @return
	 * @throws IOException
	 */
	public static <T> T readJsonFile2Json(String fileName, Class<T> valueType)  {
		T jsonObject = null;
		try {
			byte[] jsonData = readJSONFile(fileName);
			jsonObject = convertByteArray2JSON(jsonData, valueType);
			CucumberLogUtils.logDebug(jsonObject.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	public static void writeJsonString2File(String jsonStr, String filePath) {
		try {
			Files.write(Paths.get(filePath), jsonStr.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void compareJsons(String expectedJsonStr, String actualJsonStr) {
		CucumberLogUtils.logDebug("About to compare 2 JSONs");
		System.out.println("Expected JSON - " + expectedJsonStr);
		System.out.println("Actual JSON - " + actualJsonStr);
		try {
			JSONAssert.assertEquals(expectedJsonStr, actualJsonStr, JSONCompareMode.STRICT);
			CucumberLogUtils.logPass("ActualJSON and expectedJSON are equal", false);
		} catch (JSONException e) {
			CucumberLogUtils.logError(e.getMessage());
			CucumberLogUtils.logFail("ActualJSON is not matching with expectedJSON", false);
		}
		
	}
	
	public static JsonNode readJsonFileToNode(String jsonPath) throws JsonProcessingException, IOException {
		ObjectMapper mapper = JsonUtils.initializeMapper();
//		JsonNode root = mapper.readTree(new File(jsonPath));
		InputStream is =JsonUtils.class.getClassLoader().getResourceAsStream(jsonPath);
		JsonNode root = mapper.readTree(is);
		return root;
	}
	
	public static JsonNode readJsonStringToNode(String jsonStr) throws JsonProcessingException, IOException {
		ObjectMapper mapper = JsonUtils.initializeMapper();
		JsonNode root = mapper.readTree(jsonStr);
		return root;
	}
	
	public static void removeNodesWithJsonPathList(List<String> jsonPaths, JsonNode root) {
		jsonPaths.forEach(jsonPath -> {
			removeNodeWithJsonPath(root, jsonPath);
		});
		
		
	}
	
	public static String write2String(JsonNode rootNode) {
		String resultUpdate = null;
		try {
			ObjectMapper mapper = JsonUtils.initializeMapper();
			resultUpdate = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rootNode);
		} catch (IOException e) {
			CucumberLogUtils.logError("Exception occured while writing JsonNode to String");
			CucumberLogUtils.logFail(e.getMessage(), false);
		}
		return resultUpdate;
	}
	

	public static void removeNodeWithJsonPath(JsonNode root, String jsonPath) {

		//String beginningPath;
		String[] array = jsonPath.split("/");
		
		//make beginningNode and root same at the beginning
		JsonNode beginningNode = root;
		if(array.length == 0 ) {
			//if at root path, remove the node directly
			((ObjectNode) beginningNode).remove(jsonPath);
		} else {
			//If more than one level, then traverse through the tree and then remove
			for(int i=0; i<array.length; i++) {
				String currPath = array[i];
				if(array[i].contains("[")){
					String indexStr = jsonPath.substring(jsonPath.indexOf("[")+1,jsonPath.indexOf("]"));
					int index = Integer.parseInt(indexStr);
					String newPath = currPath.substring(0, currPath.length()-(indexStr.length()+ 2));
					beginningNode = beginningNode.path(newPath);
					if(i == array.length-1) {
						//If array node is the last element in the path, remove the arrayNode
						CucumberLogUtils.logDebug("removing array node at " + jsonPath);
						((ArrayNode) beginningNode).removeAll();
					} else {
						//else traverse to the nth element of the arrayNode
						beginningNode = beginningNode.get(index);
					}
				}else {
					if(i != array.length-1) {
						//If traverse through the tree until the last node
						beginningNode = beginningNode.path(currPath);
					} else {
						CucumberLogUtils.logDebug("removing node at " + jsonPath);
						((ObjectNode) beginningNode).remove(currPath);
					}
					
				}
			}
		}
	}
	
	public static void replaceNodeWithNewValueWithList(List<JSONReplacerElement> replacingList, JsonNode root) {
		replacingList.forEach(item -> {
			//TODO change the correct class type
			replaceNodeWithNewValue(root, item.getjSONpath(), item.getjSONvalue(), item.getClazzType());
		});
	}
	
	public static void replaceNodeWithNewValue(JsonNode root, String jsonPath, String newValue, String clazzType) {

		//String beginningPath;
		String[] array = jsonPath.split("/");
		
		//make beginningNode and root same at the beginning
		JsonNode beginningNode = root;
		if(array.length == 0 ) {
			//if at root path, get the node directly
			write2Node(beginningNode, jsonPath, newValue, clazzType);
		} else {
			//If more than one level, then traverse through the tree and then remove
			for(int i=0; i<array.length; i++) {
				String currPath = array[i];
				if(array[i].contains("[")){
					String indexStr = currPath.substring(currPath.indexOf("[")+1,currPath.indexOf("]"));
					int index = Integer.parseInt(indexStr);
					String newPath = currPath.substring(0, currPath.length()-(indexStr.length()+ 2));
					beginningNode = beginningNode.path(newPath);
					beginningNode = beginningNode.get(index);
				}else {
					if(i != array.length-1) {
						//If traverse through the tree until the last node
						beginningNode = beginningNode.path(currPath);
					} else {
						write2Node(beginningNode, currPath, newValue, clazzType);
					}
					
				}
			}
		}
	}
	
	private static void write2Node(JsonNode beginningNode, String currPath, String newValue, String clazzType) {
		System.out.println("replacing value at node -" + currPath + " with "+ clazzType + " Value = " + newValue);
		CucumberLogUtils.logDebug("replacing value at node -" + currPath + " with " +  newValue);

		if(null == clazzType || clazzType.equalsIgnoreCase("String")) {
			((ObjectNode) beginningNode).put(currPath, newValue);
		} else if (clazzType.equalsIgnoreCase("Number")) {
			((ObjectNode) beginningNode).put(currPath, Double.valueOf(newValue));
		} else if (clazzType.equalsIgnoreCase("Boolean")) {
			((ObjectNode) beginningNode).put(currPath, Boolean.valueOf(newValue));
		}
	}
	
	public static String getNodeValue(JsonNode root, String jsonPath) {
		String nodeValue = null;
		//String beginningPath;
		String[] array = jsonPath.split("/");
		
		//make beginningNode and root same at the beginning
		JsonNode beginningNode = root;
		if(array.length == 0 ) {
			//if at root path, remove the node directly
			nodeValue = beginningNode.asText();	
		} else {
			//If more than one level, then traverse through the tree and then remove
			for(int i=0; i<array.length; i++) {
				String currPath = array[i];
				if(array[i].contains("[")){
					String indexStr = currPath.substring(currPath.indexOf("[")+1,currPath.indexOf("]"));
					int index = Integer.parseInt(indexStr);
					String newPath = currPath.substring(0, currPath.length()-(indexStr.length()+ 2));
					beginningNode = beginningNode.path(newPath);
					beginningNode = beginningNode.get(index);
				}else {
					if(i != array.length-1) {
						//If traverse through the tree until the last node
						beginningNode = beginningNode.path(currPath);
					} else {
						if(beginningNode != null) {
							nodeValue = beginningNode.path(currPath).asText();						
						} else {
							nodeValue =  "";
						}
							
					}
					
				}
			}
		}
		return nodeValue;
	}

}
