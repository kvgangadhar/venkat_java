package com.fanniemae.razor.automation.dto;

/**
 * For the validation of JSON values 
 * @author q2uscv
 *
 */
public class JSONReplacerElement {

	private String jSONpath;
	private  String jSONvalue;
	private String jsonValueType;

	public String getjSONvalue() {
		return jSONvalue;
	}

	public void setjSONvalue(String jSONvalue) {
		this.jSONvalue = jSONvalue;
	}

	public String getjSONpath() {
		return jSONpath;
	}

	public void setjSONpath(String jSONpath) {
		this.jSONpath = jSONpath;
	}

	public String getClazzType() {
		return jsonValueType;
	}

	public void setClazzType(String clazzType) {
		this.jsonValueType = clazzType;
	}

}
