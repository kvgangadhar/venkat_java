package com.fanniemae.razor.automation;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.fanniemae.razor.automation.steps.impl.DatabaseImpl;
import com.fanniemae.razor.automation.utils.ConfUtils;
import com.fanniemae.razor.config.ApplicationConfig;
import com.fanniemae.testeng.automation.utils.LocalConfUtils;


@Component
@ComponentScan(basePackages = "com.fanniemae.razor")
public class DataValidator   {

	private static JdbcTemplate trgDB;
	private static String configFile = "./conf/local/localConf.properties";
	private static String razorEnv = "local";
	private static final String underBarFiller = StringUtils.leftPad("", 100,"_");
	Logger logger = Logger.getLogger(DataValidator.class.getName());
	public static void main(String[] args) {

		DataValidator app = new DataValidator();

		if(args.length != 0){
			razorEnv = args[0];
			//configFile = "/export/appl/fn3devl/datavalidator/conf/" + razorEnv + "Conf.properties";
			configFile = "./conf/"+razorEnv +"/"+ razorEnv + "Conf.properties";
		}
		app.startValidations();
	}

	/**
	 * Main method gets called from Autosys to initiate the validations process
	 */

	public void startValidations(){
		System.getProperties().setProperty("razor_env_path", razorEnv);
		System.getProperties().setProperty("configurationFile", configFile);
		logger.info("BEGIN: RAZOR DATALOAD AUTOMATION TESTS IN " + razorEnv.toUpperCase() + " ON " + new Date().toString());
		logger.info("CONIFG FILE: " + configFile);
		try(final AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext())
		{
			applicationContext.register(ApplicationConfig.class);
			applicationContext.refresh();

			
			Properties props = new Properties();
			int errorCode = 0;
			boolean isCritical = false;
			boolean isTestFailed = false;
			try{
				FileInputStream fis = new FileInputStream(configFile);
				props.load(fis);
			} catch (FileNotFoundException fnfe) {
				fnfe.printStackTrace();
			} catch (IOException ioe){
				ioe.printStackTrace();
			}

			String stgDbUserName = props.getProperty("aws.stage.dbconn.username");
			logger.info("Staging database User:  "+ stgDbUserName.toUpperCase());
			String mappingFileName = props.getProperty("aws.stage.dataload.mappingFile");
			String trgSchema = props.getProperty("aws.stage.dbconn.schema");
			trgDB = (JdbcTemplate) applicationContext.getBean("stagingJdbcTemplate");
			FileAppender myFileAppender;
			DateFormat dateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			Date date = new Date();
			String timestamp = dateTimeFormat.format(date); 
			DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			String dt = dateFormat.format(date);
			String dataLoadTableFetchError = "";
			String reportsOutput = null;
			if(razorEnv.equalsIgnoreCase("local")){
				reportsOutput = LocalConfUtils.getRootDir() + File.separator + "Logs" + File.separator + dt;
			} else {
				reportsOutput = "/export/appl/fn3"+razorEnv+"/datavalidator/log/" + dt;
				logger.info(":: OUTPUT DIRECTORY: " + reportsOutput);
			}

			ConfUtils.setBaseResultsDir(reportsOutput);

			PatternLayout patternLayout = new PatternLayout();
			patternLayout.setConversionPattern("[%p] %d{MM-dd-yyyy HH:mm:ss} - %m%n");

			// If tables are not in completed state and RAZOR IS still AVAILABLE?
			String tableLoadCompleteQuery = "select DISTINCT(appl_tbl_nme)" 
					+ " from "+ trgSchema +".appl_tbl_load_trkr"
					+ " where appl_tbl_load_stat_desc = 'COMPLETED'"
					+ " and appl_tbl_run_dt = (select MAX(appl_avlb_smry_run_dt) "
					+ "from "+ trgSchema +".appl_avlb_smry)";
			
			String tableTestCompleteQuery = "SELECT appl_tbl_nme FROM " + trgSchema + ".appl_tbl_appl_test_trkr "
					+ "WHERE appl_tbl_appl_test_stat = 'COMPLETED' "
					+ " AND appl_tbl_appl_test_run_dt = current_date::timestamp::date";
			
			logger.info("Data Load Complete Query: " + tableLoadCompleteQuery);
			logger.info("Validation Complete Query: " + tableTestCompleteQuery);
			List<String> tableLoadCompleteQueryResults = new ArrayList<String>();
			try{
				tableLoadCompleteQueryResults = (List<String>)trgDB.queryForList(tableLoadCompleteQuery.toString(),String.class);
			}catch(Exception e){

				dataLoadTableFetchError = "FAILURE: ERROR Excuting the Query to Fectch the table names for which data load is completed successfully " + e.toString();
				logger.info(dataLoadTableFetchError,e);
			}
			List<String> tableTestCompleteQueryResults = new ArrayList<String>();
			try{
				tableTestCompleteQueryResults = (List<String>)trgDB.queryForList(tableTestCompleteQuery.toString(),String.class);
			}catch(Exception e){

				dataLoadTableFetchError = "FAILURE: ERROR Excuting the Query to Fectch the table names for which data load is completed successfully " + e.toString();
				logger.info(dataLoadTableFetchError,e);
			}
			
			List<String> tablesBeingValidated = removeElementsFromList(tableLoadCompleteQueryResults,tableTestCompleteQueryResults);
			logger.info(" ");
			logger.info("Tables that are being validated in this run: " + tablesBeingValidated.toString());
			
			for(String tableName:tablesBeingValidated){
				DatabaseImpl impl = (DatabaseImpl) applicationContext.getBean(DatabaseImpl.class);
				
				if(!dataLoadTableFetchError.isEmpty()){
					logger.fatal(dataLoadTableFetchError);
				}
				String testCaseMapQuery = "SELECT lkup.appl_test_case_id,lkup.appl_test_case_nme,map.appl_test_case_crtl_flag,map.prnt_appl_tbl_nme,map.appl_ref_chk_reqd_ind,map.appl_test_case_reqd_ind"
						+ " FROM " + trgSchema + ".appl_tbl_test_case_map map"
						+ " INNER JOIN "+ trgSchema + ".appl_test_case_lkup lkup"
						+ " ON lkup.appl_test_case_id = map.appl_test_case_id"
						+ " WHERE map.appl_tbl_nme = '" + tableName + "'"; 
				
				//Get the test cases needed from this table
				List <Map<String, Object>> testCaseMapQueryResult = trgDB.queryForList(testCaseMapQuery);
				Object parentTableObject = !testCaseMapQueryResult.isEmpty()?testCaseMapQueryResult.get(0).get("prnt_appl_tbl_nme"):null;
				String parentTable = parentTableObject == null?"":parentTableObject.toString();

				String criticalFlag = null;
				String isRefCheckReq = null;
				String isTestCaseReq = null;
				String  methodName = null;
				int testCaseId = 0;
				boolean testCaseInProgress = false;
				boolean testTableInProgress = false;

				if (!parentTable.isEmpty() && parentTable != null && !tableLoadCompleteQueryResults.contains(parentTable)){
					continue;
				}
				try {
					myFileAppender = new FileAppender(patternLayout, reportsOutput+ File.separator + tableName +"_" + timestamp + ".log", false);
					myFileAppender.setThreshold(Level.INFO);
					BasicConfigurator.resetConfiguration();
					BasicConfigurator.configure(myFileAppender);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				logger.info("Test Case Map Query: " + testCaseMapQuery);
				isTestFailed = false;
				if(!testCaseMapQueryResult.isEmpty()){

					//Set this test table in progress in appl_tbl_appl_test_trkr
					String insertForTracking = "INSERT INTO " + trgSchema + ".appl_tbl_appl_test_trkr(appl_tbl_nme,appl_tbl_appl_test_stat,appl_tbl_appl_test_run_dt)"
							+ " VALUES ('" + tableName + "','IN PROGRESS',current_date::timestamp::date)"; 
					trgDB.execute(insertForTracking);
					impl.startValidations(tableName);
					for (Map<String, Object> m : testCaseMapQueryResult){
						testCaseInProgress = false;
						Object testCaseIdObject = m.get("appl_test_case_id");
						Object testCaseNameObject = m.get("appl_test_case_nme");
						Object criticalFlagObject = m.get("appl_test_case_crtl_flag");
						Object refCheckFlagObject = m.get("appl_ref_chk_reqd_ind");
						Object testCaseReqFlagObject = m.get("appl_test_case_reqd_ind");
						testCaseId = testCaseIdObject == null?null:((BigDecimal)testCaseIdObject).intValue();
						methodName = testCaseNameObject == null?null:testCaseNameObject.toString();
						criticalFlag = criticalFlagObject == null?"N":criticalFlagObject.toString();
						isRefCheckReq = refCheckFlagObject == null ? "N" : refCheckFlagObject.toString();
						isTestCaseReq = testCaseReqFlagObject == null ? "Y" : testCaseReqFlagObject.toString();
						//TODO: Once the flag for testCase required is enabled in db, checking for testCAseId == 0 should be cleared out
						if(testCaseId == 0 || !parentTable.isEmpty() && !tableLoadCompleteQueryResults.contains(parentTable)){
							continue;
						}
						String insertForTestCaseTracking = "INSERT INTO " + trgSchema + ".appl_test_case_trkr (appl_tbl_nme,appl_test_case_id,appl_test_case_stat,appl_test_case_strt_tm)"
								+ " VALUES('" + tableName + "'," + testCaseId + "," + "'IN PROGRESS'" + ",now())";
						trgDB.execute(insertForTestCaseTracking);
						Method validationMethod = null;

						try {
							validationMethod = impl.getClass().getMethod(methodName, String.class, String.class, String.class, String.class, String.class, int.class);
						} catch (NoSuchMethodException e) {
							logger.error("	*** Error in loading method " + methodName + ".  Method Not Found.  Please check test case lookup table...");
							e.printStackTrace();
						} catch ( SecurityException e1) {
							e1.printStackTrace();
						}
						try {
							errorCode = (Integer) validationMethod.invoke(impl, tableName, parentTable, criticalFlag, isRefCheckReq, isTestCaseReq, testCaseId);
							if (errorCode == 1 && !isCritical) isCritical = true;
						} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e1) {
							logger.error("	*** Error occured in the process.  Please check the logs...");
							e1.printStackTrace();
						}
						
						String updateTestCaseToCompleted = "UPDATE " + trgSchema + ".appl_test_case_trkr "
								+ "SET appl_test_case_stat = 'COMPLETED',"
								+ "appl_test_case_end_tm = now()"
								+ " WHERE appl_tbl_nme = '" + tableName + "'"
								+ " AND appl_test_case_id = '" + testCaseId + "'"
								+ " AND rec_cren_tm = (select max(rec_cren_tm) from " + trgSchema + ".appl_test_case_trkr where appl_tbl_nme = '" + tableName + "' AND appl_test_case_id = '" + testCaseId + "')";
						String updateTestCaseToFailed = "UPDATE " + trgSchema + ".appl_test_case_trkr "
								+ "SET appl_test_case_stat = 'FAILED',"
								+ "appl_test_case_end_tm = now(),"
								+ "appl_test_case_fail_rsn_txt = 'FAILED'"
								+ " WHERE appl_tbl_nme = '" + tableName + "'"
								+ " AND appl_test_case_id = '" + testCaseId + "'"
								+ " AND rec_cren_tm = (select max(rec_cren_tm) from " + trgSchema + ".appl_test_case_trkr where appl_tbl_nme = '" + tableName + "' AND appl_test_case_id = '" + testCaseId + "')";
						if(errorCode == 0){
							//turn to completed only if the test case is not in progress
							if(!testCaseInProgress){
								trgDB.update(updateTestCaseToCompleted);
							}
						} else {
							trgDB.update(updateTestCaseToFailed);
							isTestFailed = true;
						}
					}	//for - testcases

					//All test cases for the table are done -- Update table as COMPLETED
					String updateTblTrkrStatusToCompleted = "UPDATE " + trgSchema + ".appl_tbl_appl_test_trkr SET appl_tbl_appl_test_stat = 'COMPLETED' "
							+ "WHERE appl_tbl_nme = '" + tableName + "'"
							+ " AND rec_cren_tm = (select max(rec_cren_tm) from "  + trgSchema + ".appl_tbl_appl_test_trkr where appl_tbl_nme = '" + tableName + "')";
					String updateTblTrkrStatusToFailed = "UPDATE " + trgSchema + ".appl_tbl_appl_test_trkr SET appl_tbl_appl_test_stat = 'FAILED' "
							+ "WHERE appl_tbl_nme = '" + tableName + "'"
							+ " AND rec_cren_tm = (select max(rec_cren_tm) from "  + trgSchema + ".appl_tbl_appl_test_trkr where appl_tbl_nme = '" + tableName + "')";
					if(isTestFailed){
						//ToDo Need to handle Critical (1), Error (2) and Warning(3) and insert records into the error table accordingly.
						trgDB.update(updateTblTrkrStatusToFailed);
					} else if(!isTestFailed && !testTableInProgress){
						trgDB.update(updateTblTrkrStatusToCompleted);
					} 

				}
				else {
					logger.warn("WARNING:  No Test Case mapping found in APPL_TBL_TEST_CASE_MAP for the table " + tableName);
				}
				
				impl.endValidations(tableName);
			}
			
			if(isCritical){
				logger.info("*****************************************************************************************************");
				logger.info("*****************************************************************************************************");
				logger.info("*****************************************************************************************************");
				logger.info(" ");
				logger.fatal("CRITICAL ERRORS FOUND IN THE PROCESS.  EXITING THE APPLICATION AND SENDING ALARM FOR FUTHER ACTION....");
				logger.info(" ");
				logger.info("*****************************************************************************************************");
				logger.info("*****************************************************************************************************");
				logger.info("*****************************************************************************************************");
				System.exit(1);
			}
		}
	} 
	private List<String> removeElementsFromList(List<String> list1, List<String> list2) {
	    List<String> ret = list1.stream()
	        .filter(o -> !list2.contains(o))
	        .collect(Collectors.toList());
	    return ret;
	}
}
