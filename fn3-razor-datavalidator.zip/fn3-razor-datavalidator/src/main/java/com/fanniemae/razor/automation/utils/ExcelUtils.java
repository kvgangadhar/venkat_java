/*
 * Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.razor.automation.utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fanniemae.razor.automation.common.CommonConstants;
import com.fanniemae.razor.automation.dto.MappingDTO;
import com.fanniemae.razor.automation.dto.SourceDTO;

public class ExcelUtils implements CommonConstants {	
	private static Logger logger = Logger.getLogger(ExcelUtils.class.getName());
	public static Set<String> getAllTargetColumns(String fileName) throws Exception{
		Map<String, List<MappingDTO>> sourceMap = processExcel(fileName,null,null).getSourceMap();
		List<String> trgColumns = null;
		Set<String> trgUniqueColumns = new HashSet<String>();
		String trgTable = null;
		for(List<MappingDTO> mappingDTOList : sourceMap.values()) {
			for(MappingDTO mappingDTO:mappingDTOList){
				trgTable = mappingDTO.getTrgTableName().toUpperCase();
				trgColumns = mappingDTO.getTrgColumns();
				List<String> trgColumnsUpper = trgColumns.stream()
						.map(String::toUpperCase)
						.collect(Collectors.toList());

				for(String trgColumn:trgColumnsUpper){
					trgUniqueColumns.add(trgTable.trim() + "." + trgColumn.trim());
				}
			}
		}

		return trgUniqueColumns;
	}

	public static SourceDTO processExcel(String fileName,String source,String tableName) throws Exception {

		Row row = null;
		SourceDTO sourceDTO = null;
		DataFormatter formatter = new DataFormatter();
		Workbook workbook = null;
		try{
			FileInputStream inputStream = new FileInputStream(new File(fileName));

			workbook = new XSSFWorkbook(inputStream);
		}catch(Exception e){
			logger.info("FAILURE: Errors in reading the Excel mapping file...");
			e.printStackTrace();
		}
		Sheet sheet = workbook.getSheetAt(0);
		for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
			Map<String, List<MappingDTO>> sourceMap = null;
			List<MappingDTO> mappingDTOList = null;
			List<String> srcColumns = null;
			List<String> trgColumns = null;
			MappingDTO mappingDTO = null;
			row = sheet.getRow(rowIndex);
			String sourceName = null;
			try{
				sourceName = formatter.formatCellValue(row.getCell(EXCEL_SOURCE_INDEX)).toUpperCase().trim();
				String rowNum = formatter.formatCellValue(row.getCell(0));
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			if(source != null && !sourceName.equalsIgnoreCase(source)){
				continue;
			}
			String trgTableName = formatter.formatCellValue(row.getCell(EXCEL_TARGET_TABLE_INDEX)).toUpperCase().trim();
			if(tableName != null && !trgTableName.equalsIgnoreCase(tableName)){
				continue;
			}
			String srcTableName = formatter.formatCellValue(row.getCell(EXCEL_SOURCE_TABLE_INDEX)).toUpperCase().trim();
			String srcColName = formatter.formatCellValue(row.getCell(EXCEL_SOURCE_COLUMN_INDEX)).toUpperCase().trim();
			String trgColName = formatter.formatCellValue(row.getCell(EXCEL_TARGET_COLUMN_INDEX)).toUpperCase().trim();
			String srcKeyColumn = formatter.formatCellValue(row.getCell(EXCEL_SOURCE_KEY_INDEX)).toUpperCase().trim();
			String trgKeyColumn = formatter.formatCellValue(row.getCell(EXCEL_TARGET_KEY_INDEX)).toUpperCase().trim();
			if (sourceDTO == null) {
				sourceDTO = new SourceDTO();	
				sourceMap = new HashMap<>();
			} else {
				sourceMap = sourceDTO.getSourceMap();
				if (sourceMap.get(sourceName) != null) {
					mappingDTOList = sourceDTO.getSourceMap().get(sourceName);
				}
			}
			if (mappingDTOList == null) {
				mappingDTOList = new ArrayList<>();
			} else {
				//updated to select DTO that has matching srcTable and trgTable
				List<MappingDTO> matchingSource = mappingDTOList.stream()
						.filter(o -> o.getSrcTableName().equals(srcTableName))
						.filter(o -> o.getTrgTableName().equals(trgTableName))
						.collect(Collectors.toList());


				if (matchingSource != null && !matchingSource.isEmpty()) {
					mappingDTO = matchingSource.get(0);
					srcColumns = matchingSource.get(0).getSrcColumns();
					trgColumns = matchingSource.get(0).getTrgColumns();
				} 				
			}
			if(mappingDTO == null){
				mappingDTO = new MappingDTO();
				srcColumns = new ArrayList<>();
				trgColumns = new ArrayList<>();
				mappingDTO.setSrcTableName(srcTableName);
				mappingDTO.setTrgTableName(trgTableName);
				mappingDTO.setSrcKeyColumn(srcKeyColumn);
				mappingDTO.setTrgKeyColumn(trgKeyColumn);
				mappingDTOList.add(mappingDTO);
			}
			if (srcColumns != null && srcColName != null && trgColumns != null && trgColName != null) {
				srcColumns.add(srcColName);
				trgColumns.add(trgColName);
			}else{
				throw new Exception("FAILURE: Invalid Column mapping " + sourceName );
			}
			mappingDTO.setSrcColumns(srcColumns);
			mappingDTO.setTrgColumns(trgColumns);
			sourceMap.put(sourceName, mappingDTOList);
			sourceDTO.setSourceMap(sourceMap);
		}
		return sourceDTO;
	}

	public static Map<String,String> sourceLookupForTable(String fileName) throws Exception {
		Row row = null;
		DataFormatter formatter = new DataFormatter();
		Map<String,String> sourceLookup = new HashMap<String,String>();
		Workbook workbook = WorkbookFactory.create(new File(fileName));
		Sheet sheet = workbook.getSheetAt(0);
		for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
			row = sheet.getRow(rowIndex);
			String sourceName = formatter.formatCellValue(row.getCell(EXCEL_SOURCE_INDEX)).toUpperCase().trim();
			String sourceTableName = formatter.formatCellValue(row.getCell(EXCEL_SOURCE_TABLE_INDEX)).toUpperCase().trim();
			sourceLookup.put(sourceTableName, sourceName);
		}
		return sourceLookup;
	}
	
	public static void main(String[] args){
		try {
			SourceDTO sourceDTO = processExcel("C:/Users/sxusyp/git/fn3-razor-datavalidator/data/Expense_Attributes_Data_Mapping.xlsx",null,"PROP");
			System.out.println(sourceDTO.getSourceMap());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
