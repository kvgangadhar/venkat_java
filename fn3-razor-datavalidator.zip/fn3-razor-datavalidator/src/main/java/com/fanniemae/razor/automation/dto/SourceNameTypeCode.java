package com.fanniemae.razor.automation.dto;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 
 * Tool generated code
 */
public enum SourceNameTypeCode
{
	ARROW(1,"ARROW","fpw"),
	CDM(2,"CDM","cdm"),
	DARTS(3,"DARTS","clm"),
	EBOUTIQUE(4,"eButique","ebtq"),
	EDI(5,"EDI","edi"),
	EQUATOR_ODS(6,"Equator ODS","eqtr"),
	IHDS(7,"IHDS","ihds"),
	LMV(8,"LMV","lmv"),
	OASIS(9,"OASIS","oasis"),
	PRDW(10,"PRDW","prdw"),
	RDW(11,"RDW","rdw"),
	SERFS(12,"SERFS","clm");
	
	/**
	 * Constructor
	 * @param code typecode value
	 * @param desc typecode description 
	 * @param label typecode schema prefix
	 */
	private SourceNameTypeCode(int code, String desc, String label) {
		this.code = code;
		this.label = label;
		this.desc = desc;
	}

	/**
	 * Return the enum instance for the specified code value.
	 * 
	 * @param code type code value
	 * @return SourceNameTypeCode object
	 */
	public static SourceNameTypeCode valueOf(int code) {
		for (SourceNameTypeCode tmp : SourceNameTypeCode .values()) {
			if (tmp.getCode() == code) {
				return tmp;
			}
		}
		return null;
	}

	/** 
	 * @return map of all code values as key and name as value.
	 */
	public static Map<String, Integer> valuesMap() {
		if (mapValues == null)
		{
			mapValues = new LinkedHashMap<String, Integer>();
			for (SourceNameTypeCode tmp : SourceNameTypeCode .values()) {
				mapValues.put(tmp.getLabel(), Integer.valueOf(tmp.getCode()));
			}
		}
		return mapValues;
	}

    /** 
     * @return map of all enum codes in map. Map key is code and value is code-label
     */
    public static Map<String, Integer> codeLabelValuesMap() {
        if (mapCodeLabelValues == null)
        {
            mapCodeLabelValues = new LinkedHashMap<String, Integer>();
            for (SourceNameTypeCode tmp : SourceNameTypeCode .values()) {
                mapCodeLabelValues.put(tmp.getCode() + " - " + tmp.getLabel(), Integer.valueOf(tmp.getCode()));
            }
        }
        return mapCodeLabelValues;
    }
    
	/** 
	 * @return list of all typecodes.
	 */
	public static List<Enum> valuesList() {
		if (listValues == null)	{
			listValues = new ArrayList<Enum>(EnumSet.allOf(SourceNameTypeCode .class));
		}
		return listValues;
	}


	/**
	 * @return the code
	 */
	public int getCode() {
		return code;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @return the name
	 */
	public String getLabel() {
		return label;
	}
    /**
     * @return the codeLabel
     */
    public String getCodeLabel() {
        return codeLabel;
    }

    /**
     * @param codeLabel the codeLabel to set
     */
    public void setCodeLabel(String codeLabel) {
        this.codeLabel = codeLabel;
    }	
	private int code;
	private String label;
    private String codeLabel;
	private String desc;
	private static Map<String, Integer> mapValues = null;
    private static Map<String, Integer> mapCodeLabelValues = null;    
	private static List<Enum> listValues = null;
}
