package com.fanniemae.razor.automation.common;

import java.io.IOException;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class CustomDateTimeSerializer extends JsonSerializer<DateTime> {

	private static String timeFormat = "yyyy-MM-dd'T'HH:mm:ss";
	@Override
	public void serialize(DateTime value, JsonGenerator gen, SerializerProvider serializers)
			throws IOException, JsonProcessingException {
		DateTimeFormatter formatter = 
		        DateTimeFormat.forPattern(timeFormat);
		gen.writeString(formatter.print(value.toLocalDateTime()));
		
	}

}
