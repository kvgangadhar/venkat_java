/*package com.fanniemae.razor.automation.utils;


import static org.apache.http.util.TextUtils.isEmpty;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fanniemae.razor.automation.common.CommonCache;
import com.fanniemae.razor.automation.common.CommonCacheConstants;
import com.fanniemae.razor.automation.db.TransactionDAO;
import com.fanniemae.razor.automation.dto.LookupCodeDTO;
import com.fanniemae.razor.automation.steps.impl.DatabaseImpl;
import com.fanniemae.razor.request.ClaimDecisionRequest;
import com.fanniemae.razor.request.ClaimLineItem;
import com.fanniemae.testeng.automation.exceptions.TestingException;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;

@Component
public class LookupCodeUtil {
	
	@Autowired
	private TransactionDAO transactionDAO;
	
	@Autowired
	private CommonCache commonCache;
	
	private final String lookUpCodeQuery = "select data_enum_attr_nm as \"codeName\", data_enum_tp as \"codeType\", data_enum_ds as \"sourceCodeDescr\"," + 
											 "data_enum_edg_tp as \"targetCodeDescr\" from data_enum_lkup where data_enum_tp is not null";
	
	@PostConstruct
	public void init() {
		CucumberLogUtils.logDebug("About to initialize LookupCodes Map ");
		loadLookUpCodes();
	}

	private static Map<String, Map<String,LookupCodeDTO>> lookupCodeMapOfMap; 
	private static final String OTHER_TEXT_CODE = "Other";
	private static final String NOT_AVAILABLE_TEXT = "NotAvailable";
	
	public List<LookupCodeDTO> getLookupCodes() {
		System.out.println("Fetching LookupCodes from Database");
    	//String lookUpCodeQuery = "select * from data_enum_lkup where data_enum_tp is not null";
    	
		List<LookupCodeDTO> lookupCodeEntities = null;
		try {
			lookupCodeEntities = transactionDAO.getAllLookupCodes(lookUpCodeQuery);
			CucumberLogUtils.logInfo("---this::findAllLookupCodes ---" + lookupCodeEntities.size()+ ":" + lookupCodeEntities.get(0).getCodeName());

		} catch (TestingException e) {
			e.printStackTrace();
			CucumberLogUtils.logFail("Error occured while fetching Lookup Codes from DB", false);
		}
        return lookupCodeEntities;
    }

	public Map<String, Map<String,LookupCodeDTO>> populateLookupMap(List<LookupCodeDTO> lookupCodes) {
    	CucumberLogUtils.logInfo("Populating LookupCodeMap");
        
    	Map<String, Map<String,LookupCodeDTO>> lookupCodeMapOfMap = new HashMap<>();
    	
    	for(LookupCodeDTO code: lookupCodes)
    	{
    		Map<String, LookupCodeDTO>  lookupCodeMap = lookupCodeMapOfMap.get(code.getCodeType());
    		if(lookupCodeMap == null)
    		{
    			lookupCodeMap = new HashMap<>();
    			lookupCodeMapOfMap.put(code.getCodeType(), lookupCodeMap);
    		}
       		lookupCodeMap.put(code.getSourceCodeDescr().toUpperCase(), code);
    	}
    	return lookupCodeMapOfMap;
    }
	
	
	
	public void translateLookUpCodes(ClaimDecisionRequest request) {
		
		lookupCodeMapOfMap = commonCache.getFromCache(HashMap.class, CommonCacheConstants.LOOKUP_CODE_CACHE);
        CucumberLogUtils.logInfo("Translating LookupCodes to EDG Values");
        
        String claimSourceId = request.getValidateClaim()[0].getClaimSourceId();
        if (!isEmpty(claimSourceId)) {
        	LookupCodeDTO lookupCode = getLookupCode(LookupCodeTypes.CLAIM_SOURCE_ID.getLookupCodeType(), claimSourceId);
        	if(lookupCode == null) {
        		CucumberLogUtils.logFail("Invalid Claim Source ID for Reuest - " + request.getRequestId(), false);
        	} else if(!isEmpty(lookupCode.getTargetCodeDescr())) {
        		//Change to the EDG lookup code if it is not empty
        		request.getValidateClaim()[0].setClaimSourceId(lookupCode.getTargetCodeDescr());
        	}
        }

        String claimType = request.getValidateClaim()[0].getClaimTypeDsc();
        if (!isEmpty(claimType)) {
        	LookupCodeDTO lookupCode = getLookupCode(LookupCodeTypes.CLAIM_TYPE.getLookupCodeType(), claimType);
        	if(lookupCode == null) {
        		CucumberLogUtils.logFail("Invalid Claim TYPE for Reuest - " + request.getRequestId(), false);
        	} else if(!isEmpty(lookupCode.getTargetCodeDescr())) {
        		//Change to the EDG lookup code if it is not empty
        		request.getValidateClaim()[0].setClaimTypeDsc(lookupCode.getTargetCodeDescr());
        	}
        }

        String claimStatus = request.getValidateClaim()[0].getClaimStatusDsc();
        if (!isEmpty(claimStatus)) {
        	LookupCodeDTO lookupCode = getLookupCode(LookupCodeTypes.CLAIM_STATUS.getLookupCodeType(), claimStatus);
        	if(lookupCode == null) {
        		CucumberLogUtils.logFail("Invalid Claim Status for Reuest - " + request.getRequestId(), false);
        	} else if(!isEmpty(lookupCode.getTargetCodeDescr())) {
        		//Change to the EDG lookup code if it is not empty
        		request.getValidateClaim()[0].setClaimStatusDsc(lookupCode.getTargetCodeDescr());
        	}
        }
        
        ClaimLineItem[] lineItems = request.getValidateClaim()[0].getLineItem();
        int index = 0;
        for (ClaimLineItem lineItem : lineItems) {
        	if (!isEmpty(lineItem.getCurtailmentReasonTxt())) {
				LookupCodeDTO lookupCode = getLookupCode(
						LookupCodeTypes.CURTAILMENT_REASON.getLookupCodeType(), lineItem.getCurtailmentReasonTxt());
            	if(lookupCode == null) {
            		CucumberLogUtils.logFail("Invalid Curtailement Reason - "+ lineItem.getCurtailmentReasonTxt() + "for Reuest - " + request.getRequestId(), false);
            	} else if(!isEmpty(lookupCode.getTargetCodeDescr())) {
            		//Change to the EDG lookup code if it is not empty
            		 lineItem.setCurtailmentReasonTxt(lookupCode.getTargetCodeDescr());
            	}
            	
            }
            
            if (!isEmpty(lineItem.getInvestorBucketCd())) {
				LookupCodeDTO lookupCode = getLookupCode(
						LookupCodeTypes.INVESTOR_BUCKET_CD.getLookupCodeType(), lineItem.getInvestorBucketCd());
            	if(lookupCode == null) {
            		CucumberLogUtils.logFail("Invalid investor bucket code - "+ lineItem.getInvestorBucketCd() + "for Reuest - " + request.getRequestId(), false);
            	} else if(!isEmpty(lookupCode.getTargetCodeDescr())) {
            		//Change to the EDG lookup code if it is not empty
            		 lineItem.setInvestorBucketCd(lookupCode.getTargetCodeDescr());
            	}
            	
            }

            if (!isEmpty(lineItem.getMeasurementTypeDsc())) {
				LookupCodeDTO lookupCode = getLookupCode(
						LookupCodeTypes.MEASUREMENT_TYPE.getLookupCodeType(), lineItem.getMeasurementTypeDsc());
            	if(lookupCode == null) {
            		CucumberLogUtils.logFail("Invalid Measurement Type - "+ lineItem.getMeasurementTypeDsc() + "for Reuest - " + request.getRequestId(), false);
            	} else if(!isEmpty(lookupCode.getTargetCodeDescr())) {
            		//Change to the EDG lookup code if it is not empty
            		 lineItem.setMeasurementTypeDsc(lookupCode.getTargetCodeDescr());
            	}
            	
            }
            

            //If FloodZoneCd = A or a  Set as A
       		//If FloodZoneCd =V or v Set as  V
            //If FloodZoneCd =NULL Set as NotAvailable
            //If FloodZoneCd =Anything other than above Set as Other
            if (!isEmpty(lineItem.getFloodZoneCd())) {
				LookupCodeDTO lookupCode = getLookupCode(
						LookupCodeTypes.FLOOD_ZONE_CD.getLookupCodeType(), lineItem.getFloodZoneCd());
            	if(lookupCode == null) {
            		lineItem.setFloodZoneCd(OTHER_TEXT_CODE);
            	} else if(!isEmpty(lookupCode.getTargetCodeDescr())) {
            		//Change to the EDG lookup code if it is not empty
            		 lineItem.setFloodZoneCd(lookupCode.getTargetCodeDescr());
            	} else {
            		lineItem.setFloodZoneCd(OTHER_TEXT_CODE);
            	}
            	
            } else {
            	lineItem.setFloodZoneCd(NOT_AVAILABLE_TEXT);
            }
            
            //If bkChapterCode matches with the look up codes, then replace with the correct lookup code.  
            //If bkChapterCode = NULL, 0, &n, NU or any another value change it to "Other"
            if (!isEmpty(lineItem.getBkChapterCd())) {
				LookupCodeDTO lookupCode = getLookupCode(
						LookupCodeTypes.BANKRUPTCY_CHATPER_CD.getLookupCodeType(), lineItem.getBkChapterCd().trim());
            	if(lookupCode == null) {
            		lineItem.setBkChapterCd(OTHER_TEXT_CODE);
            	} else if(!isEmpty(lookupCode.getTargetCodeDescr())) {
            		//Change to the EDG lookup code if it is not empty
            		 lineItem.setBkChapterCd(lookupCode.getTargetCodeDescr());
            	} else {
            		lineItem.setBkChapterCd(OTHER_TEXT_CODE);
            	}
            	
            } else {
            	lineItem.setBkChapterCd(OTHER_TEXT_CODE);
            }
            index++;
        }

    }

	public LookupCodeDTO getLookupCode(String codeType, String codeDescr) {
    	CucumberLogUtils.logDebug("Get Lookup Code from the matching codeType");
 		LookupCodeDTO code = null;
    	if ((lookupCodeMapOfMap == null) || 
    			((lookupCodeMapOfMap != null) && (lookupCodeMapOfMap.size() == 0)))  {
    		loadLookUpCodes();
    	}

		Map<String, LookupCodeDTO>  lookupCodeMap = lookupCodeMapOfMap.get(codeType);
		if(lookupCodeMap != null)
		{
			code = lookupCodeMap.get(codeDescr.toUpperCase());
		}
        return  code;
    }

	public void loadLookUpCodes() {
		List<LookupCodeDTO> lookupCodes = getLookupCodes();
		lookupCodeMapOfMap = populateLookupMap(lookupCodes);
		putLookUpCodeInCache(lookupCodeMapOfMap);
	}

	private void putLookUpCodeInCache( Map<String, Map<String,LookupCodeDTO>> codeMap) {
		CucumberLogUtils.logDebug("Load LookupCode in Cache");
		Map<String, Map<String,LookupCodeDTO>> map = commonCache.getFromCache(HashMap.class, CommonCacheConstants.LOOKUP_CODE_CACHE);
		map.putAll(codeMap);
	}
	
}
*/