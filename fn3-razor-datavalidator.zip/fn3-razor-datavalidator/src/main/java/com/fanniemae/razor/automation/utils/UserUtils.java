package com.fanniemae.razor.automation.utils;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fanniemae.testeng.automation.common.UserCredentials;
import com.fanniemae.testeng.automation.exceptions.TestingException;
import com.fanniemae.testeng.automation.xml.JDomXmlUtils;

/**
 * To get the user credentials for different environments
 * 
 * @author q2uscv
 *
 */
@Component
public class UserUtils {

	@Autowired
	private ConfUtils confUtils;

	static Logger log = Logger.getLogger(UserUtils.class.getName());

	public static UserCredentials userCredentials;
	private static final String XPATH_USERNAME = "//account[@env='%s']/user[@type='%s']/username";
	private static final String XPATH_PASSWORD = "//account[@env='%s']/user[@type='%s']/password";

	public static UserCredentials getCredentials() {
		return userCredentials;
	}

	public UserCredentials getLoginCredentials(String userType) throws TestingException {

		String env = confUtils.getEnvironment();
		String userName = getUserName(userType, env);
		String password = getPassword(userType, env);

		log.info("UserName is: " + userName + " and Password is: " + password);

		return new UserCredentials(userName, password);
	}

	public String getUserName(String userType, String env) throws TestingException {
		String xPath = String.format(XPATH_USERNAME, env, userType);

		String value = getConfigValue(xPath);

		// If value was not found for specific env, try env="all"
		if (StringUtils.isBlank(value)) {
			xPath = String.format(XPATH_USERNAME, "default", userType);
			value = getConfigValue(xPath);
		}

		return value;
	}

	public String getPassword(String userType, String env) throws TestingException {
		String xPath = String.format(XPATH_PASSWORD, env, userType);
		String value = getConfigValue(xPath);

		// If value was not found for specific env, try env="all"
		if (StringUtils.isBlank(value)) {
			xPath = String.format(XPATH_PASSWORD, "default", userType);
			value = getConfigValue(xPath);
		}

		return value;
	}

	private String getConfigValue(String configElementXPath) throws TestingException {
		String userFilePath = confUtils.getUserFileResourcePath();
		String configElementValue = null;

		try {
			configElementValue = JDomXmlUtils.getValueByXpathFromResourcePath(userFilePath, configElementXPath);
		} catch (IOException ioException) {
			throw new TestingException("IO Error while reading users xml file from the location: " + configElementXPath,
					ioException);
		}

		return configElementValue;
	}

}
