package com.fanniemae.razor.aws.utils;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Properties;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.ssl.SSLContexts;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.BasicSessionCredentials;
import com.fanniemae.access.sts.AWSFederationAccess;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;

/**
 * Common Utility classes that are required for interacting with AWS resources
 * @author q2uscv
 *
 */
public class AWSCommonUtils {
	
	/**
	 * Get AWS Session credentials using federated access
	 * @param username
	 * @param password
	 * @param awsIAMRole
	 * @return
	 * @throws Exception 
	 */
	public static BasicSessionCredentials getBasicSessionCredentials(String username, String password, String awsRole) throws Exception 
	{
		AWSFederationAccess fedAccess = new AWSFederationAccess();
		BasicSessionCredentials credentials = fedAccess.getBasicSessionCredentials(username, password, awsRole);
		BasicSessionCredentials basicSessionCredentials = new BasicSessionCredentials(
						credentials.getAWSAccessKeyId(), credentials.getAWSSecretKey(), credentials.getSessionToken());
		return basicSessionCredentials;
	}
	
	public static BasicAWSCredentials  getBasicSessionCredentialsWithAcceKeys(String awsAccessKeyId, String awsSecretAccessKey) throws Exception 
	{
		System.out.println("****** Getting basic credetinals using AWS AcceKey");
		BasicAWSCredentials  credentials = new BasicAWSCredentials(awsAccessKeyId, awsSecretAccessKey);
		return credentials;
	}
	
	/**
	 * Get client configuration to connect AWS
	 * @return
	 */
	public static ClientConfiguration getAWSClientConfig(Protocol protocol) {
		ClientConfiguration clientConf = new ClientConfiguration();
		Properties config = getPropertyConfig();
		clientConf.setProtocol(protocol);
		clientConf.setProxyHost(config.getProperty("PROXY_HOST"));
		clientConf.setProxyPort(Integer.parseInt(config.getProperty("PROXY_PORT")));
		if(protocol.equals(Protocol.HTTPS)) {
			SSLConnectionSocketFactory sslsf = getSSLConfig();
			clientConf.getApacheHttpClientConfig().setSslSocketFactory(sslsf);
		}
		
		return clientConf;
	}
	
	/**
	 * Get SSLConnectionFactory for HTTPS connection
	 * @return
	 */
	public static SSLConnectionSocketFactory getSSLConfig() {
		Properties config = getPropertyConfig();
		String trustStoreAPassword = new String(
				org.apache.commons.codec.binary.Base64.decodeBase64(config.getProperty("TRUST_STORE_PASSWORD")));
		SSLConnectionSocketFactory sslsf = null;
		try {
			KeyStore trustKeyStore = KeyStore.getInstance("JKS");
			trustKeyStore.load(
					AWSFederationAccess.class.getClassLoader().getResourceAsStream(config.getProperty("TRUST_STORE")),
					trustStoreAPassword.toCharArray());

			SSLContext sslcontext = SSLContexts.custom().loadTrustMaterial(trustKeyStore, new TrustSelfSignedStrategy())
					.build();
			sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1.2" }, null,
					SSLConnectionSocketFactory.getDefaultHostnameVerifier());
		} catch (KeyManagementException | NoSuchAlgorithmException | CertificateException | KeyStoreException
				| IOException ex) {
			CucumberLogUtils.logFail("Exception occured while reading while getting SSL AWS Connection", ex, false);
		}

		return sslsf;
	}
	
	public static Properties getPropertyConfig() {
		Properties config = new Properties();
		InputStream propInputStream = AWSFederationAccess.class.getClassLoader().getResourceAsStream("saml.properties");
		try {
			config.load(propInputStream);
		} catch (IOException ex) {
			CucumberLogUtils.logFail("IO Exception occured while reading while getting SAML.properties", ex, false);
		}
		return config;
	}


}
