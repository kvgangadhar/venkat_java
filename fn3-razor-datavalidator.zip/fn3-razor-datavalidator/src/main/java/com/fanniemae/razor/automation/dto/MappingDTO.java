/*
 * Copyright (c) 2018 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */

package com.fanniemae.razor.automation.dto;

import java.util.List;

public class MappingDTO {
	
	private String trgTableName;
	private String srcTableName;
	private List<String> srcColumns;
	private List<String> trgColumns;
	private String srcKeyColumn;
	private String trgKeyColumn;
	/**
	 * @return the trgTableName
	 */
	public String getTrgTableName() {
		return trgTableName;
	}
	/**
	 * @param trgTableName the trgTableName to set
	 */
	public void setTrgTableName(String trgTableName) {
		this.trgTableName = trgTableName;
	}
	/**
	 * @return the srcTableName
	 */
	public String getSrcTableName() {
		return srcTableName;
	}
	/**
	 * @param srcTableName the srcTableName to set
	 */
	public void setSrcTableName(String srcTableName) {
		this.srcTableName = srcTableName;
	}
	/**
	 * @return the srcColumns
	 */
	public List<String> getSrcColumns() {
		return srcColumns;
	}
	/**
	 * @param srcColumns the srcColumns to set
	 */
	public void setSrcColumns(List<String> srcColumns) {
		this.srcColumns = srcColumns;
	}
	/**
	 * @return the trgColumns
	 */
	public List<String> getTrgColumns() {
		return trgColumns;
	}
	/**
	 * @param trgColumns the trgColumns to set
	 */
	public void setTrgColumns(List<String> trgColumns) {
		this.trgColumns = trgColumns;
	}
	/**
	 * @return the srcKeyColumn
	 */
	public String getSrcKeyColumn() {
		return srcKeyColumn;
	}
	/**
	 * @param srcKeyColumn the srcKeyColumn to set
	 */
	public void setSrcKeyColumn(String srcKeyColumn) {
		this.srcKeyColumn = srcKeyColumn;
	}
	/**
	 * @return the trgKeyColumn
	 */
	public String getTrgKeyColumn() {
		return trgKeyColumn;
	}
	/**
	 * @param trgKeyColumn the trgKeyColumn to set
	 */
	public void setTrgKeyColumn(String trgKeyColumn) {
		this.trgKeyColumn = trgKeyColumn;
	}
	
	
}
