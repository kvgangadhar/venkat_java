package com.fanniemae.razor.aws.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Properties;

import org.springframework.stereotype.Component;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.StorageClass;
import com.fanniemae.razor.automation.utils.CommonUtils;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;

@Component
public class AWSS3Utils {
	
	
	//@Autowired
	//private AWSCommonUtils awsCommonUtils;

	public static void main(String[] args) throws IOException {
		//TODO change sso userid and password
		System.out.println("Started");
		AWSS3Utils utils = new AWSS3Utils();
//		InputStream is = utils.getS3ObjectContent("fnma-razor01-devl-us-east-1-build-private", "validateS3.txt", "q2uscv",	"","DEVL-RAZOR01-DEVELOPER");
		InputStream is = utils.getS3ObjectContent("fnma-pvdevl-us-east-1-app-fn3-d", "FN3_POSTGRESQL_ACCT", "q2uscv","May@2017", "DEVL-RAZOR01-DEVELOPER");
		String value = CommonUtils.convertInputStream2String(is);
		is.close();
		System.out.println("Output = " + value);
	}

	private AmazonS3 getS3Client(String username, String password, String awsRole) {
		ClientConfiguration clientConf = AWSCommonUtils.getAWSClientConfig(Protocol.HTTPS);
		AmazonS3 s3client = null;
		try {
			CucumberLogUtils.logInfo("Fetching S3 client for UserID - " + username + " and Role - " + awsRole);
			BasicSessionCredentials basicSessionCredentials = AWSCommonUtils
					.getBasicSessionCredentials(username, password, awsRole);
			
			s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(basicSessionCredentials))
					.withClientConfiguration(clientConf).withRegion(Regions.US_EAST_1).build();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s3client;
	}
	
	private AmazonS3 getS3ClientWithAccessKey(String awsAccessKeyId, String awsSecretAccessKey) {
		ClientConfiguration clientConf = AWSCommonUtils.getAWSClientConfig(Protocol.HTTPS);
		AmazonS3 s3client = null;
		try {
			System.out.println("****** About to get S3 client using AWS AcceKey");
//			AWSCredentials credentials = new ProfileCredentialsProvider().getCredentials();
			BasicAWSCredentials credentials = AWSCommonUtils
					.getBasicSessionCredentialsWithAcceKeys(awsAccessKeyId, awsSecretAccessKey);
		
			s3client = AmazonS3ClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(credentials)).withClientConfiguration(clientConf).withRegion(Regions.US_EAST_1).build();
			

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s3client;
	}
	
	
	public InputStream getS3ObjectContent(String bucketName, String objectName, String userName,
			String userPassword, String awsRole) {
		GetObjectRequest getObjectRequest = new GetObjectRequest(bucketName, objectName);
		S3Object s3obj = getS3Client(userName, userPassword, awsRole).getObject(getObjectRequest);
		InputStream fileContent = s3obj.getObjectContent();
		return fileContent;
	}
	
	public InputStream getS3ObjectContentWithAccessKey(String bucketName, String objectName, String awsAccessKeyId, String awsSecretAccessKey) {
		GetObjectRequest getObjectRequest = new GetObjectRequest(bucketName, objectName);
		S3Object s3obj = getS3ClientWithAccessKey(awsAccessKeyId, awsSecretAccessKey).getObject(getObjectRequest);
		InputStream fileContent = s3obj.getObjectContent();
		return fileContent;
	}

	public static Properties loadPropsFromFile(String fileName) throws IOException {
		if (fileName == null) {
			fileName = System.getProperty("user.home") + File.separator + ".aws" + File.separator + "credentials";
		}
		Path configLocation = Paths.get(fileName);
		System.out.println("Config location: " + configLocation.toString());
		try (InputStream stream = Files.newInputStream(configLocation)) {
			Properties config = new Properties();
			config.load(stream);
			return config;
		}
	}
	
	public int getS3ObjectCount(String bucketName, String prefix, String userName,
		String userPassword, String awsRole) {
		AmazonS3 s3obj = getS3Client(userName, userPassword, awsRole);
		ObjectListing listing = s3obj.listObjects( bucketName, prefix );
		List<S3ObjectSummary> summaries = listing.getObjectSummaries();
		while (listing.isTruncated()) {
		   listing = s3obj.listNextBatchOfObjects (listing);
		   summaries.addAll (listing.getObjectSummaries());
		}
		return summaries.size();
	}
	
	public void writeToS3(String bucketName, String objPath, String message, String userName,
		String userPassword, String awsRole) {
		AmazonS3 s3Client = getS3Client(userName, userPassword, awsRole);
		this.saveToS3(s3Client,bucketName, message, objPath );
	}
	
	public void saveToS3(AmazonS3 s3Client, String s3BucketName, String message, String s3Key) {
        try {
            InputStream stream = new ByteArrayInputStream(message.getBytes(StandardCharsets.UTF_8));
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
            metadata.setContentType("application/json");
            metadata.setContentLength(message.getBytes().length);
            metadata.setContentDisposition("attachment; filename=\"" + s3Key);
            PutObjectRequest put = new PutObjectRequest(s3BucketName, s3Key, stream, metadata);
            put.setStorageClass(StorageClass.ReducedRedundancy);
            put.setMetadata(metadata);
            s3Client.putObject(put);
        } catch (AmazonServiceException ase) {
            CucumberLogUtils.logFail(ase.getErrorMessage(), false);
        } catch (AmazonClientException ace) {
        	CucumberLogUtils.logFail(ace.getMessage(), false);
        }
    }
	
	
}
