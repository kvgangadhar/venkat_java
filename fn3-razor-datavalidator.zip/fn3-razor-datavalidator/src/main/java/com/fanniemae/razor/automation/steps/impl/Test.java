package com.fanniemae.razor.automation.steps.impl;

import java.text.DecimalFormat;

public class Test {
	public static void main (String[] args){
		/*int val = 89987654;
		int total = 89987654;
		double fraction = ((double)val/total);
		DecimalFormat twoDForm = new DecimalFormat("#.##");
		double percentLoaded = Double.valueOf(twoDForm.format(fraction*100));
		System.out.println("Percent Loaded: " + percentLoaded);*/
		
		String str = "Your    string with        spaces";
		//str = str.replace(" " , " ");
		str = str.replaceAll("\\s+"," ");
		System.out.println(str);
		String str1 = "lo_casecase_id";
		String[] split = str1.split("\\.", -1);
		System.out.println("Split: " + split[1]);
	}
}
