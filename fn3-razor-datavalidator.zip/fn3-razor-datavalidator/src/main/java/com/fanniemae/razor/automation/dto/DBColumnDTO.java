/*
 * Copyright (c) 2014 Fannie Mae. All rights reserved. Unpublished -- Rights
 * reserved under the copyright laws of the United States and international
 * conventions. Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction
 * is prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.razor.automation.dto;

/**
 * Represents one database column (name/value pair)
 * 
 * @author q2uscv
 */
public class DBColumnDTO {
    private String tableName;
    private String columnName;
    private String columnValue;
    private String foreignTable;
    private String foreignJoinColumn;
    private String join;
    private String notEqual;

    public DBColumnDTO() {
        super();
    }

    public DBColumnDTO(String tableName, String columnName, String columnValue, String foreignTable,
            String foreignJoinColumn, String join, String notEqual) {
        super();
        this.tableName = tableName;
        this.columnName = columnName;
        this.columnValue = columnValue;
        this.foreignTable = foreignTable;
        this.foreignJoinColumn = foreignJoinColumn;
        this.join = join;
        this.notEqual = notEqual;
    }

    public String getTableName() {
        return tableName;
    }

    public String getColumnName() {
        return columnName;
    }

    public String getColumnValue() {
        return columnValue;
    }

    public String getForeignTable() {
        return foreignTable;
    }

    public String getForeignJoinColumn() {
        return foreignJoinColumn;
    }

    public String getJoin() {
        return join;
    }

	public String getNotEqual() {
		return notEqual;
	}


}
