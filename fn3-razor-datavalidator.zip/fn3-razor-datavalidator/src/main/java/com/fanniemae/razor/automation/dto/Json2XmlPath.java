package com.fanniemae.razor.automation.dto;

/**
 * For the validation of JSON values 
 * @author q2uscv
 *
 */
public class Json2XmlPath {

	private String jsonPath;
	private  String xPath;
	
	public String getJsonPath() {
		return jsonPath;
	}
	public void setJsonPath(String jsonPath) {
		this.jsonPath = jsonPath;
	}
	public String getxPath() {
		return xPath;
	}
	public void setxPath(String xPath) {
		this.xPath = xPath;
	}
	
	

}
