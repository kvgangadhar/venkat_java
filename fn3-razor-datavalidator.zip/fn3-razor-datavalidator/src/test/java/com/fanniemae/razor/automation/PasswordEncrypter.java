package com.fanniemae.razor.automation;

import com.fanniemae.testeng.automation.exceptions.TestingException;
import com.fanniemae.testeng.automation.utils.EncryptionUtils;

public class PasswordEncrypter {

	/**
	 * @param args
	 * @throws TestingException 
	 */
	public static void main(String[] args){
		//System.out.println("Password::: " + EncryptionUtils.encrypt("p54e0eab6"));
		System.out.println("Decrypted Pwd ::: " + EncryptionUtils.decrypt("THVrXzNHaHQ="));
		
	}
}
