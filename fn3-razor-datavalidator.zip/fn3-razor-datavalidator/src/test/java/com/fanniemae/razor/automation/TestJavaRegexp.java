package com.fanniemae.razor.automation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestJavaRegexp {
	public static void main (String[] args){
		TestJavaRegexp exp = new TestJavaRegexp();
		String str = exp.getMatching();
		System.out.println("***************:" + str);
	}
		public String getMatching(){
		//Pattern p = Pattern.compile( "AMOUNT AVAILABLE TO PAY 571[, ]?([$][0-9]*[\\.]?(\\d\\d)?)" );
		Pattern p = Pattern.compile( "AMOUNT AVAILABLE TO PAY 571[.*]?[, ]?\\$?([0-9]*[\\.]?(\\d\\d)?)" );
		//Pattern.compile("([}?)(.*?)");
		Matcher m = p.matcher( "AMOUNT AVAILABLE TO PAY 571CLAIM$19803.85, NO 571 FILED YET OK TO C/O " );
		String s = null;
		if ( m.find() ) {
		   s = m.group(1); // " that is awesome"
		}
		return s;
	}
}
