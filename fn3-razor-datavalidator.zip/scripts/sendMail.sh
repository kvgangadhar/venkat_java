send_email()

{
   echo "${attargs[@]}"

 (
    echo "To: $MAILTO"
    echo "Subject: $SUBJECT"
    echo "MIME-Version: 1.0"
    echo 'Content-Type: multipart/mixed; boundary="END OF FILE"'

    for file in ${attargs[@]}; do
    echo '--END OF FILE'
    echo 'Content-Type: text/plain charset=US-ASCII; name="'$(basename $file)'"'
    echo 'Content-Disposition: attachment; filename="'$(basename $file)'"'
    cat $file
    done
    echo 'END OF FILE--'


    echo '--END OF FILE'
    echo "Content-Type: text/html charset=US-ASCII;"
    echo "Content-Disposition: inline"
    echo 'END OF FILE--'
    cat $BODY
  ) | /usr/sbin/sendmail -t "${MAILTO}"

}


echo 'Job starting...'
#Path of the log file
DIR_PATH=/appl/$USER/datavalidator/log/

#Today's date
DATE=`date +%Y%m%d`
DATE_HR=`date +%Y%m%d%H`
HTML_FILE_PATH=/appl/$USER/datavalidator/log/$DATE/DataValidationSummary_


#Finding list of file from with '_YYYYMMDDHH*' format
for att in $(find $DIR_PATH$DATE/ -name "*_$DATE_HR*.log"); do
 attargs+=("$att" )
done
export BODY=$HTML_FILE_PATH$DATE_HR*.html
export SUBJECT="Razor Datavaliadtor Logfiles and Error Report"
sendNotificationConf=$(grep -Po '(?<=^runSendEmailScript=)\w*$'  /appl/$USER/datavalidator/SendEmailConf.conf)
 echo $sendNotificationConf
if [ ${#attargs[@]} -eq 0 ]; then
echo "No log files found for this hour"
echo 'Email not sent.'
else
        echo 'Sending email...'
        if [ "$USER" = "fn3devl" ]; then
            if [ ${sendNotificationConf//} = "N" ]; then
                echo "Not required to send notification"
            else
                export MAILTO="venkatarao_veerapaneni@fanniemae.com,sarma_paturu@fanniemae.com"
                send_email
            fi
        elif [ "$USER" = "fn3acpt" ]; then
              
                if [ ${sendNotificationConf//} = "N" ]; then
                     echo "Not required to send notification"
                else
                     export MAILTO="venkatarao_veerapaneni@fanniemae.com,sarma_paturu@fanniemae.com"
                     send_email
                fi
        elif [ "$USER" = "fn3prod" ]; then
                 export MAILTO="RAZOR_IT_Support@fanniemae.com"
                 send_email
        fi
echo 'Email sent.'
fi

echo 'Job completed'

